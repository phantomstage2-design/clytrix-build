# Mira AI ⇄ CLYTRIX link

Optional. CLYTRIX works identically with the link off (the default).

## Why there's a relay

The Wear OS Data Layer only delivers messages between apps that have the **same package name and the same signing key** on the phone and the watch. Mira AI is a different app, so it can't message the watch directly. The `link` module is a tiny phone app with CLYTRIX's application id (`com.clytrix.core`) whose only job is to forward:

```
Mira AI ──(bound service, Messenger)──▶ CLYTRIX Link (phone) ──(Data Layer)──▶ CLYTRIX (watch)
        ◀──────────────────────────────                     ◀──────────────
```

If Mira runs on a **tablet** that isn't paired with the watch, it needs a path to the phone first (for example Mira's own phone⇄tablet sync calling the relay on the phone). That hop is outside CLYTRIX and isn't implemented here.

## Security model

1. The user turns the link on and taps **Pair with Mira** on the watch. A 6-digit code shows for 2 minutes.
2. Mira sends a `pair` request with that code. Five wrong codes cancel the session.
3. The watch replies with a random 256-bit token and stores only its SHA-256 hash plus the phone's node id.
4. Every command must come from that phone **and** carry the token.
5. Each command also needs the user's switch on the watch: **Allow control** or **Share status data** (both off after pairing). `ping` needs neither.
6. 30 requests per minute at most. Requests over 4 KB are refused.
7. On the phone, binding the relay requires the runtime permission `com.clytrix.permission.MIRA_LINK`, which the user grants to Mira.

Nothing private is ever sent: no photos, no conversations; form names only when data sharing is on and only for the form a request selected. **Mira can never trigger a transformation**: it can open the dial and point it at a form; the user confirms on the watch.

## Mira-side setup (Android)

`AndroidManifest.xml`:

```xml
<uses-permission android:name="com.clytrix.permission.MIRA_LINK" />
<queries>
    <package android:name="com.clytrix.core" />
</queries>
```

Request `com.clytrix.permission.MIRA_LINK` at runtime like any dangerous permission, then bind:

```kotlin
val intent = Intent("com.clytrix.link.BIND_BRIDGE").setPackage("com.clytrix.core")
context.bindService(intent, connection, Context.BIND_AUTO_CREATE)

// Send a request
val msg = Message.obtain(null, 1 /* MSG_REQUEST */).apply {
    data = Bundle().apply { putString("json", requestJson) }
    replyTo = Messenger(Handler(Looper.getMainLooper()) { reply ->
        if (reply.what == 2 /* MSG_REPLY */) handleReply(reply.data.getString("json")!!)
        true
    })
}
serviceMessenger.send(msg)
```

Store the token from a successful `pair` reply in encrypted storage.

## Messages

Request (Mira → watch):

```json
{"v":1, "id":"<unique, ≤64 chars>", "type":"pair", "code":"123456", "client":"Mira AI"}
{"v":1, "id":"<unique>", "type":"cmd", "token":"<token>", "cmd":"battery_status", "args":{}}
```

Reply (watch → Mira):

```json
{"v":1, "id":"<same id>", "ok":true,  "result":{...}, "speech":"CLYTRIX is in Balanced mode. ..."}
{"v":1, "id":"<same id>", "ok":false, "error":"permission_denied", "message":"Allow data sharing ..."}
```

`speech` is present only when the user allows spoken status reports; Mira can read it aloud as-is.

| cmd | needs | args | result |
|---|---|---|---|
| `ping` | — | — | `app`, `link`, `app_open` |
| `battery_status` | data | — | `battery_pct`, `charging`, `power_mode`, `active_profile`, `reason` (`stale`, `snapshot_at` when CLYTRIX is closed) |
| `diagnostics_summary` | data | — | `state`, `profile`, `fps`, `jank_fraction`, `sound_ready`, `crashes_24h`, `uptime_ms`, `checks[]` |
| `evolution_status` | data | — | `enabled`, `adjustments`, `rollbacks`, `last_optimization`, `profile`, `fps`, `jank_fraction` |
| `recommendations` | data | — | `recommendations[]` of `{id,title,detail}` (applying them is done on the watch) |
| `set_power_mode` | control | `{"mode":"performance"\|"balanced"\|"ultra"\|"adaptive"}` | `power_mode` (works even when CLYTRIX is closed) |
| `open_dial` | control | — | — |
| `select_favorite` | control | — | `selected`, `name` (if data sharing) |
| `select_form` | control | `{"name":"..."}` | `selected`, `name` (if data sharing) |

Errors: `bad_request`, `unsupported_version`, `link_disabled`, `rate_limited`, `not_pairing`, `wrong_code`, `pairing_expired`, `pairing_locked`, `unauthorized`, `unknown_command`, `permission_denied`, `bad_args`, `app_not_open`, `empty_roster`, `no_favorite`, `not_found`, `internal_error`; from the relay: `watch_unreachable`, `watch_timeout`, `send_failed`, `busy`, `bridge_closed`.

## Voice examples → commands

| Mira hears | Mira sends |
|---|---|
| "Hey Mira, check CLYTRIX battery usage." | `battery_status` |
| "Mira, activate Ultra Battery Saver." | `set_power_mode` `{"mode":"ultra"}` |
| "Mira, show the CLYTRIX diagnostics." | `diagnostics_summary` |
| "Mira, select my favorite transformation." | `select_favorite` |
| "Mira, how is the Evolution Core performing?" | `evolution_status` |

## Testing status

Watch side and relay: implemented, type-checked against Android API 36, auth logic unit-tested. Mira side: not available, not built, not tested. End-to-end delivery has not been tested on devices.
