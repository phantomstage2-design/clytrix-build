# Phase 1 — Audit of the Apexium project

Source: `Apexium_Complete_Project.zip` (26 Kotlin files, 5,259 lines, plus Gradle, manifest and resources). Every file was read before any change was made.

## What already existed (and was kept)

| System | Apexium file | What it did | In CLYTRIX |
|---|---|---|---|
| State machine | CoreController.kt | Disguised→Locked→Opening→Selecting→Flashing→Active→Recharging; timed phases run in LaunchedEffects keyed on the phase | Kept. Every transition now validated by `PhaseGraph`; Ascension, activation gesture, Mira handlers added |
| Settings | Settings.kt | Compose-state prefs with safe reads (bad values fall back instead of crashing) | Kept pattern; ~15 new settings; whitelisted export/import |
| Audio synthesis | AlienSynth.kt | Procedural sound set, Android-free | **Unchanged** (now the "Classic" set). Its building blocks power the new `CelestialSynth` |
| Audio playback | SoundEngine.kt | One worker + one shared AudioTrack; separate hum thread; drain-accurate waits; bounded write retries | Kept intact; added voice-set switching, volume, silent mode, profile-aware hum, diagnostics |
| Scheduling | SoundScheduler.kt | Priority queue, tick coalescing, critical cap; JVM-tested | **Unchanged** (its test still passes) |
| Rendering | DeviceDrawing.kt, CoreScreen.kt | Three-blade shutter device, particles, CRT overlay | Replaced by the original celestial device; gesture handler and phase driving kept |
| Roster | Aliens.kt, CustomAliens.kt | User photos, rename, remove, enable/disable, Apex flag | Kept; favorites, classifications, reorder, name/file validation added |
| Haptics | Haptics.kt | Waveforms, battery-saver scaling | Kept; intensity setting, confirm/Ascension/warning/recharge patterns added |
| Adaptive | AdaptiveCore.kt, AdaptiveTuner.kt | Budgeted, logged, rule-based self-healing + battery saver (Auto/On/Off); bezel/duration learning | Extended into the 4-mode power system and the Evolution Core executor; tuner unchanged |
| Crash recovery | CrashGuard.kt | Breadcrumb + next-launch quarantine of a form whose photo crashed the app | Kept; crash count/history for diagnostics |
| Backup | Backup.kt | ZIP of manifest + photos | Extended to settings/usage/progress with validation |
| Sensors | TiltSensor.kt, SlapDetector.kt | Parallax tilt, slap activation | Kept; sampling rate follows the power profile; activity tracked |
| Progress | Progress.kt | Transform counts, Overdrive unlock | Kept; export/import |

## Problems found and fixed

1. **Backup path traversal (security).** Apexium's import wrote `File(poolDir, name)` with `name` taken straight from the zip's manifest. A crafted backup could write outside the photo folder (e.g. `../shared_prefs/...`). CLYTRIX accepts only flat, whitelisted file names and ids (`BackupRules`, unit-tested), caps entry and total sizes, and checks that every photo decodes as an image before writing.
2. **Mandatory timer by default.** Apexium defaulted to a 30-second transformation. CLYTRIX defaults to **no limit**; a limit (10/30/60 s) is opt-in, and Recharging still follows it exactly as before.
3. **Overdrive banner on every launch.** The "OVERDRIVE UNLOCKED" celebration was keyed on the persisted unlock flag, so it replayed every time the app opened. It now shows only at the moment of unlocking.
4. **Continuous 60 fps.** Two separate per-frame loops (a particle loop and an infinite transition) kept the dial rendering at display rate even in battery saver. Replaced with one frame clock whose rate the power profile caps.
5. **Backup import on the main thread** (could freeze the UI on large backups) — moved to a background dispatcher.

## Dependencies

Build configuration kept as found: compileSdk/targetSdk 36, minSdk 30, AGP 8.10.0, Kotlin 2.0.21, Gradle wrapper 8.11.1, Compose BOM 2026.09.00, Wear Compose Material 1.7.1. One dependency added: `com.google.android.gms:play-services-wearable:19.0.0` (Data Layer, only for the optional Mira link). Versions could not be re-checked against Google's Maven repository from the build environment (blocked); see VERIFICATION.md.

## Not carried over

- `preview/demo.html` and `preview/soundboard.html` (Apexium-branded browser previews). Replaced by `preview/device_preview.html` and `preview/sounds/`.
- Apexium's lime/amber skins (replaced by eight CLYTRIX themes) and its three-blade shutter artwork.
