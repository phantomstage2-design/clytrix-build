# Verification report

This report separates four different levels of confidence. Nothing below is claimed beyond what actually ran.

## 1. Executed tests — PASSED (40 / 40)

Run with the real Kotlin 2.0.21 compiler and JUnit 4.13.2 on a JVM (not via Gradle):

| Test class | What it proves |
|---|---|
| SoundSchedulerTest (6) | Apexium's priority/coalescing/cap logic, unchanged |
| CelestialSynthTest (5) | Every CLYTRIX clip renders, is audible, stays in 16-bit range, starts/ends without a click; Ascension is longer than standard; the hum loops without a discontinuity |
| EvolutionPolicyTest (11) | Battery/heat/memory force lighter profiles; user floor/ceiling always respected; measured jank steers choices; hysteresis; smoothing; particle trim steps; trial rollback; recommendations |
| PerfMonitorTest (5) | FPS, jank (judged against the frame cap), idle-gap exclusion, input→frame latency, minimum-sample rule |
| MiraAuthTest (5) | Pairing code window, token verification bound to the phone node, lockout after wrong codes, per-command permissions, rate limiting |
| PhaseGraphTest (4) | The documented sequence is legal, skipping steps is illegal, every state can return to rest |
| BackupRulesTest (4) | Path traversal and unsafe names rejected, only known zip entries read, names cleaned |

One real bug was found by these tests and fixed (PerfMonitor ignored the interval after a frame stamped exactly at time 0).

## 2. Type-checked against the real Android API 36 platform — PASSED

All 27 non-UI source files of the watch app (everything except `MainActivity.kt` and the `ui/` package) plus the phone relay's `MiraBridgeService.kt` compile with Kotlin 2.0.21 against the actual `android.jar` for API 36 and the real kotlinx-coroutines library. AndroidX Compose *runtime*, `FileProvider` and the Play-services Wearable types were represented by minimal hand-written signature stubs, so calls into those libraries are checked only against my reading of their APIs.

This step caught and fixed one compile error (a helper named `setPhase` clashed with the generated setter of `phase`).

## 3. Static review only — NOT compiled

`MainActivity.kt` and the `ui/` package (CoreScreen, DeviceDrawing, SettingsScreen, SettingsPages, Palette, Theme, plus Apexium's unchanged Art, ParticleField, CrtOverlay, DisguiseFace) depend on Compose UI and Wear Compose, which could not be downloaded. They were reviewed by hand; expect that a first Gradle build may surface a few small compile errors there (an API signature or import), which are quick to fix in Android Studio.

The device drawing math was additionally ported 1:1 to an HTML canvas and rendered at 438 × 438 (`docs/images/`) to check the visual layout. That review led to one design fix (the core is dimmed behind the hologram for contrast).

## 4. Full build and APK — NOT DONE

`./gradlew assembleDebug` was attempted and stopped at the first step:

```
Plugin [id: 'com.android.application', version: '8.10.0'] was not found ...
could not resolve plugin artifact 'com.android.application:com.android.application.gradle.plugin:8.10.0'
Searched in: Google, MavenRepo, Gradle Central Plugin Repository
```

The environment's network policy blocks `maven.google.com`, `dl.google.com` and `repo.maven.apache.org` (HTTP 403 from the egress proxy), so neither the Android Gradle Plugin, the Android SDK build tools, nor any AndroidX library could be obtained. The build was not retried. **No APK exists yet, and none has been faked.** Building in Android Studio (see README) produces `CLYTRIX.apk`.

## 5. Real-device testing — NOT DONE

Nothing has run on a Galaxy Watch 8 Classic. Not yet verified on hardware: bezel feel, haptic strength, audio loudness/balance through the watch speaker, frame rates and battery drain per profile, sensor behavior, Data Layer delivery. The in-app **RUN FULL DIAGNOSTIC** is designed to report exactly these on the watch, marking anything it can't verify as NOT TESTED.

## 6. Mira AI integration — NOT VERIFIED

Mira AI's source wasn't provided. The watch side and the phone relay are implemented and type-checked; the protocol Mira must speak is in MIRA_INTEGRATION.md. Whether Mira can use it is unknown until Mira implements it and both are tested together.

## Suggested first-run checklist on the watch

1. Build and install (README). 2. Add two forms; mark one Ascended. 3. Open the dial, turn the bezel, transform, revert. 4. Switch each power mode and watch the frame rate in Diagnostics. 5. Run **RUN FULL DIAGNOSTIC** after turning the bezel. 6. Export a backup, delete a form, import the backup.
