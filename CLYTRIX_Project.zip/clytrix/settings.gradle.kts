pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "CLYTRIX"

// :app  -- the CLYTRIX watch app (Wear OS 6, Galaxy Watch 8 Classic). Fully standalone.
// :link -- OPTIONAL phone-side relay for the Mira AI Companion Link. It shares the watch app's
//          applicationId (com.clytrix.core) because the Wear OS Data Layer only delivers messages
//          between apps with the same package name and signing key; Mira AI (a different package)
//          talks to this relay instead. CLYTRIX never needs it to work. See docs/MIRA_INTEGRATION.md.
include(":app")
include(":link")
