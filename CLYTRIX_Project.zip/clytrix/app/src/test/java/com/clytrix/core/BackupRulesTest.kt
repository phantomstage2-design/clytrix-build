package com.clytrix.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupRulesTest {
    @Test
    fun `path traversal and odd names are rejected`() {
        assertTrue(BackupRules.isSafeFileName("form_ab12cd34ef56.webp"))
        assertTrue(BackupRules.isSafeFileName("alien_0123456789ab.webp")) // Apexium backups
        assertFalse(BackupRules.isSafeFileName("../shared_prefs/clytrix_settings.xml"))
        assertFalse(BackupRules.isSafeFileName("..webp"))
        assertFalse(BackupRules.isSafeFileName("a/b.webp"))
        assertFalse(BackupRules.isSafeFileName("a\\b.webp"))
        assertFalse(BackupRules.isSafeFileName(".hidden"))
        assertFalse(BackupRules.isSafeFileName(""))
        assertFalse(BackupRules.isSafeFileName("x".repeat(65)))
    }

    @Test
    fun `only known entries are read from a zip`() {
        assertTrue(BackupRules.isKnownEntry("manifest.json"))
        assertTrue(BackupRules.isKnownEntry("settings.json"))
        assertTrue(BackupRules.isKnownEntry("photos/form_1.webp"))
        assertFalse(BackupRules.isKnownEntry("photos/../../evil"))
        assertFalse(BackupRules.isKnownEntry("lib/arm64/libevil.so"))
        assertFalse(BackupRules.isKnownEntry("/manifest.json"))
    }

    @Test
    fun `names are cleaned and capped`() {
        assertEquals("Nova", BackupRules.cleanName("  Nova \n"))
        assertNull(BackupRules.cleanName("   "))
        assertEquals(BackupRules.MAX_NAME_CHARS, BackupRules.cleanName("y".repeat(200))!!.length)
    }

    @Test
    fun `ids are restricted`() {
        assertTrue(BackupRules.isSafeId("form_ab12"))
        assertFalse(BackupRules.isSafeId("form ab"))
        assertFalse(BackupRules.isSafeId("../x"))
    }
}
