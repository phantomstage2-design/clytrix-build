package com.clytrix.core

import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/** Every CLYTRIX clip renders, has real content, stays in range, and the hum loops cleanly. */
class CelestialSynthTest {

    private val clips: Map<String, () -> ShortArray> = linkedMapOf(
        "tick" to { CelestialSynth.tick(0) }, "open" to CelestialSynth::open, "activate" to CelestialSynth::activate,
        "close" to CelestialSynth::close, "confirm" to CelestialSynth::confirm, "transform" to CelestialSynth::transform,
        "ascension" to CelestialSynth::ascension, "revert" to CelestialSynth::revert,
        "revertAscended" to CelestialSynth::revertAscended, "warning" to CelestialSynth::warning,
        "timeout" to CelestialSynth::timeout, "recharged" to CelestialSynth::recharged,
        "recalibrate" to CelestialSynth::recalibrate, "error" to CelestialSynth::error, "hum" to CelestialSynth::hum,
    )

    @Test
    fun `every clip renders audible, bounded audio`() {
        for ((name, render) in clips) {
            val pcm = render()
            assertTrue("$name is empty", pcm.size > CelestialSynth.SR / 10)
            val peak = pcm.maxOf { abs(it.toInt()) }
            assertTrue("$name is near-silent (peak $peak)", peak > 3000)
            assertTrue("$name exceeds 16-bit range", peak <= 32767)
            val rms = kotlin.math.sqrt(pcm.sumOf { it.toDouble() * it } / pcm.size)
            assertTrue("$name RMS too low ($rms)", rms > 150)
        }
    }

    @Test
    fun `ascension is longer and fuller than a standard transformation`() {
        val std = CelestialSynth.transform()
        val asc = CelestialSynth.ascension()
        assertTrue("ascension should be longer", asc.size > std.size)
    }

    @Test
    fun `clips start and end quietly (no click on the shared track)`() {
        for ((name, render) in clips) {
            if (name == "hum") continue
            val pcm = render()
            assertTrue("$name starts with a click (${pcm.first()})", abs(pcm.first().toInt()) < 400)
            assertTrue("$name ends with a click (${pcm.last()})", abs(pcm.last().toInt()) < 400)
        }
    }

    @Test
    fun `hum wraps around without a discontinuity`() {
        val pcm = CelestialSynth.hum()
        assertTrue(pcm.size == (CelestialSynth.LOOP_SEC * CelestialSynth.SR).toInt())
        // The jump across the loop point should look like any ordinary sample-to-sample step.
        var maxStep = 0
        for (i in 1 until pcm.size) maxStep = maxOf(maxStep, abs(pcm[i] - pcm[i - 1]))
        val wrap = abs(pcm.first() - pcm.last())
        assertTrue("loop point jumps $wrap vs typical max step $maxStep", wrap <= maxStep * 1.5 + 50)
    }

    @Test
    fun `each tick variant differs`() {
        val a = CelestialSynth.tick(0).toList()
        val b = CelestialSynth.tick(1).toList()
        assertTrue(a != b)
    }
}
