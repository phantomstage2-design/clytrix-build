package com.clytrix.core

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhaseGraphTest {
    @Test
    fun `the documented transformation sequence is legal`() {
        val seq = listOf(Phase.Locked, Phase.Opening, Phase.Selecting, Phase.Flashing, Phase.Active, Phase.Recharging, Phase.Locked)
        for (i in 1 until seq.size) assertTrue("${seq[i - 1]} -> ${seq[i]}", PhaseGraph.isAllowed(seq[i - 1], seq[i]))
    }

    @Test
    fun `manual revert and disguise paths are legal`() {
        assertTrue(PhaseGraph.isAllowed(Phase.Active, Phase.Locked))
        assertTrue(PhaseGraph.isAllowed(Phase.Active, Phase.Disguised))
        assertTrue(PhaseGraph.isAllowed(Phase.Disguised, Phase.Opening))
        assertTrue(PhaseGraph.isAllowed(Phase.Selecting, Phase.Locked))
    }

    @Test
    fun `skipping steps is illegal`() {
        assertFalse(PhaseGraph.isAllowed(Phase.Locked, Phase.Active))
        assertFalse(PhaseGraph.isAllowed(Phase.Selecting, Phase.Active))
        assertFalse(PhaseGraph.isAllowed(Phase.Recharging, Phase.Selecting))
        assertFalse(PhaseGraph.isAllowed(Phase.Opening, Phase.Flashing))
    }

    @Test
    fun `every phase can return to rest`() {
        assertTrue(PhaseGraph.everyPhaseCanRest())
    }
}
