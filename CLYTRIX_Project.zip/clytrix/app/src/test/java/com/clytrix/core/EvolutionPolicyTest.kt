package com.clytrix.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EvolutionPolicyTest {
    private fun sig(batt: Int = 80, charging: Boolean = false, saver: Boolean = false, thermal: Int = 0, lowMem: Boolean = false) =
        EvolutionPolicy.Signals(batt, charging, saver, thermal, lowMem)

    private fun window(jank: Float, frameMs: Float = 17f) = PerfMonitor.Window(
        frames = 100, fps = 1000f / frameMs, avgFrameMs = frameMs, p95FrameMs = frameMs * 1.4f, jankFraction = jank,
        avgDrawMs = 2f, inputSamples = 0, inputLatencyAvgMs = 0f, inputLatencyMaxMs = 0f, expectedFps = 60,
    )

    @Test
    fun `conditions force lighter profiles`() {
        assertEquals(0, EvolutionPolicy.conditionRank(sig()))
        assertEquals(1, EvolutionPolicy.conditionRank(sig(batt = 25)))
        assertEquals(2, EvolutionPolicy.conditionRank(sig(batt = 12)))
        assertEquals(2, EvolutionPolicy.conditionRank(sig(saver = true)))
        assertEquals(2, EvolutionPolicy.conditionRank(sig(thermal = 3)))
        assertEquals(1, EvolutionPolicy.conditionRank(sig(thermal = 2)))
        assertEquals(1, EvolutionPolicy.conditionRank(sig(lowMem = true)))
        // charging relaxes battery rules, not heat
        assertEquals(0, EvolutionPolicy.conditionRank(sig(batt = 10, charging = true)))
        assertEquals(2, EvolutionPolicy.conditionRank(sig(batt = 10, charging = true, thermal = 4)))
    }

    @Test
    fun `low battery switches immediately, ignoring dwell time`() {
        val d = EvolutionPolicy.choose(Profile.Performance, emptyMap(), sig(batt = 10), 0, 2, sinceLastSwitchMs = 0)
        assertEquals(Profile.Ultra, d.profile)
        assertTrue(d.changed)
    }

    @Test
    fun `user floor is respected even when the battery is critical`() {
        val d = EvolutionPolicy.choose(Profile.Performance, emptyMap(), sig(batt = 5), ceiling = 0, floor = 1, sinceLastSwitchMs = 0)
        assertEquals(Profile.Balanced, d.profile)
        assertTrue(d.reason.contains("limit"))
    }

    @Test
    fun `user ceiling is respected`() {
        val d = EvolutionPolicy.choose(Profile.Balanced, emptyMap(), sig(batt = 100, charging = true), ceiling = 1, floor = 2, sinceLastSwitchMs = Long.MAX_VALUE)
        assertTrue(d.profile.rank >= 1)
    }

    @Test
    fun `measured jank steers away from a profile`() {
        val janky = EvolutionPolicy.withWindow(EvolutionPolicy.ProfileStats(), window(0.35f))
        val smooth = EvolutionPolicy.withWindow(EvolutionPolicy.ProfileStats(), window(0.01f))
        val stats = mapOf(Profile.Performance to janky, Profile.Balanced to smooth)
        val d = EvolutionPolicy.choose(Profile.Performance, stats, sig(batt = 90), 0, 2, sinceLastSwitchMs = Long.MAX_VALUE)
        assertEquals(Profile.Balanced, d.profile)
    }

    @Test
    fun `hysteresis holds the current profile for small or recent gains`() {
        val d = EvolutionPolicy.choose(Profile.Balanced, emptyMap(), sig(batt = 100, charging = true), 0, 2, sinceLastSwitchMs = 10_000)
        assertEquals(Profile.Balanced, d.profile)
        assertFalse(d.changed)
    }

    @Test
    fun `charging at full battery prefers full quality`() {
        val d = EvolutionPolicy.choose(Profile.Balanced, emptyMap(), sig(batt = 100, charging = true), 0, 2, sinceLastSwitchMs = Long.MAX_VALUE)
        assertEquals(Profile.Performance, d.profile)
    }

    @Test
    fun `stats are smoothed, not overwritten`() {
        var st = EvolutionPolicy.ProfileStats()
        st = EvolutionPolicy.withWindow(st, window(0.0f))
        st = EvolutionPolicy.withWindow(st, window(1.0f))
        assertTrue(st.jankEma in 0.2f..0.3f)
        st = EvolutionPolicy.withDrain(st, 10f)
        st = EvolutionPolicy.withDrain(st, -5f) // rejected
        st = EvolutionPolicy.withDrain(st, Float.NaN) // rejected
        assertEquals(1, st.drainSamples)
    }

    @Test
    fun `particle trim steps down on jank and up only after a smooth streak`() {
        assertEquals(0.85f, EvolutionPolicy.nextParticleScale(1.0f, 0.2f, 0)!!, 1e-4f)
        assertNull(EvolutionPolicy.nextParticleScale(0.4f, 0.5f, 0)) // already at minimum
        assertNull(EvolutionPolicy.nextParticleScale(0.7f, 0.01f, 2)) // streak too short
        assertEquals(0.85f, EvolutionPolicy.nextParticleScale(0.7f, 0.01f, 3)!!, 1e-4f)
        assertNull(EvolutionPolicy.nextParticleScale(1.0f, 0.01f, 9)) // already at maximum
    }

    @Test
    fun `trials are rolled back when jank rises`() {
        assertTrue(EvolutionPolicy.keepTrial(0.02f, 0.05f))
        assertFalse(EvolutionPolicy.keepTrial(0.02f, 0.2f))
    }

    @Test
    fun `recommendations reflect measurements and never include unrelated items`() {
        val base = EvolutionPolicy.RecInputs(
            crtOn = false, particlesOn = true, stayAwake = false, ambientHumOn = true, powerMode = PowerMode.Adaptive,
            batteryPct = 80, charging = false, jankEma = 0.01f, drainPerHour = 8f, soundFailures = 0, recentCrashes = 0,
        )
        assertTrue(EvolutionPolicy.recommendations(base).isEmpty())
        val crtJank = EvolutionPolicy.recommendations(base.copy(crtOn = true, jankEma = 0.3f)).map { it.id }
        assertTrue("crt_off" in crtJank)
        assertTrue("particles_off" in crtJank)
        val lowPerf = EvolutionPolicy.recommendations(base.copy(powerMode = PowerMode.Performance, batteryPct = 20)).map { it.id }
        assertTrue("mode_adaptive" in lowPerf)
        assertNotNull(EvolutionPolicy.recommendations(base.copy(recentCrashes = 3)).find { it.id == "run_diagnostic" })
    }
}
