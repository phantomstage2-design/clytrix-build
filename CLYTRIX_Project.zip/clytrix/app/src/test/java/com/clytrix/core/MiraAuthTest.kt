package com.clytrix.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class MiraAuthTest {

    @Test
    fun `correct code within the window pairs and issues a verifiable token`() {
        val s = MiraAuth.newSession(now = 0)
        assertEquals(6, s.code.length)
        val (r, keep) = MiraAuth.attempt(s, s.code, now = 1_000)
        assertTrue(r is MiraAuth.PairResult.Paired)
        assertNull(keep)
        val p = r as MiraAuth.PairResult.Paired
        assertTrue(p.token.length >= 40)
        assertTrue(MiraAuth.verify(p.tokenHash, "node-A", p.token, "node-A"))
        assertFalse("other node", MiraAuth.verify(p.tokenHash, "node-A", p.token, "node-B"))
        assertFalse("wrong token", MiraAuth.verify(p.tokenHash, "node-A", p.token + "x", "node-A"))
        assertFalse("not paired", MiraAuth.verify(null, null, p.token, "node-A"))
    }

    @Test
    fun `expired sessions and absent sessions are refused`() {
        val s = MiraAuth.newSession(now = 0)
        assertTrue(MiraAuth.attempt(s, s.code, now = MiraAuth.PAIR_WINDOW_MS + 1).first is MiraAuth.PairResult.Expired)
        assertTrue(MiraAuth.attempt(null, "123456", now = 0).first is MiraAuth.PairResult.NotPairing)
    }

    @Test
    fun `wrong codes lock the session after the limit`() {
        var s: MiraAuth.PairSession? = MiraAuth.newSession(now = 0)
        val wrong = if (s!!.code == "000000") "111111" else "000000"
        repeat(MiraAuth.MAX_ATTEMPTS - 1) {
            val (r, keep) = MiraAuth.attempt(s, wrong, now = 10)
            assertTrue(r is MiraAuth.PairResult.WrongCode)
            s = keep
        }
        val (r, keep) = MiraAuth.attempt(s, wrong, now = 10)
        assertTrue(r is MiraAuth.PairResult.Locked)
        assertNull(keep)
    }

    @Test
    fun `permissions gate each command`() {
        assertTrue(MiraAuth.permitted("ping", allowControl = false, allowData = false))
        assertFalse(MiraAuth.permitted("battery_status", allowControl = true, allowData = false))
        assertTrue(MiraAuth.permitted("battery_status", allowControl = false, allowData = true))
        assertFalse(MiraAuth.permitted("set_power_mode", allowControl = false, allowData = true))
        assertTrue(MiraAuth.permitted("select_favorite", allowControl = true, allowData = false))
        assertFalse(MiraAuth.permitted("transform_now", allowControl = true, allowData = true))
    }

    @Test
    fun `rate limiter allows the limit per window, then recovers`() {
        val rl = MiraAuth.RateLimiter(limit = 3, windowMs = 1000)
        assertTrue(rl.tryAcquire(0)); assertTrue(rl.tryAcquire(1)); assertTrue(rl.tryAcquire(2))
        assertFalse(rl.tryAcquire(3))
        assertTrue(rl.tryAcquire(1001))
    }
}
