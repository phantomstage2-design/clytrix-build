package com.clytrix.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Local-JVM tests for [SoundScheduler] (carried over from Apexium) -- the ordering/coalescing/
 * capping logic that [SoundEngine] relies on to keep effect playback bounded and prioritised.
 * [SoundScheduler] has no Android dependency, so nothing here needs Robolectric or a device.
 */
class SoundSchedulerTest {

    private val critical = 0
    private val tick = 1

    @Test
    fun `critical jumps ahead of an already-queued tick`() {
        val s = SoundScheduler<String>()
        s.offer(tick, "tick1", coalesceKey = "TICK_KEY")
        s.offer(critical, "open")
        assertEquals("open", s.take())
        assertEquals("tick1", s.take())
    }

    @Test
    fun `FIFO within the same priority tier`() {
        val s = SoundScheduler<String>()
        s.offer(critical, "a")
        s.offer(critical, "b")
        s.offer(critical, "c")
        assertEquals("a", s.take())
        assertEquals("b", s.take())
        assertEquals("c", s.take())
    }

    @Test
    fun `a burst of rapid ticks coalesces down to one queued`() {
        val s = SoundScheduler<String>()
        repeat(50) { s.offer(tick, "tick$it", coalesceKey = "TICK_KEY") }
        assertEquals(1, s.size())
        assertEquals("tick49", s.take())
    }

    @Test
    fun `different coalesce keys do not collide`() {
        val s = SoundScheduler<String>()
        s.offer(tick, "tickA", coalesceKey = "KEY_A")
        s.offer(tick, "tickB", coalesceKey = "KEY_B")
        assertEquals(2, s.size())
    }

    @Test
    fun `critical requests are capped, not coalesced -- excess is dropped`() {
        val s = SoundScheduler<String>(maxPerPriority = mapOf(critical to 4))
        var accepted = 0
        repeat(10) { if (s.offer(critical, "c$it")) accepted++ }
        assertEquals(4, accepted)
        assertEquals(4, s.size())
        assertEquals("c0", s.take())
    }

    @Test
    fun `concurrent offers never exceed the configured bound and drain cleanly`() {
        val s = SoundScheduler<Int>(maxPerPriority = mapOf(critical to 5))
        val pool = Executors.newFixedThreadPool(8)
        val done = CountDownLatch(16)
        repeat(8) {
            pool.submit({
                try {
                    repeat(2000) { i -> s.offer(tick, i, coalesceKey = "TICK_KEY") }
                } finally {
                    done.countDown()
                }
            })
            pool.submit({
                try {
                    repeat(2000) { i -> s.offer(critical, i) }
                } finally {
                    done.countDown()
                }
            })
        }
        assertTrue(done.await(30, TimeUnit.SECONDS))
        pool.shutdown()
        // At most 1 coalesced tick + the 5-entry critical cap can ever be queued at once.
        assertTrue("queue size should never exceed 6, was ${s.size()}", s.size() <= 6)
        var drained = 0
        while (s.size() > 0 && drained <= 100) {
            s.take()
            drained++
        }
        assertTrue(drained <= 6)
    }
}
