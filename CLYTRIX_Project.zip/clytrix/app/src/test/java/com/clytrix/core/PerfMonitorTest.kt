package com.clytrix.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PerfMonitorTest {
    private val ms = 1_000_000L

    @Test
    fun `steady 60 fps measures as 60 fps with no jank`() {
        val p = PerfMonitor()
        var t = 0L
        repeat(121) { p.onFrame(t, t / ms, 2 * ms, 0); t += 16_667_000L }
        val w = p.closeWindow()!!
        assertEquals(120, w.frames)
        assertEquals(60f, w.fps, 0.5f)
        assertEquals(0f, w.jankFraction, 0f)
        assertEquals(2f, w.avgDrawMs, 0.01f)
    }

    @Test
    fun `long frames count as jank, idle gaps do not`() {
        val p = PerfMonitor()
        var t = 0L
        p.onFrame(t, 0, 0, 0)
        repeat(50) { t += 16 * ms; p.onFrame(t, t / ms, 0, 0) }
        repeat(10) { t += 40 * ms; p.onFrame(t, t / ms, 0, 0) } // janky at a 60 fps target
        t += 2000 * ms; p.onFrame(t, t / ms, 0, 0)                 // idle gap: ignored
        val w = p.closeWindow()!!
        assertEquals(60, w.frames)
        assertEquals(10f / 60f, w.jankFraction, 1e-4f)
    }

    @Test
    fun `jank is judged against the frame-rate cap`() {
        val p = PerfMonitor()
        var t = 0L
        repeat(41) { p.onFrame(t, t / ms, 0, 15); t += 66 * ms }
        assertEquals(0f, p.closeWindow()!!.jankFraction, 0f)
    }

    @Test
    fun `input latency is measured to the next frame`() {
        val p = PerfMonitor()
        p.onFrame(0, 1000, 0, 0)
        p.onInput(1005)
        p.onFrame(16 * ms, 1021, 0, 0)
        repeat(40) { i -> p.onFrame((32 + 16 * i) * ms, 1037L + 16 * i, 0, 0) }
        val w = p.closeWindow()!!
        assertEquals(1, w.inputSamples)
        assertEquals(16f, w.inputLatencyAvgMs, 0.01f)
    }

    @Test
    fun `too few frames gives no verdict`() {
        val p = PerfMonitor()
        repeat(5) { p.onFrame(it * 16 * ms, 0, 0, 0) }
        assertNull(p.closeWindow())
        assertTrue(p.pendingFrames() > 0)
    }
}
