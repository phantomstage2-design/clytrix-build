package com.clytrix.core.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

private const val DEG = (Math.PI / 180.0).toFloat()

/*
 * CLYTRIX's device, drawn entirely in code -- an original design (no bundled artwork):
 *
 *   case        deep-black radial plate, a brushed-silver bezel ring with 60 engraved ticks (every
 *               fifth in gold)
 *   selection   a gold ring of twelve four-pointed stars that turns with the bezel; the star at the
 *   ring        top marker brightens as forms pass under it
 *   constellation  seven linked stars on a slow counter-rotating orbit
 *   conduits    eight curved energy channels between core and rim, each carrying a travelling pulse
 *   core        a luminous radial core with a slowly turning octagram (two interlocked squares)
 *   segments    eight metal segments that close over the core; when closed their glowing seams and
 *               the gold octagram form the CLYTRIX emblem; opening, they slide out and turn away
 *   hologram    the selected form projected in the core: tinted light, scanlines, a rising beam
 *   ascension   rotating rays and a white-gold halo, only for Ascended forms in Ascension Mode
 *
 * Everything scales from the Canvas size, so it fits the Galaxy Watch 8 Classic's 438 x 438 round
 * display (and any other round watch) without fixed pixel values. Animated parameters are passed
 * in; nothing here holds state.
 */

/** The core window, as a circle. */
fun windowPath(c: Offset, r: Float): Path = Path().apply { addOval(Rect(center = c, radius = r)) }

/** Draws an image centred at [cx],[cy], [w] x [h] px, with optional tint / blend. */
fun DrawScope.drawArt(
    bmp: ImageBitmap, cx: Float, cy: Float, w: Float, h: Float = w,
    alpha: Float = 1f, filter: ColorFilter? = null, blend: BlendMode = BlendMode.SrcOver,
) {
    drawImage(
        image = bmp,
        srcOffset = IntOffset.Zero, srcSize = IntSize(bmp.width, bmp.height),
        dstOffset = IntOffset((cx - w / 2f).roundToInt(), (cy - h / 2f).roundToInt()),
        dstSize = IntSize(w.roundToInt(), h.roundToInt()),
        alpha = alpha.coerceIn(0f, 1f), colorFilter = filter, blendMode = blend, filterQuality = FilterQuality.Medium,
    )
}

/** A [points]-pointed star outline centred on [c]. */
fun starPath(c: Offset, rOuter: Float, rInner: Float, points: Int = 4, rotDeg: Float = -90f): Path = Path().apply {
    val n = points * 2
    for (i in 0 until n) {
        val r = if (i % 2 == 0) rOuter else rInner
        val a = (rotDeg + i * 360f / n) * DEG
        val x = c.x + cos(a) * r
        val y = c.y + sin(a) * r
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

/** Two interlocked squares: the octagram at the heart of the emblem. */
private fun DrawScope.drawOctagram(c: Offset, r: Float, rotDeg: Float, color: Color, width: Float, alpha: Float) {
    for (k in 0 until 2) {
        val p = Path()
        for (i in 0 until 4) {
            val a = (rotDeg + k * 45f + i * 90f) * DEG
            val x = c.x + cos(a) * r
            val y = c.y + sin(a) * r
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        drawPath(p, color, alpha = alpha, style = Stroke(width = width, join = StrokeJoin.Miter))
    }
}

private val constellation: List<Pair<Float, Float>> = Random(17).let { rnd ->
    // (angle in degrees, radius fraction) for seven linked stars -- fixed seed, stable pattern
    List(7) { i -> (i * 51.4f + rnd.nextFloat() * 18f) to (0.78f + rnd.nextFloat() * 0.05f) }
}

/**
 * The full device for Locked / Opening / Selecting / Flashing / Recharging.
 *
 * @param open 0 = segments closed (emblem shows), 1 = fully open (core and hologram visible).
 * @param time seconds, from the throttled frame clock.
 * @param ringAngle degrees the selection ring has turned with the bezel.
 * @param pulse 0..1 breathing of the core glow.
 * @param form the selected form's picture (only visible once mostly open).
 * @param swap 0..1 progress of the form-change animation; [direction] its slide direction.
 * @param ascended true while the selected form will transform in Ascension Mode.
 * @param intensity glow multiplier from the Animation intensity setting.
 */
fun DrawScope.drawCelestialDevice(
    pal: Palette,
    open: Float,
    time: Float,
    ringAngle: Float,
    pulse: Float,
    form: ImageBitmap?,
    swap: Float,
    direction: Int,
    tiltX: Float = 0f,
    tiltY: Float = 0f,
    particles: List<Particle> = emptyList(),
    ascended: Boolean = false,
    overdriveActive: Boolean = false,
    recalibrateGlow: Float = 0f,
    intensity: Float = 1f,
) {
    val c = center
    val outer = size.minDimension / 2f
    val rc = outer * 0.56f
    val parX = tiltX * outer * 0.025f
    val parY = tiltY * outer * 0.025f
    val cc = Offset(c.x + parX, c.y + parY)
    val awake = 0.35f + 0.65f * open

    // ---- case and silver bezel ---------------------------------------------------------------------
    drawCircle(Brush.radialGradient(listOf(pal.caseA, pal.caseB), center = c, radius = outer), radius = outer, center = c)
    drawCircle(
        brush = Brush.sweepGradient(listOf(pal.silver, Color(0xFF4A5157), pal.silver, Color(0xFF3A4045), pal.silver), center = c),
        radius = outer * 0.975f, center = c, style = Stroke(outer * 0.03f),
    )
    for (k in 0 until 60) {
        val a = (k * 6f) * DEG
        val major = k % 5 == 0
        val r0 = outer * (if (major) 0.905f else 0.925f)
        val r1 = outer * 0.952f
        drawLine(
            if (major) pal.gold.copy(alpha = 0.85f) else pal.silver.copy(alpha = 0.35f),
            Offset(c.x + cos(a) * r0, c.y + sin(a) * r0), Offset(c.x + cos(a) * r1, c.y + sin(a) * r1),
            strokeWidth = outer * (if (major) 0.012f else 0.006f), cap = StrokeCap.Round,
        )
    }

    // ---- selection ring: twelve stars turning with the bezel ---------------------------------------
    drawCircle(pal.gold.copy(alpha = 0.45f), radius = outer * 0.86f, center = c, style = Stroke(outer * 0.006f))
    for (k in 0 until 12) {
        val deg = k * 30f + ringAngle
        val rad = deg * DEG
        val pos = Offset(c.x + sin(rad) * outer * 0.86f, c.y - cos(rad) * outer * 0.86f)
        var d = deg % 360f
        if (d < 0f) d += 360f
        if (d > 180f) d -= 360f
        val near = max(0f, 1f - abs(d) / 40f)
        val r = outer * (0.026f + 0.02f * near)
        if (near > 0.01f) drawCircle(pal.glow.copy(alpha = 0.35f * near * awake * intensity.coerceAtMost(1.3f)), radius = r * 2.2f, center = pos)
        drawPath(starPath(pos, r, r * 0.32f, 4, deg - 90f), lerp(pal.gold, pal.accent, near), alpha = (0.45f + 0.55f * near) * awake)
    }

    // ---- constellation, slowly counter-rotating -------------------------------------------------------
    rotate(-time * 3f, pivot = c) {
        val pts = constellation.map { (deg, fr) -> Offset(c.x + cos(deg * DEG) * outer * fr, c.y + sin(deg * DEG) * outer * fr) }
        for (i in 0 until pts.size - 1) drawLine(pal.silver.copy(alpha = 0.16f * awake), pts[i], pts[i + 1], strokeWidth = outer * 0.004f)
        for ((i, p) in pts.withIndex()) {
            val tw = 0.5f + 0.5f * sin(time * (1.3f + i * 0.21f) + i)
            drawCircle(pal.accent.copy(alpha = (0.25f + 0.45f * tw) * awake), radius = outer * (0.008f + 0.004f * tw), center = p)
        }
    }

    // ---- energy conduits between core and rim -----------------------------------------------------------
    for (k in 0 until 8) {
        val a0 = (k * 45f + 22.5f) * DEG
        val a1 = a0 + 18f * DEG
        val p0 = Offset(cc.x + cos(a0) * rc * 1.02f, cc.y + sin(a0) * rc * 1.02f)
        val ctl = Offset(c.x + cos((a0 + a1) / 2f) * outer * 0.70f, c.y + sin((a0 + a1) / 2f) * outer * 0.70f)
        val p1 = Offset(c.x + cos(a1) * outer * 0.80f, c.y + sin(a1) * outer * 0.80f)
        val path = Path().apply { moveTo(p0.x, p0.y); quadraticTo(ctl.x, ctl.y, p1.x, p1.y) }
        drawPath(path, pal.goldDeep.copy(alpha = 0.55f), style = Stroke(outer * 0.016f, cap = StrokeCap.Round))
        drawPath(path, pal.glow.copy(alpha = (0.12f + 0.18f * open) * intensity.coerceAtMost(1.3f)), style = Stroke(outer * 0.007f, cap = StrokeCap.Round))
        val t = (time * 0.45f + k * 0.125f) % 1f
        val u = 1f - t
        val pp = Offset(u * u * p0.x + 2 * u * t * ctl.x + t * t * p1.x, u * u * p0.y + 2 * u * t * ctl.y + t * t * p1.y)
        val pa = (0.35f + 0.65f * open) * sin(t * Math.PI.toFloat())
        drawCircle(pal.glow.copy(alpha = pa * 0.35f), radius = outer * 0.022f, center = pp)
        drawCircle(pal.accent.copy(alpha = pa), radius = outer * 0.008f, center = pp)
    }

    // ---- Ascension rays (behind the core) ---------------------------------------------------------------
    if (ascended && open > 0.05f) drawAscensionRays(cc, rc * 0.9f, outer * 0.95f, time, pal, open * intensity)

    // ---- the core ----------------------------------------------------------------------------------------
    clipPath(windowPath(cc, rc)) {
        drawCircle(
            Brush.radialGradient(
                listOf(lerp(pal.accent, pal.coreA, 0.35f), pal.coreA, pal.coreB, lerp(pal.coreB, Color.Black, 0.55f)),
                center = Offset(cc.x, cc.y - rc * 0.08f), radius = rc * 1.05f,
            ),
            radius = rc, center = cc, alpha = 0.55f + 0.45f * open,
        )
        drawOctagram(cc, rc * 0.92f, time * 6f, pal.gold, rc * 0.012f, 0.30f + 0.2f * pulse)
        drawCircle(pal.gold.copy(alpha = 0.25f), radius = rc * 0.62f, center = cc, style = Stroke(rc * 0.008f))
        drawCircle(pal.accent.copy(alpha = 0.12f), radius = rc * 0.36f, center = cc, style = Stroke(rc * 0.006f))

        // hologram of the selected form
        if (form != null && open > 0.55f) {
            val a = ((open - 0.55f) / 0.45f).coerceIn(0f, 1f) * swap.coerceIn(0f, 1f)
            val box = rc * 1.5f * (0.86f + 0.14f * swap)
            val offY = direction * (1f - swap) * rc * 0.32f
            val bob = sin(time * 1.6f) * rc * 0.012f
            val cy = cc.y - rc * 0.04f + offY + bob
            // Dim the core behind the projection so the hologram reads clearly against it.
            drawCircle(
                Brush.radialGradient(listOf(Color.Black.copy(alpha = 0.55f * a), Color.Black.copy(alpha = 0.25f * a)), center = cc, radius = rc),
                radius = rc, center = cc,
            )
            drawHologramBeam(cc, rc, pal, a)
            drawHologram(form, cc.x, cy, box, pal, time, a)
        }

        // the eight mechanical segments
        drawSegments(cc, rc, open, pal, pulse)
    }
    drawCircle(pal.gold.copy(alpha = 0.75f), radius = rc, center = cc, style = Stroke(outer * 0.012f))
    drawCircle(pal.glow.copy(alpha = (0.25f + 0.35f * pulse) * awake * intensity.coerceAtMost(1.3f)), radius = rc * 1.035f, center = cc, style = Stroke(outer * 0.006f))

    // ---- closed: core glow leaking through the seams --------------------------------------------------------
    val leak = (0.25f + 0.35f * pulse) * (1f - open) * intensity
    if (leak > 0.01f) {
        drawCircle(
            Brush.radialGradient(listOf(pal.glow.copy(alpha = leak.coerceAtMost(1f)), Color.Transparent), center = cc, radius = rc * 0.7f),
            radius = rc * 0.7f, center = cc,
        )
    }

    // ---- indicators ---------------------------------------------------------------------------------------
    if (ascended && open > 0.05f) {
        drawCircle(lerp(pal.gold, Color.White, 0.5f).copy(alpha = (0.35f + 0.25f * pulse) * open), radius = outer * 0.905f, center = c, style = Stroke(outer * 0.01f))
    }
    if (overdriveActive) {
        val od = 0.55f + 0.45f * sin(time * 3f)
        drawCircle(overdriveGlow.copy(alpha = 0.5f * od), radius = outer * 0.94f, center = c, style = Stroke(outer * 0.012f))
    }
    if (recalibrateGlow > 0.01f) {
        drawCircle(pal.glow.copy(alpha = 0.6f * recalibrateGlow), radius = outer * 0.86f, center = c, style = Stroke(outer * (0.008f + 0.02f * recalibrateGlow)))
    }

    // glass glare (tilt-reactive)
    val glare = Offset(c.x - outer * (0.32f + tiltX * 0.16f), c.y - outer * (0.40f + tiltY * 0.16f))
    drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.10f), Color.Transparent), center = glare, radius = outer * 0.55f), radius = outer * 0.55f, center = glare)

    drawParticles(particles, pal)

    // selection marker at 12 o'clock
    val marker = Path().apply {
        moveTo(c.x, c.y - outer * 0.895f)
        lineTo(c.x - outer * 0.03f, c.y - outer * 0.965f)
        lineTo(c.x + outer * 0.03f, c.y - outer * 0.965f)
        close()
    }
    drawPath(marker, pal.gold, alpha = awake)
}

/** Eight metal segments: closed they meet at the centre; opening, they slide outward and turn. */
private fun DrawScope.drawSegments(c: Offset, rc: Float, open: Float, pal: Palette, pulse: Float) {
    if (open > 0.985f) return
    val shift = rc * 1.05f * open
    rotate(open * 28f, pivot = c) {
        for (i in 0 until 8) {
            val mid = (i * 45f - 90f) * DEG
            val ux = cos(mid)
            val uy = sin(mid)
            val ax = c.x + ux * shift
            val ay = c.y + uy * shift
            val half = 22.5f * DEG
            val far = rc * 1.15f
            val p1 = Offset(ax + cos(mid - half) * far, ay + sin(mid - half) * far)
            val p2 = Offset(ax + cos(mid + half) * far, ay + sin(mid + half) * far)
            val seg = Path().apply { moveTo(ax, ay); lineTo(p1.x, p1.y); lineTo(p2.x, p2.y); close() }
            drawPath(seg, Brush.linearGradient(listOf(pal.metalA, pal.metalB), start = Offset(ax, ay), end = Offset(ax + ux * rc, ay + uy * rc)))
            drawPath(seg, pal.goldDeep, alpha = 0.9f, style = Stroke(width = rc * 0.012f, join = StrokeJoin.Round))
            // the seam light between segments
            val seamA = (0.55f + 0.4f * pulse) * (1f - open)
            if (seamA > 0.01f) {
                drawLine(pal.glow.copy(alpha = seamA), Offset(ax, ay), Offset(ax + cos(mid - half) * rc * 1.0f, ay + sin(mid - half) * rc * 1.0f),
                    strokeWidth = rc * 0.035f, cap = StrokeCap.Round)
            }
            // a small engraved star on each segment
            val sp = Offset(ax + ux * rc * 0.62f, ay + uy * rc * 0.62f)
            drawPath(starPath(sp, rc * 0.05f, rc * 0.018f, 4, i * 45f), pal.gold, alpha = 0.55f)
        }
        // the emblem: gold octagram and a glowing heart, visible while closed
        val e = (1f - open * 2.2f).coerceIn(0f, 1f)
        if (e > 0.01f) {
            drawOctagram(c, rc * 0.34f, 0f, pal.gold, rc * 0.022f, e)
            drawCircle(pal.glow.copy(alpha = e * (0.6f + 0.4f * pulse)), radius = rc * 0.12f, center = c)
            drawCircle(pal.accent.copy(alpha = e), radius = rc * 0.05f, center = c)
            drawLine(pal.accent.copy(alpha = e * 0.85f), Offset(c.x, c.y - rc * 0.3f), Offset(c.x, c.y + rc * 0.3f), strokeWidth = rc * 0.018f, cap = StrokeCap.Round)
        }
    }
}

/** A soft upward beam from the bottom of the core: the projector the hologram stands on. */
private fun DrawScope.drawHologramBeam(c: Offset, rc: Float, pal: Palette, a: Float) {
    val beam = Path().apply {
        moveTo(c.x - rc * 0.12f, c.y + rc * 0.95f)
        lineTo(c.x + rc * 0.12f, c.y + rc * 0.95f)
        lineTo(c.x + rc * 0.75f, c.y - rc * 0.6f)
        lineTo(c.x - rc * 0.75f, c.y - rc * 0.6f)
        close()
    }
    drawPath(beam, Brush.verticalGradient(listOf(Color.Transparent, pal.glow.copy(alpha = 0.22f * a)), startY = c.y - rc * 0.6f, endY = c.y + rc * 0.95f))
}

/**
 * The selected form as an animated hologram: the photo at reduced opacity, the theme's light
 * added on top, drifting scanlines and a faint flicker. Clipped to the core by the caller.
 */
fun DrawScope.drawHologram(img: ImageBitmap, cx: Float, cy: Float, box: Float, pal: Palette, time: Float, a: Float) {
    val flicker = 0.92f + 0.08f * sin(time * 23f) * sin(time * 7.3f)
    drawArt(img, cx, cy, box, alpha = 0.78f * a * flicker)
    drawArt(img, cx, cy, box, alpha = 0.32f * a, filter = ColorFilter.tint(pal.glow, BlendMode.SrcIn), blend = BlendMode.Plus)
    val top = cy - box / 2f
    val spacing = box / 34f
    val drift = (time * spacing * 2.2f) % spacing
    var y = top + drift
    while (y < top + box) {
        drawLine(pal.glow.copy(alpha = 0.10f * a), Offset(cx - box / 2f, y), Offset(cx + box / 2f, y), strokeWidth = spacing * 0.35f)
        y += spacing
    }
    val sweep = top + ((time * 0.35f) % 1f) * box
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, pal.accent.copy(alpha = 0.18f * a), Color.Transparent), startY = sweep - spacing * 3, endY = sweep + spacing * 3),
        topLeft = Offset(cx - box / 2f, sweep - spacing * 3), size = Size(box, spacing * 6))
}

/** Ascension: slowly turning rays of white-gold light. */
fun DrawScope.drawAscensionRays(c: Offset, r0: Float, r1: Float, time: Float, pal: Palette, strength: Float) {
    val col = lerp(pal.gold, Color.White, 0.55f)
    rotate(time * 8f, pivot = c) {
        for (k in 0 until 16) {
            val a = (k * 22.5f) * DEG
            val long = k % 2 == 0
            val end = if (long) r1 else r1 * 0.82f
            val w = 0.35f + 0.65f * (0.5f + 0.5f * sin(time * 2.1f + k))
            drawLine(
                Brush.linearGradient(listOf(col.copy(alpha = 0.45f * strength.coerceAtMost(1f) * w), Color.Transparent),
                    start = Offset(c.x + cos(a) * r0, c.y + sin(a) * r0), end = Offset(c.x + cos(a) * end, c.y + sin(a) * end)),
                Offset(c.x + cos(a) * r0, c.y + sin(a) * r0), Offset(c.x + cos(a) * end, c.y + sin(a) * end),
                strokeWidth = r0 * (if (long) 0.07f else 0.045f), cap = StrokeCap.Round,
            )
        }
    }
}

/**
 * The transformed state: the form fully materialised inside a halo, orbiting stars, and -- only
 * if the user chose a time limit -- a countdown ring.
 *
 * @param remaining 1..0 countdown fraction; [timed] false = no ring (no limit, or Overdrive).
 */
fun DrawScope.drawActiveState(
    pal: Palette,
    img: ImageBitmap,
    time: Float,
    breathe: Float,
    remaining: Float,
    timed: Boolean,
    overdrive: Boolean,
    ascended: Boolean,
    tiltX: Float,
    tiltY: Float,
    particles: List<Particle>,
    intensity: Float,
) {
    val c = center
    val r = size.minDimension / 2f
    drawCircle(Brush.radialGradient(listOf(pal.caseA, pal.caseB), center = c, radius = r), radius = r, center = c)
    drawCircle(
        Brush.radialGradient(listOf(pal.glow.copy(alpha = ((0.28f + 0.14f * breathe) * intensity).coerceAtMost(0.7f)), Color.Transparent), center = c, radius = r),
        radius = r, center = c,
    )
    if (ascended) drawAscensionRays(c, r * 0.42f, r * 0.98f, time, pal, 1f * intensity)

    // halo rings expanding outward
    for (k in 0 until 3) {
        val ph = ((time * 0.25f) + k / 3f) % 1f
        drawCircle(pal.glow.copy(alpha = 0.35f * (1f - ph)), radius = r * (0.45f + 0.5f * ph), center = c, style = Stroke(r * 0.01f))
    }
    drawOctagram(c, r * 0.86f, time * 4f, pal.gold, r * 0.006f, 0.25f)

    val stroke = r * 0.045f
    drawCircle(pal.gold.copy(alpha = 0.25f), radius = r - stroke, center = c, style = Stroke(stroke * 0.4f))
    when {
        overdrive -> {
            val od = 0.65f + 0.35f * sin(time * 2.4f)
            drawCircle(overdriveGlow.copy(alpha = 0.55f * od), radius = r - stroke, center = c, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        timed -> {
            val low = remaining < 0.2f
            val ringColor = if (low) lerp(pal.glow, Color(0xFFFF4A3A), 1f - remaining / 0.2f) else pal.glow
            val ringAlpha = if (low && (remaining * 40f).toInt() % 2 == 0) 0.45f else 1f
            drawArc(
                color = ringColor.copy(alpha = ringAlpha), startAngle = -90f, sweepAngle = 360f * remaining, useCenter = false,
                topLeft = Offset(c.x - (r - stroke), c.y - (r - stroke)), size = Size(2f * (r - stroke), 2f * (r - stroke)),
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
        }
    }

    // orbiting stars
    for (k in 0 until 5) {
        val ang = time * (0.6f + 0.18f * k) + k * 1.26f
        val orbit = r * (0.6f + 0.06f * k)
        val pos = Offset(c.x + orbit * cos(ang), c.y - r * 0.03f + orbit * 0.5f * sin(ang))
        val s = r * (0.02f + 0.004f * k)
        drawPath(starPath(pos, s, s * 0.32f, 4, time * 40f + k * 20f), pal.accent, alpha = 0.85f)
    }

    drawParticles(particles, pal)

    val box = r * (1.5f + 0.03f * breathe)
    val cy = c.y - r * 0.04f + sin(time * 1.4f) * r * 0.012f + tiltY * r * 0.03f
    val cx = c.x + tiltX * r * 0.03f
    drawArt(img, cx, cy, box * 1.06f, alpha = 0.22f + 0.12f * breathe, filter = ColorFilter.tint(pal.glow, BlendMode.SrcIn))
    drawArt(img, cx, cy, box)
    if (ascended) drawCircle(lerp(pal.gold, Color.White, 0.5f).copy(alpha = 0.5f + 0.3f * breathe), radius = box * 0.56f, center = Offset(cx, cy), style = Stroke(r * 0.012f))
}

/** Particles in the theme's light: stars, drifting starlight, and outward rays. */
fun DrawScope.drawParticles(particles: List<Particle>, pal: Palette) {
    for (p in particles) {
        val lifeFrac = (p.life / p.maxLife).coerceIn(0f, 1f)
        when (p.kind) {
            ParticleKind.Ember -> {
                val a = lifeFrac * 0.95f
                val o = Offset(p.x, p.y)
                drawCircle(pal.glow.copy(alpha = a * 0.3f), radius = p.size * 2.4f, center = o)
                drawPath(starPath(o, p.size * 1.6f, p.size * 0.45f, 4, p.seed * 90f), pal.accent, alpha = a)
            }
            ParticleKind.Mote -> {
                val a = lifeFrac * 0.55f * (0.6f + 0.4f * sin(p.seed * 40f + lifeFrac * 12f))
                drawCircle(lerp(pal.gold, pal.accent, p.seed).copy(alpha = a), radius = p.size, center = Offset(p.x, p.y))
            }
            ParticleKind.Shard -> {
                val len = p.size * 3f
                val speed = kotlin.math.sqrt(p.vx * p.vx + p.vy * p.vy).coerceAtLeast(1f)
                val dx = p.vx / speed * len
                val dy = p.vy / speed * len
                drawLine(pal.accent.copy(alpha = lifeFrac * 0.85f), Offset(p.x - dx, p.y - dy), Offset(p.x, p.y), strokeWidth = p.size * 0.4f, cap = StrokeCap.Round)
            }
        }
    }
}

/** The transformation flash: a white-gold bloom and an expanding star ring. */
fun DrawScope.drawFlash(pal: Palette, progress: Float, ascended: Boolean) {
    val f = progress.coerceIn(0f, 1f)
    val alpha = when {
        f < 0.2f -> f / 0.2f
        f < 0.5f -> 1f
        else -> Math.pow((1f - (f - 0.5f) / 0.5f).toDouble(), 1.5).toFloat()
    }
    val r = size.minDimension / 2f
    drawCircle(
        Brush.radialGradient(listOf(Color.White, pal.accent, pal.glow, pal.coreB), center = center, radius = r * 1.05f),
        radius = r, center = center, alpha = alpha,
    )
    val ringR = r * (0.15f + 1.1f * f)
    drawCircle(Color.White, radius = ringR, center = center, alpha = (1f - f) * 0.9f, style = Stroke(width = r * 0.06f * (1f - f) + 2f))
    drawOctagram(center, ringR * 0.8f, f * 45f, pal.gold, r * 0.02f * (1f - f) + 1f, (1f - f) * 0.9f)
    if (ascended) {
        val r2 = r * (0.05f + 0.8f * f)
        drawCircle(lerp(pal.gold, Color.White, 0.6f), radius = r2, center = center, alpha = (1f - f) * 0.7f, style = Stroke(width = r * 0.04f * (1f - f) + 1f))
    }
}
