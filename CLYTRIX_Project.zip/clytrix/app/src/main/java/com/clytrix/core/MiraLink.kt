package com.clytrix.core

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.google.android.gms.wearable.Wearable
import org.json.JSONObject

/**
 * The watch side of the optional MIRA AI COMPANION LINK.
 *
 * Transport: the Wear OS Data Layer (MessageClient). The Data Layer only delivers messages between
 * apps with the SAME package name and signing key, so Mira AI (a different app) can't talk to the
 * watch directly. It talks to the small "CLYTRIX Link" relay (the :link module, installed on the
 * phone with the same application id), which forwards requests here and replies back. See
 * docs/MIRA_INTEGRATION.md for the exact protocol Mira has to implement.
 *
 *   phone -> watch  path /clytrix/v1/request   {"v":1,"id":"..","type":"pair","code":"123456","client":"Mira AI"}
 *                                              {"v":1,"id":"..","type":"cmd","token":"..","cmd":"battery_status","args":{}}
 *   watch -> phone  path /clytrix/v1/reply     {"v":1,"id":"..","ok":true,"result":{..},"speech":".."}
 *                                              {"v":1,"id":"..","ok":false,"error":"permission_denied","message":".."}
 *
 * Security: pairing is user-initiated on the watch with a short-lived code; requests must come from
 * the paired phone node AND carry the issued token; each command is gated by the user's Control /
 * Data switches; requests are rate-limited; the whole link is OFF by default and every request is
 * refused while it's off. Nothing private is sent: no photos, no conversations, no form names
 * unless Data sharing is on (and then only the name of the form the request selected).
 *
 * Everything here is optional: CLYTRIX never waits on it and works identically when it's off.
 */
object MiraLink {
    const val REQUEST_PATH = "/clytrix/v1/request"
    const val REPLY_PATH = "/clytrix/v1/reply"
    private const val PREFS = "clytrix_mira"
    private const val TAG = "ClytrixMira"

    /** What the running app exposes to the link. Registered by MainActivity while it exists. */
    interface Host {
        fun batteryStatus(): JSONObject
        fun setPowerMode(mode: PowerMode)
        fun diagnosticsSummary(): JSONObject
        fun evolutionStatus(): JSONObject
        fun recommendations(): JSONObject
        fun openDial(): Boolean
        fun selectFavorite(): Alien?
        fun selectForm(name: String): Alien?
    }

    @Volatile private var host: Host? = null
    private val main = Handler(Looper.getMainLooper())
    private val limiter = MiraAuth.RateLimiter()
    private var session: MiraAuth.PairSession? = null

    // ---- observable state for Settings / Diagnostics ----------------------------------------------
    var enabled by mutableStateOf(false); private set
    var pairedClient by mutableStateOf<String?>(null); private set
    var pairedNode by mutableStateOf<String?>(null); private set
    var allowControl by mutableStateOf(false); private set
    var allowData by mutableStateOf(false); private set
    var spokenReports by mutableStateOf(true); private set
    var pairingCode by mutableStateOf<String?>(null); private set
    var pairingExpiresAt by mutableStateOf(0L); private set
    var lastSuccessAt by mutableStateOf(0L); private set
    var lastError by mutableStateOf<String?>(null); private set
    var requestsServed by mutableStateOf(0); private set
    var requestsRefused by mutableStateOf(0); private set

    private var tokenHash: String? = null
    private var loaded = false

    fun load(context: Context) {
        if (loaded) return
        val sp = prefs(context)
        enabled = sp.getBoolean("enabled", false)
        pairedClient = sp.getString("client", null)
        pairedNode = sp.getString("node", null)
        tokenHash = sp.getString("tokenHash", null)
        allowControl = sp.getBoolean("allowControl", false)
        allowData = sp.getBoolean("allowData", false)
        spokenReports = sp.getBoolean("spoken", true)
        lastSuccessAt = sp.getLong("lastSuccessAt", 0L)
        lastError = sp.getString("lastError", null)
        loaded = true
    }

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val isPaired: Boolean get() = tokenHash != null && pairedNode != null

    fun register(h: Host) { host = h }
    fun unregister(h: Host) { if (host === h) host = null }

    // ---- user actions (Settings > Mira AI Link) ------------------------------------------------------

    fun setEnabled(context: Context, on: Boolean) {
        enabled = on
        if (!on) { session = null; pairingCode = null }
        prefs(context).edit().putBoolean("enabled", on).apply()
    }

    fun setPermissions(context: Context, control: Boolean = allowControl, data: Boolean = allowData, spoken: Boolean = spokenReports) {
        allowControl = control; allowData = data; spokenReports = spoken
        prefs(context).edit().putBoolean("allowControl", control).putBoolean("allowData", data).putBoolean("spoken", spoken).apply()
    }

    @Synchronized
    fun startPairing(): String {
        val s = MiraAuth.newSession(System.currentTimeMillis())
        session = s
        pairingCode = s.code
        pairingExpiresAt = s.expiresAt
        return s.code
    }

    @Synchronized
    fun cancelPairing() { session = null; pairingCode = null }

    fun unpair(context: Context) {
        synchronized(this) { tokenHash = null; session = null }
        pairedClient = null; pairedNode = null; pairingCode = null
        prefs(context).edit().remove("tokenHash").remove("node").remove("client").apply()
        setPermissions(context, control = false, data = false)
    }

    // ---- incoming requests (called by MiraLinkService on a background thread) -------------------------

    fun handle(context: Context, sourceNodeId: String, path: String, data: ByteArray) {
        load(context)
        if (path != REQUEST_PATH) return
        val req = try {
            if (data.size > 4096) throw IllegalArgumentException("too large")
            JSONObject(String(data, Charsets.UTF_8))
        } catch (e: Exception) {
            refuse(context, sourceNodeId, "", "bad_request", "Unreadable request")
            return
        }
        val id = req.optString("id").take(64)
        if (req.optInt("v", 0) != 1) { refuse(context, sourceNodeId, id, "unsupported_version", "This CLYTRIX speaks link version 1"); return }
        if (!enabled) { refuse(context, sourceNodeId, id, "link_disabled", "The Mira AI link is switched off on the watch"); return }
        if (!synchronized(this) { limiter.tryAcquire(System.currentTimeMillis()) }) {
            refuse(context, sourceNodeId, id, "rate_limited", "Too many requests; try again in a minute"); return
        }
        when (req.optString("type")) {
            "pair" -> handlePair(context, sourceNodeId, id, req)
            "cmd" -> handleCommand(context, sourceNodeId, id, req)
            else -> refuse(context, sourceNodeId, id, "bad_request", "Unknown request type")
        }
    }

    private fun handlePair(context: Context, node: String, id: String, req: JSONObject) {
        val (result, keep) = synchronized(this) {
            val r = MiraAuth.attempt(session, req.optString("code"), System.currentTimeMillis())
            session = r.second
            r
        }
        main.post { if (keep == null) pairingCode = null }
        when (result) {
            is MiraAuth.PairResult.Paired -> {
                val client = BackupRules.cleanName(req.optString("client", "Mira AI")) ?: "Mira AI"
                synchronized(this) { tokenHash = result.tokenHash }
                prefs(context).edit().putString("tokenHash", result.tokenHash).putString("node", node)
                    .putString("client", client).putLong("pairedAt", System.currentTimeMillis()).apply()
                main.post { pairedNode = node; pairedClient = client }
                // New pairings start with Control and Data OFF; the user turns them on.
                setPermissionsQuiet(context)
                succeed(context, node, id, JSONObject().put("token", result.token).put("watch_app", "CLYTRIX"),
                    "CLYTRIX is paired. Turn on control and data sharing on the watch to use it.")
            }
            is MiraAuth.PairResult.WrongCode -> refuse(context, node, id, "wrong_code", "Wrong code; ${result.attemptsLeft} tries left")
            MiraAuth.PairResult.Expired -> refuse(context, node, id, "pairing_expired", "The pairing code expired; start pairing again on the watch")
            MiraAuth.PairResult.Locked -> refuse(context, node, id, "pairing_locked", "Too many wrong codes; start pairing again on the watch")
            MiraAuth.PairResult.NotPairing -> refuse(context, node, id, "not_pairing", "Start pairing on the watch first (Settings > Mira AI Link)")
        }
    }

    private fun setPermissionsQuiet(context: Context) {
        prefs(context).edit().putBoolean("allowControl", false).putBoolean("allowData", false).apply()
        main.post { allowControl = false; allowData = false }
    }

    private fun handleCommand(context: Context, node: String, id: String, req: JSONObject) {
        val ok = synchronized(this) { MiraAuth.verify(tokenHash, pairedNode, req.optString("token"), node) }
        if (!ok) { refuse(context, node, id, "unauthorized", "This device isn't paired with CLYTRIX"); return }
        val cmd = req.optString("cmd")
        if (cmd !in MiraAuth.COMMANDS) { refuse(context, node, id, "unknown_command", "Unknown command"); return }
        if (!MiraAuth.permitted(cmd, allowControl, allowData)) {
            val which = if (MiraAuth.COMMANDS[cmd] == MiraAuth.Perm.Control) "control" else "data sharing"
            refuse(context, node, id, "permission_denied", "Allow $which for Mira in CLYTRIX settings on the watch")
            return
        }
        val args = req.optJSONObject("args") ?: JSONObject()
        // Host calls touch app state, so they run on the main thread; replies are async anyway.
        main.post {
            try {
                val h = host
                when (cmd) {
                    "ping" -> succeed(context, node, id, JSONObject().put("app", "CLYTRIX").put("link", 1).put("app_open", h != null), "CLYTRIX is connected.")
                    "battery_status" -> {
                        val r = h?.batteryStatus() ?: snapshot(context).put("stale", true)
                        succeed(context, node, id, r, r.optString("speech_text"))
                    }
                    "diagnostics_summary" -> {
                        val r = h?.diagnosticsSummary() ?: return@post refuse(context, node, id, "app_not_open", "Open CLYTRIX on the watch for live diagnostics")
                        succeed(context, node, id, r, r.optString("speech_text"))
                    }
                    "evolution_status" -> {
                        val r = h?.evolutionStatus() ?: return@post refuse(context, node, id, "app_not_open", "Open CLYTRIX on the watch")
                        succeed(context, node, id, r, r.optString("speech_text"))
                    }
                    "recommendations" -> {
                        val r = h?.recommendations() ?: return@post refuse(context, node, id, "app_not_open", "Open CLYTRIX on the watch")
                        succeed(context, node, id, r, r.optString("speech_text"))
                    }
                    "set_power_mode" -> {
                        val mode = parseMode(args.optString("mode"))
                            ?: return@post refuse(context, node, id, "bad_args", "mode must be performance, balanced, ultra or adaptive")
                        if (h != null) h.setPowerMode(mode) else writeModeOffline(context, mode)
                        succeed(context, node, id, JSONObject().put("power_mode", mode.name), "${mode.label} is on.")
                    }
                    "open_dial" -> {
                        if (h == null) return@post refuse(context, node, id, "app_not_open", "Open CLYTRIX on the watch first")
                        if (h.openDial()) succeed(context, node, id, JSONObject(), "The dial is open.")
                        else refuse(context, node, id, "empty_roster", "There are no forms in the roster yet")
                    }
                    "select_favorite" -> {
                        if (h == null) return@post refuse(context, node, id, "app_not_open", "Open CLYTRIX on the watch first")
                        val a = h.selectFavorite() ?: return@post refuse(context, node, id, "no_favorite", "No favorite form is available right now")
                        succeed(context, node, id, selectedJson(a), "Your favorite form is selected. Activate it on the watch.")
                    }
                    "select_form" -> {
                        if (h == null) return@post refuse(context, node, id, "app_not_open", "Open CLYTRIX on the watch first")
                        val a = h.selectForm(args.optString("name").take(40))
                            ?: return@post refuse(context, node, id, "not_found", "No form with that name is available right now")
                        succeed(context, node, id, selectedJson(a), "Form selected. Activate it on the watch.")
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Command $cmd failed", e)
                refuse(context, node, id, "internal_error", "CLYTRIX couldn't complete that")
            }
        }
    }

    /** Selection never transforms remotely: the user confirms on the watch itself. */
    private fun selectedJson(a: Alien) = JSONObject().put("selected", true).apply {
        if (allowData) put("name", a.name)
    }

    private fun parseMode(s: String): PowerMode? = when (s.lowercase()) {
        "performance" -> PowerMode.Performance
        "balanced" -> PowerMode.Balanced
        "ultra", "ultra_saver", "ultra battery saver" -> PowerMode.UltraSaver
        "adaptive", "adaptive_ai" -> PowerMode.Adaptive
        else -> null
    }

    /** With the app closed, a mode change is written where Settings reads it on next launch. */
    private fun writeModeOffline(context: Context, mode: PowerMode) {
        context.applicationContext.getSharedPreferences(Settings.PREFS, Context.MODE_PRIVATE)
            .edit().putInt("powerMode", mode.ordinal).apply()
    }

    // ---- status snapshot for when the app isn't running -----------------------------------------------

    fun saveSnapshot(context: Context, status: JSONObject) {
        prefs(context).edit().putString("snapshot", status.toString()).putLong("snapshotAt", System.currentTimeMillis()).apply()
    }

    private fun snapshot(context: Context): JSONObject {
        val sp = prefs(context)
        val o = runCatching { JSONObject(sp.getString("snapshot", "{}") ?: "{}") }.getOrDefault(JSONObject())
        return o.put("snapshot_at", sp.getLong("snapshotAt", 0L))
    }

    // ---- replies ------------------------------------------------------------------------------------

    private fun succeed(context: Context, node: String, id: String, result: JSONObject, speech: String?) {
        result.remove("speech_text")
        val reply = JSONObject().put("v", 1).put("id", id).put("ok", true).put("result", result)
        if (spokenReports && !speech.isNullOrBlank()) reply.put("speech", speech)
        send(context, node, reply, success = true)
    }

    private fun refuse(context: Context, node: String, id: String, code: String, message: String) {
        val reply = JSONObject().put("v", 1).put("id", id).put("ok", false).put("error", code).put("message", message)
        send(context, node, reply, success = false, errorCode = code)
    }

    private fun send(context: Context, node: String, reply: JSONObject, success: Boolean, errorCode: String? = null) {
        val bytes = reply.toString().toByteArray(Charsets.UTF_8)
        try {
            Wearable.getMessageClient(context.applicationContext)
                .sendMessage(node, REPLY_PATH, bytes)
                .addOnSuccessListener { main.post { if (success) noteSuccess(context) else noteRefused(context, errorCode) } }
                .addOnFailureListener { e -> main.post { noteError(context, "Reply failed: ${e.javaClass.simpleName}") } }
        } catch (e: Throwable) {
            main.post { noteError(context, "Data Layer unavailable: ${e.javaClass.simpleName}") }
        }
    }

    private fun noteSuccess(context: Context) {
        requestsServed += 1
        lastSuccessAt = System.currentTimeMillis()
        prefs(context).edit().putLong("lastSuccessAt", lastSuccessAt).apply()
    }

    private fun noteRefused(context: Context, code: String?) {
        requestsRefused += 1
        if (code != null && code != "rate_limited") noteError(context, "Refused: $code")
    }

    private fun noteError(context: Context, msg: String) {
        lastError = "$msg (${java.text.SimpleDateFormat("MMM d HH:mm", java.util.Locale.getDefault()).format(java.util.Date())})"
        prefs(context).edit().putString("lastError", lastError).apply()
    }

    /**
     * Checks, without sending anything to Mira, whether the paired phone is currently reachable over
     * the Data Layer. [callback] gets true/false, or null when not paired / not checkable.
     */
    fun checkReachable(context: Context, callback: (Boolean?) -> Unit) {
        val node = pairedNode ?: return callback(null)
        try {
            Wearable.getNodeClient(context.applicationContext).connectedNodes
                .addOnSuccessListener { nodes -> main.post { callback(nodes.any { it.id == node }) } }
                .addOnFailureListener { main.post { callback(false) } }
        } catch (e: Throwable) {
            callback(null)
        }
    }
}
