package com.clytrix.core

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64

/**
 * Authentication and permission rules for the optional Mira AI link, free of Android so they're
 * unit-tested on the JVM (MiraAuthTest). [MiraLink] wires them to the Data Layer and storage.
 *
 * Model:
 *  1. Pairing is started ON THE WATCH by the user. It shows a 6-digit code for [PAIR_WINDOW_MS].
 *  2. Mira (through the CLYTRIX Link relay on the phone) sends that code. A correct code within
 *     the window, from one node, issues a 256-bit random token. Wrong codes count; after
 *     [MAX_ATTEMPTS] the session is cancelled.
 *  3. The watch stores only SHA-256(token) and the phone's node id. Every later request must come
 *     from that node AND carry the token (compared in constant time).
 *  4. What a paired client may do is limited by the user's own switches: [Perm.Control] (change
 *     mode, point the dial at a form) and [Perm.Data] (battery/diagnostics/Evolution summaries).
 *     Both are OFF after pairing until the user turns them on. `ping` needs neither.
 *  5. At most [RATE_LIMIT] requests per [RATE_WINDOW_MS] are served.
 */
object MiraAuth {
    const val PAIR_WINDOW_MS = 120_000L
    const val MAX_ATTEMPTS = 5
    const val RATE_LIMIT = 30
    const val RATE_WINDOW_MS = 60_000L

    enum class Perm { None, Control, Data }

    /** Which permission each command needs. Unknown commands are rejected before this is asked. */
    val COMMANDS: Map<String, Perm> = mapOf(
        "ping" to Perm.None,
        "battery_status" to Perm.Data,
        "diagnostics_summary" to Perm.Data,
        "evolution_status" to Perm.Data,
        "recommendations" to Perm.Data,
        "set_power_mode" to Perm.Control,
        "open_dial" to Perm.Control,
        "select_favorite" to Perm.Control,
        "select_form" to Perm.Control,
    )

    data class PairSession(val code: String, val expiresAt: Long, val attempts: Int = 0)

    sealed class PairResult {
        data class Paired(val token: String, val tokenHash: String) : PairResult()
        data class WrongCode(val attemptsLeft: Int) : PairResult()
        object NotPairing : PairResult()
        object Expired : PairResult()
        object Locked : PairResult()
    }

    private val random = SecureRandom()

    fun newSession(now: Long, rnd: SecureRandom = random): PairSession =
        PairSession(code = (rnd.nextInt(900_000) + 100_000).toString(), expiresAt = now + PAIR_WINDOW_MS)

    /**
     * Checks a pairing attempt. Returns the result plus the session to keep (null = session over).
     */
    fun attempt(session: PairSession?, offered: String, now: Long, rnd: SecureRandom = random): Pair<PairResult, PairSession?> {
        if (session == null) return PairResult.NotPairing to null
        if (now > session.expiresAt) return PairResult.Expired to null
        if (session.attempts >= MAX_ATTEMPTS) return PairResult.Locked to null
        if (constantTimeEquals(session.code, offered.trim())) {
            val bytes = ByteArray(32).also { rnd.nextBytes(it) }
            val token = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
            return PairResult.Paired(token, hash(token)) to null
        }
        val next = session.copy(attempts = session.attempts + 1)
        if (next.attempts >= MAX_ATTEMPTS) return PairResult.Locked to null
        return PairResult.WrongCode(MAX_ATTEMPTS - next.attempts) to next
    }

    fun hash(token: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(token.toByteArray(Charsets.UTF_8))
        return d.joinToString("") { "%02x".format(it) }
    }

    /** True when [token] from [nodeId] matches the stored pairing. Constant-time on the hash. */
    fun verify(storedHash: String?, storedNode: String?, token: String?, nodeId: String): Boolean {
        if (storedHash.isNullOrEmpty() || storedNode.isNullOrEmpty() || token.isNullOrEmpty()) return false
        if (storedNode != nodeId) return false
        return constantTimeEquals(storedHash, hash(token))
    }

    fun constantTimeEquals(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))

    /** Whether a command is allowed under the user's current permission switches. */
    fun permitted(command: String, allowControl: Boolean, allowData: Boolean): Boolean =
        when (COMMANDS[command]) {
            Perm.None -> true
            Perm.Control -> allowControl
            Perm.Data -> allowData
            null -> false
        }

    /** Sliding-window rate limiter. Not thread-safe by itself; callers synchronize. */
    class RateLimiter(private val limit: Int = RATE_LIMIT, private val windowMs: Long = RATE_WINDOW_MS) {
        private val times = ArrayDeque<Long>()
        fun tryAcquire(now: Long): Boolean {
            while (times.isNotEmpty() && now - times.first() >= windowMs) times.removeFirst()
            if (times.size >= limit) return false
            times.addLast(now)
            return true
        }
    }
}
