package com.clytrix.core

import androidx.annotation.DrawableRes

/** Where a form's artwork comes from: a photo the user picked, copied into private storage. */
sealed class ImageSource {
    data class Bundled(@DrawableRes val resId: Int) : ImageSource()
    data class Custom(val fileName: String) : ImageSource()
}

/**
 * Optional, purely aesthetic celestial categories a user can tag a form with. They change nothing
 * about how a transformation behaves; they're shown on the dial and used for sorting/filtering.
 */
enum class Classification(val label: String, val glyph: String) {
    Radiant("Radiant", "✶"),
    Astral("Astral", "✧"),
    Guardian("Guardian", "⛨"),
    Tempest("Tempest", "≋"),
    Eclipse("Eclipse", "◐"),
    Eternal("Eternal", "∞");

    companion object {
        fun fromName(name: String?): Classification? = values().firstOrNull { it.name == name }
    }
}

/**
 * One transformation form in the user's own roster. (The class keeps Apexium's internal name,
 * `Alien`, so the proven roster/backup/crash-recovery code paths it flows through are unchanged;
 * everything user-facing calls it a "form".)
 *
 * [apex] is Apexium's per-form "evolved variant" flag, carried over unchanged. In CLYTRIX it is
 * presented as an "Ascended" form: with Ascension Mode switched on (see [Settings.ascensionOn]),
 * transforming into it uses the Ascension visuals, sound and haptics instead of the standard ones.
 */
data class Alien(
    val id: String,
    val name: String,
    val source: ImageSource,
    val apex: Boolean = false,
    val favorite: Boolean = false,
    val classification: Classification? = null,
)
