package com.clytrix.core.ui

import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * What a particle is, so the draw code can style it without the field knowing about Canvas.
 * CLYTRIX draws [Ember] as a four-point star of light, [Mote] as drifting starlight, and [Shard]
 * as a short ray streaking outward.
 */
enum class ParticleKind { Ember, Mote, Shard }

data class Particle(
    var x: Float, var y: Float,
    var vx: Float, var vy: Float,
    var life: Float, val maxLife: Float,
    var size: Float,
    val kind: ParticleKind,
    val seed: Float,
)

/**
 * A tiny, dependency-free particle simulation driven once per frame from [update]. Deliberately
 * plain Kotlin (no Compose state) -- it's advanced by the frame clock in [CoreScreen], so the Canvas reads a consistent snapshot each frame
 * without the field itself ever touching Compose state (which would be unsafe from inside a draw
 * block; see the same lesson learned in [Art]).
 */
class ParticleField(private val random: Random = Random(System.nanoTime())) {
    private val list = ArrayList<Particle>()

    val particles: List<Particle> get() = list

    fun update(dtSeconds: Float, dragX: Float = 0f, dragY: Float = 0f) {
        val it = list.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.life -= dtSeconds
            if (p.life <= 0f) { it.remove(); continue }
            p.x += (p.vx + dragX) * dtSeconds
            p.y += (p.vy + dragY) * dtSeconds
            // gentle drag so ambient motes drift rather than fly straight forever
            p.vx *= (1f - 0.35f * dtSeconds).coerceIn(0f, 1f)
            p.vy *= (1f - 0.35f * dtSeconds).coerceIn(0f, 1f)
        }
        if (list.size > MAX_PARTICLES) {
            // Oldest-first trim keeps a runaway spawn burst from ever growing the list unbounded.
            while (list.size > MAX_PARTICLES) list.removeAt(0)
        }
    }

    /**
     * A radial burst of stars, used on transform -- [strength] scales count and speed, [density]
     * (from the active power profile x animation intensity) scales the count only.
     */
    fun spawnBurst(cx: Float, cy: Float, radius: Float, strength: Float = 1f, density: Float = 1f) {
        val count = ((14 + 10 * strength) * density).toInt()
        repeat(count) {
            val a = random.nextFloat() * (2f * Math.PI.toFloat())
            val speed = radius * (0.9f + 1.6f * strength) * (0.5f + random.nextFloat())
            list.add(
                Particle(
                    x = cx, y = cy,
                    vx = cos(a) * speed, vy = sin(a) * speed,
                    life = 0.5f + random.nextFloat() * 0.6f, maxLife = 1.1f,
                    size = radius * (0.02f + random.nextFloat() * 0.03f),
                    kind = ParticleKind.Ember, seed = random.nextFloat(),
                ),
            )
        }
    }

    /** One slow-drifting mote, spawned at a low rate while the dial is idle/selecting. */
    fun spawnAmbientMote(cx: Float, cy: Float, radius: Float) {
        val a = random.nextFloat() * (2f * Math.PI.toFloat())
        val dist = radius * (0.3f + random.nextFloat() * 0.9f)
        list.add(
            Particle(
                x = cx + cos(a) * dist, y = cy + sin(a) * dist,
                vx = cos(a + 1.5f) * radius * 0.06f, vy = sin(a + 1.5f) * radius * 0.06f,
                life = 2.5f + random.nextFloat() * 2f, maxLife = 4.5f,
                size = radius * (0.006f + random.nextFloat() * 0.01f),
                kind = ParticleKind.Mote, seed = random.nextFloat(),
            ),
        )
    }

    /** A handful of light rays that streak outward, used for the shockwave burst. */
    fun spawnShards(cx: Float, cy: Float, radius: Float, strength: Float = 1f, density: Float = 1f) {
        repeat(((5 + 3 * strength) * density).toInt()) {
            val a = random.nextFloat() * (2f * Math.PI.toFloat())
            val speed = radius * (1.2f + 1.0f * strength)
            list.add(
                Particle(
                    x = cx, y = cy,
                    vx = cos(a) * speed, vy = sin(a) * speed,
                    life = 0.35f + random.nextFloat() * 0.35f, maxLife = 0.7f,
                    size = radius * (0.03f + random.nextFloat() * 0.035f),
                    kind = ParticleKind.Shard, seed = random.nextFloat(),
                ),
            )
        }
    }

    fun clear() = list.clear()

    private companion object {
        const val MAX_PARTICLES = 220
    }
}
