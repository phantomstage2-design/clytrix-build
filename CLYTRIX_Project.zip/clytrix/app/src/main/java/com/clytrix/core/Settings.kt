package com.clytrix.core

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Colour themes for the device. [Emerald] (radiant emerald + celestial gold) is the default. */
enum class Skin(val label: String) {
    Emerald("Radiant Emerald"), Gold("Celestial Gold"), Sapphire("Astral Sapphire"),
    Amethyst("Eclipse Amethyst"), Aurora("Aurora Teal"), Seraph("Seraph Rose"),
    Ember("Solar Ember"), Lunar("Lunar Silver"),
}

enum class SortMode(val label: String) {
    Default("Custom order"), Alphabetical("A to Z"), MostUsed("Most used"), FavoritesFirst("Favorites first"),
}

/** Which synthesized sound set plays. Celestial is new for CLYTRIX; Classic is Apexium's set. */
enum class VoiceSet(val label: String) { Celestial("Celestial"), Classic("Classic machine") }

/** What arms a transformation while selecting. Long press makes accidental taps harmless. */
enum class Activation(val label: String) { Tap("Tap"), LongPress("Long press") }

/**
 * All user preferences plus the user's own form roster. Every field is Compose snapshot state, so
 * UI reading them recomposes automatically, and every setter persists to SharedPreferences.
 *
 * Carried over from Apexium (same safe-read pattern: a corrupted or wrong-typed preference falls
 * back to its default and is cleared, instead of crashing on launch), with CLYTRIX's additions:
 * the four-mode power system, Ascension Mode, sound set/volume/silent-mode, haptic and animation
 * intensity, activation gesture and gesture sensitivity, favourites, classifications, reordering,
 * and whitelisted settings export/import for backups.
 *
 * Stored under "clytrix_settings" -- nothing is shared with an installed Apexium.
 */
class Settings(
    context: Context,
    private val customAliens: CustomAliens,
    val adaptiveTuner: AdaptiveTuner,
    val progress: Progress,
) {
    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun safeInt(key: String, default: Int): Int =
        try { sp.getInt(key, default) } catch (e: ClassCastException) { sp.edit().remove(key).apply(); default }
    private fun safeBool(key: String, default: Boolean): Boolean =
        try { sp.getBoolean(key, default) } catch (e: ClassCastException) { sp.edit().remove(key).apply(); default }
    private fun safeString(key: String, default: String?): String? =
        try { sp.getString(key, default) } catch (e: ClassCastException) { sp.edit().remove(key).apply(); default }
    private fun safeStringSet(key: String): Set<String>? =
        try { sp.getStringSet(key, null)?.toSet() } catch (e: ClassCastException) { sp.edit().remove(key).apply(); null }
    private inline fun <reified E : Enum<E>> safeEnum(key: String, default: E): E =
        enumValues<E>().getOrElse(safeInt(key, default.ordinal)) { default }

    // ---- Transformation --------------------------------------------------------------------------
    var activation by mutableStateOf(Activation.Tap); private set
    /** 0 = no time limit (the CLYTRIX default -- no mandatory transformation timer). */
    var durationSec by mutableStateOf(0); private set
    var bezelClicks by mutableStateOf(1); private set
    /** Drag/long-press sensitivity: 0 = low (needs more deliberate input), 1 = normal, 2 = high. */
    var gestureSensitivity by mutableStateOf(1); private set
    var slapOn by mutableStateOf(false); private set
    var slapForce by mutableStateOf(1); private set
    var parallaxOn by mutableStateOf(true); private set
    var disguiseOn by mutableStateOf(false); private set
    var sort by mutableStateOf(SortMode.Default); private set
    var ascensionOn by mutableStateOf(true); private set
    /** Only usable once [Progress.overdriveUnlocked]; the user still opts in explicitly. */
    var overdriveOn by mutableStateOf(false); private set
    var smartTuningOn by mutableStateOf(true); private set

    // ---- Visual ------------------------------------------------------------------------------------
    var skin by mutableStateOf(Skin.Emerald); private set
    /** 0 = subtle, 1 = standard, 2 = radiant. Scales glow strength and particle counts. */
    var animationIntensity by mutableStateOf(1); private set
    var particlesOn by mutableStateOf(true); private set
    var crtOn by mutableStateOf(false); private set
    var showNames by mutableStateOf(true); private set
    var stayAwake by mutableStateOf(true); private set

    // ---- Sound and haptics ---------------------------------------------------------------------------
    var soundOn by mutableStateOf(true); private set
    var voiceSet by mutableStateOf(VoiceSet.Celestial); private set
    /** 0..100, applied to every effect and (scaled) to the ambient hum. */
    var effectsVolume by mutableStateOf(80); private set
    var ambientHumOn by mutableStateOf(true); private set
    var respectSilent by mutableStateOf(true); private set
    var hapticsOn by mutableStateOf(true); private set
    /** 0 = light, 1 = medium, 2 = strong. */
    var hapticIntensity by mutableStateOf(1); private set

    // ---- Battery and performance ---------------------------------------------------------------------
    var powerMode by mutableStateOf(PowerMode.Adaptive); private set
    /** Adaptive mode never goes MORE capable than this rank (0 = Performance). */
    var adaptiveCeiling by mutableStateOf(0); private set
    /** Adaptive mode never goes LESS capable than this rank (2 = Ultra). */
    var adaptiveFloor by mutableStateOf(2); private set
    /** Master switch for the Evolution Core (auto-adjustments and self-healing). Off = observe only. */
    var adaptiveCoreOn by mutableStateOf(true); private set

    /** Runtime only: the profile in force right now. Only [AdaptiveCore] writes this. */
    var activeProfile by mutableStateOf(Profile.Balanced); internal set
    /** Runtime only: plain-language reason for [activeProfile]. */
    var profileReason by mutableStateOf("Starting up"); internal set
    /** Runtime only: a short banner shown on the dial when the profile changed by itself. */
    var profileNotice by mutableStateOf<String?>(null); internal set
    /** Runtime only: Evolution Core's particle-density trim (0.4..1.0); see EvolutionCore. */
    var evoParticleScale by mutableFloatStateOf(1f); internal set

    /** Kept from Apexium: true while the lightest profile is in force. */
    val batterySaverActive: Boolean get() = activeProfile == Profile.Ultra

    private val intensityScale: Float get() = when (animationIntensity) { 0 -> 0.6f; 2 -> 1.35f; else -> 1f }
    val glowIntensity: Float get() = when (animationIntensity) { 0 -> 0.75f; 2 -> 1.2f; else -> 1f }

    /** What rendering/audio/sensors should actually do this frame: user setting x profile. */
    val particleDensity: Float get() = activeProfile.particleDensity * evoParticleScale * intensityScale
    val effectiveParticlesOn: Boolean get() = particlesOn && particleDensity > 0.01f
    val effectiveParallaxOn: Boolean get() = parallaxOn && activeProfile.decorAllowed
    val effectiveCrtOn: Boolean get() = crtOn && activeProfile.decorAllowed
    val effectiveHumOn: Boolean get() = ambientHumOn && activeProfile.humAllowed
    val hapticScale: Float get() = activeProfile.hapticScale * when (hapticIntensity) { 0 -> 0.55f; 2 -> 1.0f; else -> 0.8f }

    /** Drag distance (px) per roster step, and the hold time for a long press. */
    val dragStepPx: Float get() = when (gestureSensitivity) { 0 -> 72f; 2 -> 42f; else -> 56f }
    val longPressMs: Long get() = when (gestureSensitivity) { 0 -> 600L; 2 -> 360L; else -> 450L }

    /** Slap threshold in m/s^2 of linear acceleration. */
    val slapThreshold: Float get() = when (slapForce) { 0 -> 14f; 2 -> 28f; else -> 20f }

    // ---- roster + usage --------------------------------------------------------------------------------
    var aliens by mutableStateOf(customAliens.loadAll()); private set
    private var disabledIds by mutableStateOf<Set<String>>(emptySet())
    var usage by mutableStateOf<Map<String, Int>>(emptyMap()); private set
    /** Set once, after a crash, if this launch auto-disabled a form that caused it. Dismissible. */
    var recoveryNotice by mutableStateOf<String?>(null); private set

    init { loadFromPrefs() }

    private fun loadFromPrefs() {
        activation = safeEnum("activation", Activation.Tap)
        durationSec = safeInt("durationSec", 0).let { if (it in DURATIONS) it else 0 }
        bezelClicks = safeInt("bezelClicks", 1).coerceIn(1, 4)
        gestureSensitivity = safeInt("gestureSensitivity", 1).coerceIn(0, 2)
        slapOn = safeBool("slapOn", false)
        slapForce = safeInt("slapForce", 1).coerceIn(0, 2)
        parallaxOn = safeBool("parallaxOn", true)
        disguiseOn = safeBool("disguiseOn", false)
        sort = safeEnum("sort", SortMode.Default)
        ascensionOn = safeBool("ascensionOn", true)
        overdriveOn = safeBool("overdriveOn", false)
        smartTuningOn = safeBool("smartTuningOn", true)
        skin = safeEnum("skin", Skin.Emerald)
        animationIntensity = safeInt("animationIntensity", 1).coerceIn(0, 2)
        particlesOn = safeBool("particlesOn", true)
        crtOn = safeBool("crtOn", false)
        showNames = safeBool("showNames", true)
        stayAwake = safeBool("stayAwake", true)
        soundOn = safeBool("soundOn", true)
        voiceSet = safeEnum("voiceSet", VoiceSet.Celestial)
        effectsVolume = safeInt("effectsVolume", 80).coerceIn(0, 100)
        ambientHumOn = safeBool("ambientHumOn", true)
        respectSilent = safeBool("respectSilent", true)
        hapticsOn = safeBool("hapticsOn", true)
        hapticIntensity = safeInt("hapticIntensity", 1).coerceIn(0, 2)
        powerMode = safeEnum("powerMode", PowerMode.Adaptive)
        adaptiveCeiling = safeInt("adaptiveCeiling", 0).coerceIn(0, 2)
        adaptiveFloor = safeInt("adaptiveFloor", 2).coerceIn(adaptiveCeiling, 2)
        adaptiveCoreOn = safeBool("adaptiveCoreOn", true)
        disabledIds = safeStringSet("disabledIds") ?: emptySet()
        usage = parseUsage(safeString("usage", "") ?: "")
        recoveryNotice = safeString("recoveryNotice", null)
    }

    private fun putBool(key: String, v: Boolean) = sp.edit().putBoolean(key, v).apply()
    private fun putInt(key: String, v: Int) = sp.edit().putInt(key, v).apply()

    // ---- setters ----
    fun updateActivation(v: Activation) { activation = v; putInt("activation", v.ordinal) }
    fun updateDurationSec(v: Int) { durationSec = if (v in DURATIONS) v else 0; putInt("durationSec", durationSec) }
    fun updateBezelClicks(v: Int) { bezelClicks = v.coerceIn(1, 4); putInt("bezelClicks", bezelClicks) }
    fun updateGestureSensitivity(v: Int) { gestureSensitivity = v.coerceIn(0, 2); putInt("gestureSensitivity", gestureSensitivity) }
    fun updateSlapOn(v: Boolean) { slapOn = v; putBool("slapOn", v) }
    fun updateSlapForce(v: Int) { slapForce = v.coerceIn(0, 2); putInt("slapForce", slapForce) }
    fun updateParallaxOn(v: Boolean) { parallaxOn = v; putBool("parallaxOn", v) }
    fun updateDisguiseOn(v: Boolean) { disguiseOn = v; putBool("disguiseOn", v) }
    fun updateSort(v: SortMode) { sort = v; putInt("sort", v.ordinal) }
    fun updateAscensionOn(v: Boolean) { ascensionOn = v; putBool("ascensionOn", v) }
    fun updateOverdriveOn(v: Boolean) {
        if (v && !progress.overdriveUnlocked) return
        overdriveOn = v; putBool("overdriveOn", v)
    }
    fun updateSmartTuningOn(v: Boolean) { smartTuningOn = v; putBool("smartTuningOn", v) }
    fun updateSkin(v: Skin) { skin = v; putInt("skin", v.ordinal) }
    fun updateAnimationIntensity(v: Int) { animationIntensity = v.coerceIn(0, 2); putInt("animationIntensity", animationIntensity) }
    fun updateParticlesOn(v: Boolean) { particlesOn = v; putBool("particlesOn", v) }
    fun updateCrtOn(v: Boolean) { crtOn = v; putBool("crtOn", v) }
    fun updateShowNames(v: Boolean) { showNames = v; putBool("showNames", v) }
    fun updateStayAwake(v: Boolean) { stayAwake = v; putBool("stayAwake", v) }
    fun updateSoundOn(v: Boolean) { soundOn = v; putBool("soundOn", v) }
    fun updateVoiceSet(v: VoiceSet) { voiceSet = v; putInt("voiceSet", v.ordinal) }
    fun updateEffectsVolume(v: Int) { effectsVolume = v.coerceIn(0, 100); putInt("effectsVolume", effectsVolume) }
    fun updateAmbientHumOn(v: Boolean) { ambientHumOn = v; putBool("ambientHumOn", v) }
    fun updateRespectSilent(v: Boolean) { respectSilent = v; putBool("respectSilent", v) }
    fun updateHapticsOn(v: Boolean) { hapticsOn = v; putBool("hapticsOn", v) }
    fun updateHapticIntensity(v: Int) { hapticIntensity = v.coerceIn(0, 2); putInt("hapticIntensity", hapticIntensity) }
    fun updatePowerMode(v: PowerMode) { powerMode = v; putInt("powerMode", v.ordinal) }
    fun updateAdaptiveLimits(ceiling: Int, floor: Int) {
        adaptiveCeiling = ceiling.coerceIn(0, 2)
        adaptiveFloor = floor.coerceIn(adaptiveCeiling, 2)
        sp.edit().putInt("adaptiveCeiling", adaptiveCeiling).putInt("adaptiveFloor", adaptiveFloor).apply()
    }
    fun updateAdaptiveCoreOn(v: Boolean) { adaptiveCoreOn = v; putBool("adaptiveCoreOn", v) }

    /** Ascension presentation applies to a form only when it's flagged AND the mode is on. */
    fun isAscended(alien: Alien?): Boolean = alien != null && alien.apex && ascensionOn

    // ---- the user's own roster -----------------------------------------------------------------------

    private fun refreshAliens() { aliens = customAliens.loadAll() }

    suspend fun addAlien(uri: Uri, name: String): Alien? {
        val alien = withContext(Dispatchers.IO) { customAliens.add(uri, name) } ?: return null
        refreshAliens()
        return alien
    }

    fun renameAlien(alien: Alien, newName: String) { customAliens.rename(alien.id, newName); refreshAliens() }
    fun setApex(alien: Alien, apex: Boolean) { customAliens.setApex(alien.id, apex); refreshAliens() }
    fun setFavorite(alien: Alien, fav: Boolean) { customAliens.setFavorite(alien.id, fav); refreshAliens() }
    fun setClassification(alien: Alien, c: Classification?) { customAliens.setClassification(alien.id, c); refreshAliens() }
    fun moveAlien(alien: Alien, delta: Int) { customAliens.move(alien.id, delta); refreshAliens() }

    fun removeAlien(alien: Alien) {
        customAliens.remove(alien.id)
        setDisabled(disabledIds - alien.id)
        refreshAliens()
    }

    fun isEnabled(alien: Alien) = alien.id !in disabledIds

    /** Toggle a form in the roster; at least one stays enabled whenever more than one exists. */
    fun toggleEnabled(alien: Alien) {
        val enabledCount = aliens.count { it.id !in disabledIds }
        if (alien.id in disabledIds) {
            setDisabled(disabledIds - alien.id)
        } else {
            if (enabledCount <= 1) return
            setDisabled(disabledIds + alien.id)
        }
    }

    /**
     * Self-healing (from Apexium): called when a form's photo fails to decode. It's switched off
     * automatically (never deleted) and a one-time, dismissible note explains what happened.
     */
    fun quarantineAlien(id: String) {
        val alien = aliens.find { it.id == id } ?: return
        val enabledCount = aliens.count { it.id !in disabledIds }
        if (id !in disabledIds && enabledCount > 1) setDisabled(disabledIds + id)
        val msg = "Turned off “${alien.name}” after a problem loading it. You can switch it back on, or remove it, in the roster."
        recoveryNotice = msg
        sp.edit().putString("recoveryNotice", msg).apply()
    }

    fun dismissRecoveryNotice() {
        recoveryNotice = null
        sp.edit().remove("recoveryNotice").apply()
    }

    private fun setDisabled(next: Set<String>) {
        disabledIds = next
        sp.edit().putStringSet("disabledIds", next).apply()
    }

    fun recordUse(alien: Alien) {
        val next = usage + (alien.id to ((usage[alien.id] ?: 0) + 1))
        usage = next
        sp.edit().putString("usage", serializeUsage(next)).apply()
    }

    /** The forms the dial cycles through: your own roster, minus anything switched off, sorted. */
    fun roster(): List<Alien> {
        val enabled = aliens.filter { it.id !in disabledIds }
        val list = enabled.ifEmpty { aliens }
        return when (sort) {
            SortMode.Default -> list
            SortMode.Alphabetical -> list.sortedBy { it.name.lowercase() }
            SortMode.MostUsed -> list.sortedByDescending { usage[it.id] ?: 0 }
            SortMode.FavoritesFirst -> list.sortedByDescending { it.favorite } // stable: keeps custom order within
        }
    }

    // ---- backup / restore --------------------------------------------------------------------------

    fun exportBackup(context: Context): java.io.File? = Backup.exportZip(context, customAliens, this)

    fun importBackup(context: Context, uri: Uri): Backup.ImportResult {
        val result = Backup.importZip(context, customAliens, this, uri)
        refreshAliens()
        return result
    }

    /** Whitelisted, type-checked preferences for a backup. No runtime state, no roster data. */
    fun exportPrefs(): JSONObject {
        val o = JSONObject()
        for (spec in PREF_SPECS) {
            if (!sp.contains(spec.key)) continue
            when (spec) {
                is PrefSpec.B -> o.put(spec.key, safeBool(spec.key, false))
                is PrefSpec.I -> o.put(spec.key, safeInt(spec.key, spec.min))
            }
        }
        return o
    }

    /** Applies preferences from a backup: unknown keys, wrong types and out-of-range values are
     *  ignored one by one rather than failing the whole restore. Returns how many were applied. */
    fun importPrefs(o: JSONObject): Int {
        val edit = sp.edit()
        var applied = 0
        for (spec in PREF_SPECS) {
            if (!o.has(spec.key)) continue
            val raw = o.opt(spec.key)
            when (spec) {
                is PrefSpec.B -> if (raw is Boolean) { edit.putBoolean(spec.key, raw); applied++ }
                is PrefSpec.I -> if (raw is Int && raw in spec.min..spec.max) { edit.putInt(spec.key, raw); applied++ }
            }
        }
        edit.commit()
        loadFromPrefs()
        return applied
    }

    fun exportUsage(): JSONObject = JSONObject().apply { usage.forEach { (k, v) -> put(k, v) } }

    /** Merges usage counts from a backup (taking the larger count per form). */
    fun importUsage(o: JSONObject): Int {
        val next = usage.toMutableMap()
        var merged = 0
        for (key in o.keys()) {
            if (!BackupRules.isSafeId(key)) continue
            val v = o.optInt(key, -1)
            if (v < 0) continue
            next[key] = maxOf(next[key] ?: 0, v); merged++
        }
        usage = next
        sp.edit().putString("usage", serializeUsage(next)).apply()
        return merged
    }

    // ---- smart tuning: a slow, capped, opt-out nudge (from Apexium) -------------------------------

    fun durationSuggestion(): Int? = if (smartTuningOn) adaptiveTuner.durationSuggestion(durationSec) else null
    fun acceptDurationSuggestion(v: Int) { updateDurationSec(v); adaptiveTuner.resolveDurationSuggestion(true) }
    fun dismissDurationSuggestion() { adaptiveTuner.resolveDurationSuggestion(false) }

    private fun parseUsage(s: String): Map<String, Int> =
        s.split(",").mapNotNull {
            val p = it.split(":")
            if (p.size == 2) p[1].toIntOrNull()?.let { n -> p[0] to n } else null
        }.toMap()

    private fun serializeUsage(m: Map<String, Int>) = m.entries.joinToString(",") { "${it.key}:${it.value}" }

    /** Test hook for diagnostics: a write/read/remove round-trip on the real preferences file. */
    fun persistenceSelfTest(): Boolean {
        val key = "__diag_probe"
        val value = (System.nanoTime() and 0x7fffffff).toInt()
        val wrote = sp.edit().putInt(key, value).commit()
        val ok = wrote && sp.getInt(key, -1) == value
        sp.edit().remove(key).commit()
        return ok && !sp.contains(key)
    }

    private sealed class PrefSpec(val key: String) {
        class B(key: String) : PrefSpec(key)
        class I(key: String, val min: Int, val max: Int) : PrefSpec(key)
    }

    companion object {
        const val PREFS = "clytrix_settings"
        val DURATIONS = listOf(0, 10, 30, 60)

        private val PREF_SPECS: List<PrefSpec> = listOf(
            PrefSpec.I("activation", 0, Activation.values().size - 1),
            PrefSpec.I("durationSec", 0, 60),
            PrefSpec.I("bezelClicks", 1, 4),
            PrefSpec.I("gestureSensitivity", 0, 2),
            PrefSpec.B("slapOn"), PrefSpec.I("slapForce", 0, 2),
            PrefSpec.B("parallaxOn"), PrefSpec.B("disguiseOn"),
            PrefSpec.I("sort", 0, SortMode.values().size - 1),
            PrefSpec.B("ascensionOn"), PrefSpec.B("overdriveOn"), PrefSpec.B("smartTuningOn"),
            PrefSpec.I("skin", 0, Skin.values().size - 1),
            PrefSpec.I("animationIntensity", 0, 2),
            PrefSpec.B("particlesOn"), PrefSpec.B("crtOn"), PrefSpec.B("showNames"), PrefSpec.B("stayAwake"),
            PrefSpec.B("soundOn"), PrefSpec.I("voiceSet", 0, VoiceSet.values().size - 1),
            PrefSpec.I("effectsVolume", 0, 100), PrefSpec.B("ambientHumOn"), PrefSpec.B("respectSilent"),
            PrefSpec.B("hapticsOn"), PrefSpec.I("hapticIntensity", 0, 2),
            PrefSpec.I("powerMode", 0, PowerMode.values().size - 1),
            PrefSpec.I("adaptiveCeiling", 0, 2), PrefSpec.I("adaptiveFloor", 0, 2),
            PrefSpec.B("adaptiveCoreOn"),
        )
    }
}
