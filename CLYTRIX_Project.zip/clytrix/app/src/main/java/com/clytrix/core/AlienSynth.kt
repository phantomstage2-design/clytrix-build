package com.clytrix.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

/**
 * Sound design for the device: a heavy, mechanical, unmistakably alien signature, built entirely
 * from maths (no audio files). Deliberately favours texture and impact over melody — nothing in
 * the set plays a musical scale or a chime arpeggio, and the whole set is pitched toward
 * *ancient* alien technology, not a bright modern gadget: think the tripod war-horn from *The War
 * of the Worlds* -- a vast, dissonant, ponderous machine that sounds like it predates humanity,
 * not a device that was switched on yesterday.
 *
 *  - "Ancient horn" (`hornBlast`): the signature layer. Several detuned sawtooth voices tuned a
 *    minor second and a tritone apart -- deliberately dissonant intervals that beat against each
 *    other instead of blending into a clean chord -- with a slow attack and a long decay, so it
 *    reads as something enormous waking up rather than a quick electronic sting.
 *  - "Metallic/alien" (`ringMod`): a carrier-sine ring modulator layered over the horn and the
 *    growl, the classic sci-fi trick for turning an ordinary tone into something that could not
 *    have come from an earthly instrument.
 *  - "Mechanical": an inharmonic modal resonator (`clank`) for metal-latch impacts, and filtered
 *    noise swept through a resonant filter with motor-style cogging (`whir`) for servo/motor
 *    texture, instead of clean electronic tones.
 *  - "Organic": an unstable, sub-heavy, noise-blended tone with a slow random-walk pitch wobble
 *    that never settles (`growl`), standing in for a living creature rather than a machine.
 *  - "Overpowered": saturated sub-bass booms (`powerBoom`) driven hard into soft clipping, tuned
 *    low enough to read as ground-shaking infrasound rather than a punchy modern bass hit.
 *  - "Outer space": a long synthetic reverb tail on everything -- longer and wetter than a
 *    contemporary device would ever need -- so every sound feels like it is happening in a vast,
 *    ancient, empty chamber, not a small plastic speaker.
 *  - A faint high `shimmer` touch tuned to 396 / 432 / 528 Hz threads through every effect as a
 *    one-shot signature accent, never arpeggiated into a tune.
 *
 * On top of the base set, [apexify] gives an Apex-flagged alien's transform/revert a deeper, driven
 * character (pitched down and pushed through an extra soft-clip drive pass, with a touch of ring
 * modulation) -- a cheap, robust way to make the evolved form sound fiercer without hand-tuning a
 * whole second DSP chain.
 *
 * This file has no Android dependencies, so it can be unit-tested on any JVM.
 */
object AlienSynth {
    const val SR = 22050
    private const val TWO_PI = 2.0 * PI

    /** Pitch on a 7-steps-per-octave scale (not Western notes, so nothing sounds like a ringtone). */
    fun step7(base: Double, k: Int): Double = base * 2.0.pow(k / 7.0)

    /** The three "living" anchor tones every effect and the background hum are tuned around. */
    private const val A1 = 396.0
    private const val A2 = 432.0
    private const val A3 = 528.0

    /** One full breathing cycle of [ambientHum]; its loop length is exactly 1 / this, in Hz. */
    private const val BREATHE_HZ = 1.0 / 6.6667

    // ---------------------------------------------------------------------------------------
    // Building blocks
    // ---------------------------------------------------------------------------------------

    private fun samples(seconds: Double) = max(1, (seconds * SR).toInt())

    /** Adds [src] into [dst] starting at [startSec]. */
    private fun mixInto(dst: FloatArray, src: FloatArray, startSec: Double, gain: Float = 1f) {
        val off = (startSec * SR).toInt()
        val fadeIn = (0.004 * SR).toInt()
        val fadeOut = (0.03 * SR).toInt()
        for (i in src.indices) {
            val j = off + i
            if (j !in dst.indices) continue
            var g = gain
            if (i < fadeIn) g *= i / fadeIn.toFloat()
            val left = src.size - i
            if (left < fadeOut) g *= left / fadeOut.toFloat()
            dst[j] += src[i] * g
        }
    }

    /** Two cascaded one-pole low-passes (12 dB/oct) to keep the harmonics from sounding harsh. */
    private fun warm(x: FloatArray, cutoffHz: Double = 3600.0): FloatArray {
        val a = (1.0 - exp(-TWO_PI * cutoffHz / SR)).toFloat()
        val out = FloatArray(x.size)
        var y1 = 0f
        var y2 = 0f
        for (i in x.indices) {
            y1 += a * (x[i] - y1)
            y2 += a * (y1 - y2)
            out[i] = y2
        }
        return out
    }

    /**
     * A sine pushed through an arctan waveshaper: not a smooth tone but a buzzy, electric edge.
     * [shape] 0 = almost a pure sine, 1 = hard buzz. [vib] adds a fast, slightly unstable wobble.
     */
    fun edge(dur: Double, f: Double, shape: Double = 0.5, decay: Double = 4.0, vib: Double = 0.0): FloatArray {
        val n = samples(dur)
        val out = FloatArray(n)
        val k = 1.0 + 8.0 * shape
        val norm = atan(k)
        for (i in 0 until n) {
            val t = i / SR.toDouble()
            var phase = TWO_PI * f * t
            if (vib > 0.0) phase += vib * sin(TWO_PI * 37.0 * t)
            val s = sin(phase)
            val sharp = atan(s * k) / norm
            out[i] = (sharp * exp(-decay * t)).toFloat()
        }
        return out
    }

    /**
     * An electric arc: a waveshaped chirp from [f0] to [f1] blended with filtered noise, so it
     * reads as a spark or a bolt of current rather than a musical sweep.
     */
    fun zap(
        dur: Double, f0: Double, f1: Double, curve: Double = 1.0,
        noiseMix: Double = 0.35, decay: Double = 3.0, seed: Int = 13,
        shape: Double = 0.6, lpHz: Double = 5200.0,
    ): FloatArray {
        val n = samples(dur)
        val out = FloatArray(n)
        val k = 1.0 + 8.0 * shape
        val norm = atan(k)
        val rnd = Random(seed)
        val a = 1.0 - exp(-TWO_PI * lpHz / SR)
        var phase = 0.0
        var ny = 0.0
        for (i in 0 until n) {
            val p = i / n.toDouble()
            val t = i / SR.toDouble()
            val f = f0 * (f1 / f0).pow(p.pow(curve))
            phase += TWO_PI * f / SR
            val sharp = atan(sin(phase) * k) / norm
            ny += a * ((rnd.nextDouble() * 2 - 1) - ny)
            val mixed = sharp * (1 - noiseMix) + ny * noiseMix * 2.2
            out[i] = (mixed * exp(-decay * t)).toFloat()
        }
        return out
    }

    /**
     * Sparse crackling sparks: short noise bursts scattered through the buffer at random, like
     * static discharge. [density] is the rough chance per sample of a new spark starting.
     * [envStart]/[envEnd] fade the whole layer's intensity from start to end of the buffer.
     */
    fun crackle(
        dur: Double, density: Double, seed: Int = 7,
        amp0: Double = 0.4, amp1: Double = 1.0, len0: Double = 0.0015, len1: Double = 0.011,
        envStart: Double = 1.0, envEnd: Double = 1.0,
    ): FloatArray {
        val n = samples(dur)
        val out = FloatArray(n)
        val rnd = Random(seed)
        var i = 0
        while (i < n) {
            if (rnd.nextDouble() < density) {
                val length = max(2, ((len0 + rnd.nextDouble() * (len1 - len0)) * SR).toInt())
                val amp = amp0 + rnd.nextDouble() * (amp1 - amp0)
                val env = envStart + (envEnd - envStart) * (i / n.toDouble())
                val tau = max(1.0, length * 0.3)
                var j = 0
                while (j < length && i + j < n) {
                    out[i + j] += (amp * env * (rnd.nextDouble() * 2 - 1) * exp(-j / tau)).toFloat()
                    j++
                }
            }
            i++
        }
        return out
    }

    /** Low breathing hum built from slightly detuned sines, swelling in and out; never quite settles. */
    fun drone(dur: Double, f: Double, peakAt: Double = 0.5): FloatArray {
        val n = samples(dur)
        val out = FloatArray(n)
        for (i in 0 until n) {
            val t = i / SR.toDouble()
            val p = t / dur
            val swell = if (p < peakAt) (p / peakAt).pow(1.6) else ((1 - p) / (1 - peakAt)).pow(1.2)
            val vib = 1.0 + 0.004 * sin(TWO_PI * 0.45 * t)
            val s = sin(TWO_PI * f * vib * t) +
                0.7 * sin(TWO_PI * f * 1.006 * vib * t) +
                0.4 * sin(TWO_PI * f * 0.5 * t) +
                0.25 * sin(TWO_PI * f * 2.01 * t)
            out[i] = (s * swell * 0.3).toFloat()
        }
        return out
    }

    /**
     * FM glide from [f0] to [f1] (exponential, shaped by [curve]) with envelope [amp](progress).
     * [ring] > 0 multiplies by a ring-modulator for a metallic, unstable warble.
     */
    fun glide(
        dur: Double, f0: Double, f1: Double, curve: Double = 1.0,
        ratio: Double = 1.5, index: Double = 3.0, ring: Double = 0.0,
        amp: (Double) -> Double,
    ): FloatArray {
        val n = samples(dur)
        val out = FloatArray(n)
        var phase = 0.0
        var mphase = 0.0
        for (i in 0 until n) {
            val p = i / n.toDouble()
            val f = f0 * (f1 / f0).pow(p.pow(curve))
            phase += TWO_PI * f / SR
            mphase += TWO_PI * f * ratio / SR
            var s = sin(phase + index * (1 - p * 0.7) * sin(mphase))
            if (ring > 0.0) s *= 0.6 + 0.4 * sin(TWO_PI * ring * i / SR)
            out[i] = (s * amp(p)).toFloat()
        }
        return out
    }

    /**
     * Noise whose low-pass cutoff sweeps exponentially from [fc0] to [fc1]: rising = a shockwave
     * blooming outward, falling = energy draining away. [decay] is an exponential fade rate.
     */
    fun noiseSweep(dur: Double, fc0: Double, fc1: Double, decay: Double = 0.0, seed: Int = 5): FloatArray {
        val n = samples(dur)
        val out = FloatArray(n)
        val rnd = Random(seed)
        var y = 0.0
        for (i in 0 until n) {
            val p = i / n.toDouble()
            val t = i / SR.toDouble()
            val fc = fc0 * (fc1 / fc0).pow(p)
            val a = 1.0 - exp(-TWO_PI * fc / SR)
            y += a * ((rnd.nextDouble() * 2 - 1) - y)
            out[i] = (y * min(1.0, t / 0.004) * exp(-decay * t) * 2.5).toFloat()
        }
        return out
    }

    /** Sine sub-bass thump that drops in pitch. */
    fun thump(dur: Double, f: Double, decay: Double): FloatArray {
        val n = samples(dur)
        val out = FloatArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i / SR.toDouble()
            phase += TWO_PI * (f * (1 + 0.8 * exp(-18 * t))) / SR
            out[i] = (sin(phase) * exp(-decay * t)).toFloat()
        }
        return out
    }

    /** A sub-bass thump driven hard into soft clipping: an overpowered, not-quite-clean boom. */
    fun powerBoom(dur: Double, f: Double, decay: Double, drive: Double = 3.0): FloatArray {
        val x = thump(dur, f, decay)
        val norm = tanh(drive).toFloat()
        return FloatArray(x.size) { (tanh(x[it] * drive.toFloat()) / norm) }
    }

    /** A short, bright electric "ping": an [edge] tone with a whisper of noise riding on top. */
    fun pingElectric(dur: Double, f: Double, decay: Double = 10.0, shape: Double = 0.55, noiseMix: Double = 0.06): FloatArray {
        val n = samples(dur)
        val e = edge(dur, f, shape, decay)
        val rnd = Random((f.toInt() % 997) + 1)
        val out = FloatArray(n)
        for (i in 0 until n) {
            val t = i / SR.toDouble()
            out[i] = (e[i] + noiseMix * (rnd.nextDouble() * 2 - 1) * exp(-decay * 2 * t)).toFloat()
        }
        return out
    }

    /**
     * A thin, quiet overtone sine at one of the anchor tones (396 / 432 / 528 Hz): the high
     * shimmer layered on top of the heavier low end so those frequencies read as a signature
     * rather than a rumble, with a slow tremolo so it doesn't sit dead-still.
     */
    fun shimmer(dur: Double, f: Double, gain: Double, phase0: Double = 0.0): FloatArray {
        val n = samples(dur)
        val out = FloatArray(n)
        for (i in 0 until n) {
            val t = i / SR.toDouble()
            val env = exp(-1.4 * t) * (0.5 + 0.5 * sin(TWO_PI * 3.1 * t + phase0))
            out[i] = (sin(TWO_PI * f * t + 0.6 * sin(TWO_PI * 2.0 * t)) * env * gain).toFloat()
        }
        return out
    }

    /**
     * Resonant bandpass (RBJ biquad), with its center frequency swept by [centerHz] and its
     * coefficients recomputed every [block] samples (cheap approximation of a continuous sweep).
     * Used to carve noise into a "whir"/"wind"/"metal ring" texture instead of leaving it
     * broadband and hissy.
     */
    private fun bandpassSwept(x: FloatArray, q: Double, block: Int = 48, centerHz: (Double) -> Double): FloatArray {
        val n = x.size
        val y = FloatArray(n)
        var x1 = 0.0; var x2 = 0.0; var y1 = 0.0; var y2 = 0.0
        var i = 0
        while (i < n) {
            val j = min(n, i + block)
            val t = i / SR.toDouble()
            val center = max(20.0, centerHz(t))
            val w0 = TWO_PI * center / SR
            val alpha = sin(w0) / (2 * q)
            val cosw0 = cos(w0)
            val a0 = 1 + alpha
            val b0 = alpha / a0
            val b1 = 0.0
            val b2 = -alpha / a0
            val a1 = (-2 * cosw0) / a0
            val a2 = (1 - alpha) / a0
            for (k in i until j) {
                val xi = x[k].toDouble()
                val yi = b0 * xi + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
                y[k] = yi.toFloat()
                x2 = x1; x1 = xi
                y2 = y1; y1 = yi
            }
            i = j
        }
        return y
    }

    /**
     * An inharmonic modal resonator: a handful of decaying partials at NON-integer ratios of
     * [f0] (like a struck bar or a heavy latch), each with its own fast decay, lightly
     * saturated, with a short noise click at the very front for the "impact" before the ring.
     * A mechanical thunk/clack transient — deliberately not a clean pitched tone.
     */
    fun clank(dur: Double, f0: Double, drive: Double = 2.2, seed: Int = 1, decayMul: Double = 1.0): FloatArray {
        val ratios = doubleArrayOf(1.0, 1.83, 2.41, 3.76, 5.02)
        val decays = doubleArrayOf(9.0, 13.0, 15.0, 20.0, 26.0)
        val amps = doubleArrayOf(1.0, 0.55, 0.42, 0.28, 0.16)
        val n = samples(dur)
        val rnd = Random(seed)
        val s = DoubleArray(n)
        for (p in ratios.indices) {
            val wob = 1.0 + 0.003 * (rnd.nextDouble() * 2 - 1)
            val r = ratios[p]; val d = decays[p] * decayMul; val a = amps[p]
            for (i in 0 until n) {
                val t = i / SR.toDouble()
                s[i] += a * sin(TWO_PI * f0 * r * wob * t) * exp(-d * t)
            }
        }
        val clickLen = (0.006 * SR).toInt()
        if (clickLen > 0) {
            for (i in 0 until min(clickLen, n)) {
                s[i] += (rnd.nextDouble() * 2 - 1) * exp(-i / (clickLen * 0.3)) * 0.5
            }
        }
        val driveF = drive
        val norm = tanh(driveF)
        return FloatArray(n) { i ->
            val t = i / SR.toDouble()
            val env = min(1.0, t / 0.0015)
            (tanh(s[i] * env * driveF) / norm).toFloat()
        }
    }

    /**
     * Noise carved by a swept resonant bandpass, with a slow amplitude "cogging" at [motorHz]:
     * reads as a servo or motor spinning up/down rather than an electronic sweep. No fixed
     * pitch, so it never reads as a musical note.
     */
    fun whir(dur: Double, f0: Double, f1: Double, motorHz: Double = 12.0, q: Double = 6.0, seed: Int = 2, curve: Double = 1.0, noiseGain: Double = 1.0): FloatArray {
        val n = samples(dur)
        val rnd = Random(seed)
        val noise = FloatArray(n) { ((rnd.nextDouble() * 2 - 1) * noiseGain).toFloat() }
        val y = bandpassSwept(noise, q) { t ->
            val p = if (dur > 0) t / dur else 0.0
            f0 * (f1 / f0).pow(p.pow(curve))
        }
        return FloatArray(n) { i ->
            val t = i / SR.toDouble()
            val cog = 0.72 + 0.28 * sin(TWO_PI * motorHz * t + 0.4 * sin(TWO_PI * 2.3 * t))
            (y[i] * cog).toFloat()
        }
    }

    /**
     * A low, unstable, sub-heavy tone: a fundamental with a sub-octave layer, slow random-walk
     * pitch wobble (never settles on a clean pitch), and a blend of filtered noise — an organic
     * creature/engine growl rather than an electronic tone.
     */
    fun growl(dur: Double, f0: Double, f1: Double = f0, seed: Int = 3, noiseMix: Double = 0.22, wobble: Double = 1.0): FloatArray {
        val n = samples(dur)
        val rnd = Random(seed)
        val steps = max(4, (dur * 6).toInt())
        val walkRaw = DoubleArray(steps)
        var acc = 0.0
        for (i in 0 until steps) { acc += rnd.nextDouble() * 2 - 1; walkRaw[i] = acc }
        val mean = walkRaw.average()
        for (i in 0 until steps) walkRaw[i] -= mean
        val maxAbs = walkRaw.maxOf { abs(it) }.let { if (it < 1e-9) 1.0 else it }
        for (i in 0 until steps) walkRaw[i] /= maxAbs

        fun walkAt(p: Double): Double {
            val pos = p * (steps - 1)
            val i0 = pos.toInt().coerceIn(0, steps - 1)
            val i1 = (i0 + 1).coerceAtMost(steps - 1)
            val frac = pos - i0
            return walkRaw[i0] * (1 - frac) + walkRaw[i1] * frac
        }

        val tone = FloatArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val p = i / (n - 1).toDouble().coerceAtLeast(1.0)
            val f = f0 * (f1 / f0).pow(p)
            val finst = f * (1 + 0.05 * wobble * walkAt(p))
            phase += TWO_PI * finst / SR
            tone[i] = (sin(phase) + 0.55 * sin(phase * 0.5) + 0.3 * sin(phase * 2.01)).toFloat()
        }
        val noise = FloatArray(n) { (rnd.nextDouble() * 2 - 1).toFloat() }
        val noisy = bandpassSwept(noise, 3.5) { t ->
            val p = (t / dur).coerceIn(0.0, 1.0)
            (f0 + (f1 - f0) * p) * 1.6
        }
        return FloatArray(n) { i -> (tone[i] * (1 - noiseMix) + noisy[i] * noiseMix * 1.6).toFloat() }
    }

    /**
     * The signature "ancient tech" layer: several detuned sawtooth voices a minor second and a
     * tritone above [f0] -- dissonant intervals, chosen so they beat against each other instead of
     * blending into a clean chord -- with a slow attack and a long exponential decay. Reads as a
     * vast war-horn or a piece of machinery far older and larger than the device housing it, never
     * as a musical note. [ringHz]/[ringMix] optionally ring-modulate the whole blast for an even
     * more unnatural, metallic-alien warble (0 mix = untouched).
     */
    fun hornBlast(
        dur: Double, f0: Double, attack: Double = 0.16, decay: Double = 1.4,
        drive: Double = 2.3, ringHz: Double = 0.0, ringMix: Double = 0.0,
    ): FloatArray {
        val n = samples(dur)
        val ratios = doubleArrayOf(1.0, 1.0595, 1.4142) // unison, minor 2nd, tritone above f0
        val amps = doubleArrayOf(1.0, 0.72, 0.52)
        val ampSum = amps.sum()
        val phases = DoubleArray(ratios.size)
        val raw = FloatArray(n)
        for (i in 0 until n) {
            val t = i / SR.toDouble()
            val env = if (t < attack) (t / attack).pow(1.4) else exp(-(t - attack) / decay)
            var s = 0.0
            for (k in ratios.indices) {
                phases[k] += TWO_PI * f0 * ratios[k] / SR
                val cyc = phases[k] / TWO_PI
                val saw = 2.0 * (cyc - floor(cyc + 0.5))
                s += amps[k] * saw
            }
            s /= ampSum
            if (ringMix > 0.0) {
                val ring = sin(TWO_PI * ringHz * t)
                s = s * (1 - ringMix) + s * ring * ringMix
            }
            raw[i] = (s * env).toFloat()
        }
        val norm = tanh(drive)
        return FloatArray(n) { i -> (tanh(raw[i] * drive) / norm).toFloat() }
    }

    /**
     * Multiplies [x] by a carrier sine at [hz]: the classic sci-fi ring-modulator trick for turning
     * an ordinary tone into something metallic and unnatural. [mix] 0 = untouched, 1 = fully
     * ring-modulated.
     */
    private fun ringMod(x: FloatArray, hz: Double, mix: Double): FloatArray {
        if (mix <= 0.0) return x
        return FloatArray(x.size) { i ->
            val t = i / SR.toDouble()
            val ring = sin(TWO_PI * hz * t)
            (x[i] * (1 - mix) + x[i] * ring * mix).toFloat()
        }
    }

    /**
     * A buzzy, amplitude-modulated low tone blended with noise and driven into saturation — a
     * haptic-motor "vibrate", not a musical tone. [buzzHz] is the tremolo rate that gives it its
     * buzzing texture (a real vibration motor's eccentric-weight wobble), [noiseMix] roughens the
     * tone so it never reads as a clean pitch or a struck instrument.
     */
    fun vibrateHum(dur: Double, f0: Double, buzzHz: Double = 90.0, noiseMix: Double = 0.35, drive: Double = 2.0, seed: Int = 1): FloatArray {
        val n = samples(dur)
        val rnd = Random(seed)
        val raw = FloatArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i / SR.toDouble()
            phase += TWO_PI * f0 / SR
            val tone = sin(phase)
            val buzz = 0.5 + 0.5 * sin(TWO_PI * buzzHz * t)
            val noise = rnd.nextDouble() * 2 - 1
            var s = tone * (1 - noiseMix) + noise * noiseMix
            s *= (0.35 + 0.65 * buzz)
            raw[i] = s.toFloat()
        }
        val norm = tanh(drive)
        return FloatArray(n) { i -> (tanh(raw[i] * drive) / norm).toFloat() }
    }

    private fun reversed(x: FloatArray) = FloatArray(x.size) { x[x.size - 1 - it] }

    /**
     * Freeverb-style reverb (parallel damped combs into two all-passes). Returns a longer buffer
     * that includes the tail, so everything feels like it is happening in a vast, empty chamber.
     */
    fun reverb(x: FloatArray, wet: Float, tailSec: Double = 1.2, feedback: Float = 0.80f): FloatArray {
        val out = FloatArray(x.size + samples(tailSec))
        val combLens = intArrayOf(1557, 1617, 1491, 1422, 1277, 1356)
        val damp = 0.35f
        val wetSum = FloatArray(out.size)
        for (len in combLens) {
            val buf = FloatArray(len)
            var idx = 0
            var lp = 0f
            for (i in out.indices) {
                val input = if (i < x.size) x[i] else 0f
                val delayed = buf[idx]
                lp = delayed * (1 - damp) + lp * damp
                buf[idx] = input + lp * feedback
                idx = (idx + 1) % len
                wetSum[i] += delayed
            }
        }
        // two all-pass diffusers
        for (len in intArrayOf(225, 556)) {
            val buf = FloatArray(len)
            var idx = 0
            for (i in out.indices) {
                val input = wetSum[i]
                val delayed = buf[idx]
                val v = input + delayed * 0.5f
                buf[idx] = v
                wetSum[i] = delayed - v * 0.5f
                idx = (idx + 1) % len
            }
        }
        for (i in out.indices) {
            val dry = if (i < x.size) x[i] else 0f
            out[i] = dry + wetSum[i] * wet * 0.22f
        }
        return out
    }

    /** Scales to [peak], soft-clips, fades the last few ms, converts to 16-bit PCM. */
    fun toPcm(input: FloatArray, peak: Float = 0.85f): ShortArray {
        val x = warm(input, 3200.0)
        var m = 0f
        for (v in x) m = max(m, abs(v))
        val g = if (m > 1e-6f) peak / m else 1f
        val fade = (0.03 * SR).toInt()
        return ShortArray(x.size) { i ->
            var v = x[i] * g
            v = tanh(v * 1.55f) / tanh(1.55f)
            if (i < 40) v *= i / 40f
            if (i > x.size - fade) v *= (x.size - i) / fade.toFloat()
            (v * Short.MAX_VALUE).toInt().coerceIn(-32767, 32767).toShort()
        }
    }

    /**
     * Like [toPcm] but with NO start/end silence fade: the caller guarantees the waveform itself
     * is already continuous end-to-end, so this is safe to loop with [android.media.AudioTrack]'s
     * `setLoopPoints` (a fade here would create an audible pump every time the loop repeats).
     */
    private fun toPcmLoop(input: FloatArray, peak: Float = 0.55f, drive: Float = 1.2f, cutoffHz: Double = 3600.0): ShortArray {
        val x = warm(input, cutoffHz)
        var m = 0f
        for (v in x) m = max(m, abs(v))
        val g = if (m > 1e-6f) peak / m else 1f
        return ShortArray(x.size) { i ->
            val v = tanh(x[i] * g * drive) / tanh(drive)
            (v * Short.MAX_VALUE).toInt().coerceIn(-32767, 32767).toShort()
        }
    }

    /**
     * Equal-power crossfades the tail of a loop buffer into its head over [xfMs] milliseconds,
     * then drops the redundant tail, so the wrap-around point has no audible click.
     */
    private fun sealLoop(pcm: ShortArray, xfMs: Double = 18.0): ShortArray {
        val xf = ((xfMs / 1000.0) * SR).toInt()
        val n = pcm.size
        if (n <= 2 * xf) return pcm
        val out = ShortArray(n - xf)
        for (i in 0 until xf) {
            val p = i / xf.toDouble()
            val fadeIn = sin(p * PI / 2)
            val fadeOut = cos(p * PI / 2)
            val head = pcm[i].toDouble()
            val tail = pcm[n - xf + i].toDouble()
            out[i] = (tail * fadeOut + head * fadeIn).toInt().coerceIn(-32767, 32767).toShort()
        }
        for (i in xf until n - xf) out[i] = pcm[i]
        return out
    }

    // ---------------------------------------------------------------------------------------
    // The sound set
    // ---------------------------------------------------------------------------------------

    /**
     * Dial step: a buzzy haptic vibrate-hum, not an instrument and not a chime -- amplitude-
     * modulates a noise-roughened low tone at a fast tremolo rate, like a real phone haptic
     * motor's eccentric-weight buzz, so it reads as a device sensation, not a sound.
     */
    fun tick(k: Int): ShortArray {
        val f0 = 62.0 + (k % 7) * 4.0
        val b = FloatArray(samples(0.13))
        mixInto(b, vibrateHum(0.11, f0, buzzHz = 95.0, noiseMix = 0.45, drive = 2.4, seed = 100 + k), 0.0, 0.9f)
        mixInto(b, crackle(0.015, 0.6, seed = 200 + k, amp0 = 0.15, amp1 = 0.3, len0 = 0.0008, len1 = 0.0018), 0.0, 0.35f)
        mixInto(b, shimmer(0.03, A1, 0.09, 0.0), 0.0, 1.0f)
        mixInto(b, shimmer(0.03, A2, 0.06, 1.4), 0.0, 1.0f)
        mixInto(b, shimmer(0.03, A3, 0.05, 2.8), 0.0, 1.0f)
        return toPcm(reverb(b, 0.07f, 0.08, 0.45f), 0.7f)
    }

    /**
     * Shutter opening: a slow, dissonant horn blast swells up out of the dark alongside static
     * crackle and a charging motor whir, like a vast door that has not moved in a very long time,
     * before a single mechanical latch clank releases it.
     */
    fun open(): ShortArray {
        val b = FloatArray(samples(2.05))
        mixInto(b, hornBlast(1.7, 42.0, attack = 0.55, decay = 1.1, drive = 2.0, ringHz = 61.0, ringMix = 0.18), 0.0, 0.6f)
        mixInto(b, crackle(1.3, 0.028, seed = 11, amp0 = 0.22, amp1 = 0.65, len0 = 0.003, len1 = 0.015, envStart = 0.12, envEnd = 1.0), 0.0, 0.5f)
        mixInto(b, whir(1.3, 24.0, 220.0, motorHz = 7.0, q = 5.0, seed = 3, noiseGain = 0.9), 0.0, 0.55f)
        mixInto(b, drone(1.3, 19.0, 0.8), 0.0, 0.75f)
        mixInto(b, powerBoom(0.65, 27.0, 5.5, drive = 4.8), 1.25, 1.1f)
        mixInto(b, clank(0.55, 68.0, drive = 2.5, seed = 31), 1.25, 0.95f)
        mixInto(b, crackle(0.3, 0.10, seed = 31, amp0 = 0.4, amp1 = 0.9), 1.25, 0.5f)
        mixInto(b, shimmer(1.1, A1, 0.24, 0.0), 1.3, 1.0f)
        mixInto(b, shimmer(1.1, A2, 0.12, 1.4), 1.3, 1.0f)
        mixInto(b, shimmer(1.1, A3, 0.11, 2.8), 1.3, 1.0f)
        return toPcm(reverb(b, 0.44f, 1.8, 0.86f), 0.85f)
    }

    /**
     * Played when the dial comes alive: the war-horn blast at full force under a rising whir and
     * drone, ring-modulated for an unmistakably alien, metallic warble, closing on one deep impact
     * and one metal clank -- an ancient machine drawing on a vast reserve of power, not a jingle.
     */
    fun activate(): ShortArray {
        val b = FloatArray(samples(3.10))
        mixInto(b, hornBlast(2.3, 37.0, attack = 0.5, decay = 1.7, drive = 2.6, ringHz = 53.0, ringMix = 0.24), 0.0, 0.75f)
        mixInto(b, drone(2.6, 18.0, 0.32), 0.0, 1.0f)
        mixInto(b, powerBoom(0.9, 22.0, 3.2, drive = 5.2), 0.0, 0.9f)
        mixInto(b, crackle(2.4, 0.036, seed = 41, amp0 = 0.18, amp1 = 0.8, len0 = 0.003, len1 = 0.016, envStart = 0.2, envEnd = 1.0), 0.0, 0.45f)
        mixInto(b, whir(1.3, 48.0, 460.0, motorHz = 14.0, q = 6.5, seed = 51, curve = 1.4, noiseGain = 1.1), 0.15, 0.9f)
        mixInto(b, ringMod(growl(1.2, 34.0, 108.0, seed = 52, noiseMix = 0.3), 47.0, 0.2), 0.25, 0.5f)
        mixInto(b, powerBoom(0.8, 18.0, 2.7, drive = 6.0), 1.5, 1.3f)
        mixInto(b, clank(0.55, 58.0, drive = 2.8, seed = 55, decayMul = 0.8), 1.52, 1.0f)
        mixInto(b, whir(0.75, 2800.0, 260.0, motorHz = 28.0, q = 9.0, seed = 56, noiseGain = 0.6), 1.5, 0.4f)
        arcCluster(b, 1.48, 6, seedBase = 5500, gain = 0.4f, spread = 0.18)
        mixInto(b, shimmer(1.2, A1, 0.25, 0.0), 1.6, 1.0f)
        mixInto(b, shimmer(1.2, A2, 0.15, 1.4), 1.6, 1.0f)
        mixInto(b, shimmer(1.2, A3, 0.13, 2.8), 1.6, 1.0f)
        return toPcm(reverb(b, 0.68f, 2.6, 0.9f), 0.88f)
    }

    /** Shutter closing: a descending whir winding down under a low horn sigh, into one mechanical clunk. */
    fun close(): ShortArray {
        val b = FloatArray(samples(1.55))
        mixInto(b, hornBlast(0.9, 46.0, attack = 0.04, decay = 0.55, drive = 1.8, ringHz = 58.0, ringMix = 0.14), 0.0, 0.4f)
        mixInto(b, whir(0.55, 600.0, 55.0, motorHz = 18.0, q = 5.5, seed = 61, curve = 1.3, noiseGain = 0.8), 0.0, 0.75f)
        mixInto(b, crackle(0.55, 0.045, seed = 71, amp0 = 0.15, amp1 = 0.55, envStart = 1.0, envEnd = 0.1), 0.0, 0.4f)
        mixInto(b, clank(0.5, 64.0, drive = 2.6, seed = 71), 0.03, 0.95f)
        mixInto(b, powerBoom(0.6, 24.0, 6.5, drive = 4.6), 0.03, 0.75f)
        mixInto(b, drone(0.9, 20.0, 0.10), 0.0, 0.5f)
        mixInto(b, shimmer(0.45, A1, 0.22, 0.0), 0.0, 1.0f)
        mixInto(b, shimmer(0.45, A2, 0.12, 1.4), 0.0, 1.0f)
        mixInto(b, shimmer(0.45, A3, 0.11, 2.8), 0.0, 1.0f)
        return toPcm(reverb(b, 0.42f, 1.1, 0.82f), 0.8f)
    }

    /**
     * A dense cluster of branching electric-arc zaps fired at slightly randomised times, pitches
     * and lengths -- real high-voltage arcing crackles and forks unevenly rather than sweeping
     * cleanly, so no two arcs in the cluster are identical. Used for the explosive burst of energy
     * at the start of a transformation and, reversed in feel, the collapse of a revert.
     */
    private fun arcCluster(b: FloatArray, startAt: Double, count: Int, seedBase: Int, gain: Float = 0.55f, spread: Double = 0.05) {
        val rnd = Random(seedBase)
        for (i in 0 until count) {
            val at = startAt + rnd.nextDouble() * spread * i / count.coerceAtLeast(1) + i * (spread / count)
            val f0 = 700.0 + rnd.nextDouble() * 2400.0
            val f1 = 55.0 + rnd.nextDouble() * 220.0
            val dur = 0.05 + rnd.nextDouble() * 0.09
            val decay = 6.0 + rnd.nextDouble() * 5.0
            val g = gain * (0.55f + 0.45f * (1f - i.toFloat() / count))
            mixInto(
                b,
                zap(dur, f0, f1, curve = 0.5 + rnd.nextDouble() * 0.6, noiseMix = 0.45 + rnd.nextDouble() * 0.25,
                    decay = decay, seed = seedBase + i, shape = 0.7 + rnd.nextDouble() * 0.25),
                at, g,
            )
        }
    }

    /**
     * The transformation as raw (already reverberated) audio, shared with [revert]: a genuine
     * explosion of energy going OUT -- an almost-instant detonation (ring-modulated horn stab, a
     * hard metal-impact clank and two overpowered sub-bass booms landing together, not staggered),
     * a dense cluster of branching electrical arcs crackling and forking outward like a real
     * high-voltage surge, an expanding noise shockwave, ring-modulated glides for an unexplainable
     * warble, three further pulses of arcing energy, and finally one continuous descending growl —
     * itself ring-modulated — as the power drains away. Longer and wetter than a device chime: this
     * is meant to feel like a vast discharge, not a light show.
     */
    private fun transformRaw(): FloatArray {
        val b = FloatArray(samples(3.85))
        val t0 = 0.015 // near-instant: the detonation has almost no wind-up
        // The detonation itself, all landing within the same few milliseconds.
        mixInto(b, hornBlast(0.55, 58.0, attack = 0.004, decay = 0.3, drive = 3.4, ringHz = 88.0, ringMix = 0.42), 0.0, 1.25f)
        mixInto(b, clank(0.45, 62.0, drive = 3.6, seed = 81, decayMul = 0.55), 0.0, 1.3f)
        mixInto(b, powerBoom(1.3, 13.0, 2.1, drive = 7.4), t0, 2.0f)
        mixInto(b, powerBoom(0.6, 27.0, 4.8, drive = 6.6), t0, 1.2f)
        mixInto(b, crackle(0.5, 0.46, seed = 85, amp0 = 0.55, amp1 = 1.0, len0 = 0.001, len1 = 0.006), t0, 1.0f)
        mixInto(b, noiseSweep(0.55, 4600.0, 200.0, decay = 3.4, seed = 87), t0, 1.05f)
        mixInto(b, noiseSweep(1.4, 130.0, 4200.0, decay = 1.5, seed = 89), t0 + 0.04, 0.75f)
        // The branching arc cluster -- the electrical-surge signature -- fires right on top of the
        // detonation, then two further smaller clusters ride the outward-expanding shockwave.
        arcCluster(b, t0, 9, seedBase = 5001, gain = 0.6f, spread = 0.22)
        mixInto(b, glide(1.3, 1900.0, 30.0, 0.5, 1.8, 5.4, 58.0) { p -> exp(-3.2 * p) * 1.0 }, t0, 0.55f)
        mixInto(b, glide(1.45, 42.0, 480.0, 1.3, 2.3, 4.4, 24.0) { p -> sin(PI * p.pow(0.6)) }, t0, 0.38f)
        mixInto(b, crackle(1.8, 0.032, seed = 91, amp0 = 0.15, amp1 = 0.6, len0 = 0.003, len1 = 0.014, envStart = 1.0, envEnd = 0.15), t0, 0.5f)
        for (w in 0 until 3) {
            val tw = t0 + 0.10 + 0.30 * w
            mixInto(b, whir(0.42, 220.0 - 40 * w, 1400.0 - 200 * w, motorHz = 22.0 + 5 * w, q = 5.0, seed = 400 + w, noiseGain = 1.0), tw, 0.55f - 0.08f * w)
            mixInto(b, clank(0.35, 90.0 - 10 * w, drive = 2.2, seed = 410 + w, decayMul = 1.2), tw, 0.5f - 0.06f * w)
            arcCluster(b, tw, 3, seedBase = 5100 + w * 10, gain = 0.4f - 0.08f * w, spread = 0.14)
        }
        mixInto(b, ringMod(growl(1.4, 220.0, 48.0, seed = 95, noiseMix = 0.3, wobble = 1.5), 42.0, 0.2), t0 + 0.55, 0.42f)
        mixInto(b, hornBlast(1.6, 30.0, attack = 0.32, decay = 1.25, drive = 2.1, ringHz = 46.0, ringMix = 0.24), t0 + 0.75, 0.44f)
        mixInto(b, shimmer(1.4, A1, 0.24, 0.0), t0 + 0.55, 1.0f)
        mixInto(b, shimmer(1.4, A2, 0.13, 1.4), t0 + 0.55, 1.0f)
        mixInto(b, shimmer(1.4, A3, 0.12, 2.8), t0 + 0.55, 1.0f)
        mixInto(b, drone(3.2, 16.0, 0.08), t0, 1.1f)
        mixInto(b, drone(2.9, 33.0, 0.12), t0, 0.5f)
        return reverb(b, 0.7f, 2.6, 0.91f)
    }

    fun transform(): ShortArray = toPcm(transformRaw(), 0.93f)

    /**
     * The reverse of the transformation: the whole explosive release played backwards, so every
     * arc, boom and shockwave is heard being pulled back IN instead of blasting out -- a rushing
     * inward suction (noise sweeping from bright to a near-vacuum low, growing rather than
     * decaying, as if air itself is being drawn in), a second, denser cluster of collapsing
     * electric arcs right at the point of impact, and finally one very hard implosive
     * clank-and-boom landing together as the alien form collapses back into the device.
     */
    private fun revertRaw(): FloatArray {
        val rev = reversed(transformRaw())
        val len = samples(2.55)
        val tail = rev.copyOfRange(max(0, rev.size - len), rev.size)
        val out = FloatArray(len + samples(1.25))
        mixInto(out, tail, 0.0, 1f)
        mixInto(out, whir(1.7, 1600.0, 42.0, motorHz = 18.0, q = 5.5, seed = 95, curve = 1.6, noiseGain = 0.95), 0.0, 0.38f)
        // an inward suction: amplitude GROWS toward the implosion instead of decaying away from it
        mixInto(out, noiseSweep(1.6, 5200.0, 90.0, decay = -1.1, seed = 96), 0.0, 0.3f)
        val end = len / SR.toDouble()
        arcCluster(out, end - 0.22, 10, seedBase = 5300, gain = 0.55f, spread = 0.2)
        mixInto(out, powerBoom(0.8, 20.0, 4.8, drive = 6.4), end - 0.03, 1.3f)
        mixInto(out, clank(0.45, 60.0, drive = 3.2, seed = 97, decayMul = 0.6), end - 0.02, 1.1f)
        mixInto(out, hornBlast(0.6, 42.0, attack = 0.015, decay = 0.35, drive = 2.6, ringHz = 62.0, ringMix = 0.3), end - 0.02, 0.6f)
        mixInto(out, shimmer(0.4, A1, 0.24, 0.0), end - 0.02, 1.0f)
        mixInto(out, shimmer(0.4, A2, 0.15, 1.4), end - 0.02, 1.0f)
        mixInto(out, shimmer(0.4, A3, 0.13, 2.8), end - 0.02, 1.0f)
        return reverb(out, 0.5f, 1.6, 0.87f)
    }

    fun revert(): ShortArray = toPcm(revertRaw(), 0.9f)

    /**
     * Time-out: an urgent warning — the SAME short, dissonant horn stab repeated three times, each
     * hit a little harder (real alarms repeat, they don't play a descending melody), reading like a
     * vast ancient siren rather than an electronic beep — then the same power-draining reverse
     * effect as a manual revert.
     */
    fun timeout(): ShortArray {
        val alarm = FloatArray(samples(1.55))
        val f = 78.0
        for (i in 0 until 3) {
            val t0 = 0.28 * i
            mixInto(alarm, hornBlast(0.34, f, attack = 0.01, decay = 0.22, drive = 2.6 + 0.2 * i, ringHz = 66.0, ringMix = 0.22), t0, 0.6f + 0.1f * i)
            mixInto(alarm, edge(0.3, f * 1.6, shape = 0.9, decay = 8.0), t0, 0.4f + 0.08f * i)
            mixInto(alarm, clank(0.3, f * 1.4, drive = 2.4, seed = 500 + i, decayMul = 1.6), t0, 0.45f + 0.07f * i)
            mixInto(alarm, crackle(0.14, 0.18, seed = 600 + i, amp0 = 0.2, amp1 = 0.5), t0, 0.4f)
            arcCluster(alarm, t0, 3, seedBase = 5700 + i * 10, gain = 0.32f + 0.05f * i, spread = 0.08)
        }
        mixInto(alarm, shimmer(0.35, A1, 0.22, 0.0), 0.0, 1.0f)
        mixInto(alarm, shimmer(0.35, A2, 0.12, 1.4), 0.0, 1.0f)
        mixInto(alarm, shimmer(0.35, A3, 0.11, 2.8), 0.0, 1.0f)
        val wetAlarm = reverb(alarm, 0.4f, 1.3, 0.82f)
        val rev = revertRaw()
        val out = FloatArray(max(wetAlarm.size, samples(0.55) + rev.size))
        mixInto(out, wetAlarm, 0.0, 0.9f)
        mixInto(out, rev, 0.55, 1.0f)
        return toPcm(out, 0.9f)
    }

    /**
     * Ready again: a low, solemn horn swell settling into place -- less a cheerful chime than an
     * ancient mechanism finishing its cycle -- plus a soft metal tap.
     */
    fun recharged(): ShortArray {
        val b = FloatArray(samples(1.35))
        mixInto(b, hornBlast(0.85, 58.0, attack = 0.22, decay = 0.6, drive = 1.8, ringHz = 50.0, ringMix = 0.14), 0.0, 0.5f)
        mixInto(b, growl(0.55, 80.0, 116.0, seed = 61, noiseMix = 0.12, wobble = 0.5), 0.0, 0.5f)
        mixInto(b, powerBoom(0.4, 62.0, 9.0, drive = 3.6), 0.02, 0.65f)
        mixInto(b, clank(0.4, 128.0, drive = 2.2, seed = 62, decayMul = 1.3), 0.05, 0.55f)
        mixInto(b, crackle(0.4, 0.04, seed = 62, amp0 = 0.12, amp1 = 0.3), 0.1, 0.3f)
        mixInto(b, shimmer(0.6, A1, 0.25, 0.0), 0.08, 1.0f)
        mixInto(b, shimmer(0.6, A2, 0.13, 1.4), 0.08, 1.0f)
        mixInto(b, shimmer(0.6, A3, 0.12, 2.8), 0.08, 1.0f)
        return toPcm(reverb(b, 0.48f, 1.2, 0.84f), 0.8f)
    }

    /**
     * A short, sharp double-hit used when a transform lands mid-combo: two quick clank/crackle
     * impacts with a rising shimmer, reading as an escalation rather than a fresh transform.
     */
    fun comboHit(streak: Int): ShortArray {
        val b = FloatArray(samples(0.55))
        val bump = (streak.coerceAtMost(8) - 1) * 0.02
        mixInto(b, clank(0.22, 130.0 + streak * 6.0, drive = 2.6, seed = 700 + streak), 0.0, 1.0f)
        mixInto(b, clank(0.22, 170.0 + streak * 8.0, drive = 2.4, seed = 710 + streak), 0.10, 0.85f)
        mixInto(b, crackle(0.3, 0.12, seed = 720 + streak, amp0 = 0.2, amp1 = 0.5), 0.0, 0.5f)
        mixInto(b, shimmer(0.35, A2 + bump * 40.0, 0.22, 0.0), 0.05, 1.0f)
        return toPcm(reverb(b, 0.22f, 0.4, 0.7f), 0.85f)
    }

    /**
     * A quiet, continuously-loopable background hum, so the device feels alive even when idle.
     * Tuned around the three anchor tones (396 / 432 / 528 Hz). The waveform is built to wrap
     * seamlessly so [android.media.AudioTrack] can loop it with no click or pump.
     */
    fun ambientHum(dur: Double = 1.0 / BREATHE_HZ, seed: Int = 999): ShortArray {
        val n = samples(dur)
        val rnd = Random(seed)

        // f2 is detuned to a near-tritone relationship with f1 rather than a clean interval, so the
        // idle hum beats faintly against itself instead of settling into a pleasant chord -- an
        // ancient reactor breathing, not a gadget's standby tone.
        val f1 = A1 / 8.0
        val f2 = f1 * 1.41
        val f3 = A3 / 11.0
        val sub = FloatArray(n)
        val mid = FloatArray(n)
        val shim = FloatArray(n)
        for (i in 0 until n) {
            val t = i / SR.toDouble()
            val breathe = 0.45 + 0.55 * (0.5 + 0.5 * sin(TWO_PI * BREATHE_HZ * t))
            val breathe2 = 0.6 + 0.4 * (0.5 + 0.5 * sin(TWO_PI * (2 * BREATHE_HZ) * t + 2.1))
            var s = sin(TWO_PI * f1 * t) + 0.85 * sin(TWO_PI * f2 * t + 0.3) + 0.7 * sin(TWO_PI * f3 * t + 1.1)
            s *= (0.55 + 0.45 * breathe) * (0.7 + 0.3 * breathe2)
            sub[i] = s.toFloat()

            var m = sin(TWO_PI * A1 * t) + 0.8 * sin(TWO_PI * A2 * t + 0.7) + 0.65 * sin(TWO_PI * A3 * t + 1.6)
            m *= 0.06 * (0.4 + 0.6 * breathe)
            mid[i] = m.toFloat()

            shim[i] = (sin(TWO_PI * (A1 * 2) * t + 3.0 * sin(TWO_PI * 0.6 * t)) * 0.02 * (0.3 + 0.7 * breathe2)).toFloat()
        }

        val out = FloatArray(n)
        for (i in 0 until n) out[i] = sub[i] * 0.5f + mid[i] + shim[i]

        val density = 0.4
        val nSparks = (dur * density).toInt()
        repeat(nSparks) {
            val pos = 0.05 + rnd.nextDouble() * (dur - 0.10)
            val i0 = (pos * SR).toInt()
            val length = ((0.002 + rnd.nextDouble() * 0.008) * SR).toInt().coerceAtLeast(1)
            val i1 = min(n, i0 + length)
            if (i1 <= i0) return@repeat
            val amp = 0.08 + rnd.nextDouble() * 0.14
            for (i in i0 until i1) {
                val env = exp(-(i - i0) / (length * 0.3 + 1))
                out[i] += ((rnd.nextDouble() * 2 - 1) * env * amp).toFloat()
            }
        }

        val xf = (0.35 * SR).toInt()
        val looped = if (n > 2 * xf) {
            val trimmed = FloatArray(n - xf)
            for (i in 0 until xf) {
                val p = i / xf.toDouble()
                trimmed[i] = (out[n - xf + i] * (1 - p) + out[i] * p).toFloat()
            }
            for (i in xf until n - xf) trimmed[i] = out[i]
            trimmed
        } else out

        val loopLen = looped.size
        val doubled = FloatArray(loopLen * 2)
        System.arraycopy(looped, 0, doubled, 0, loopLen)
        System.arraycopy(looped, 0, doubled, loopLen, loopLen)
        val wetDoubled = reverb(doubled, 0.46f, 1.6, 0.83f)
        val wet = FloatArray(loopLen) { wetDoubled[loopLen + it] * 0.5f }

        val pcm = toPcmLoop(wet, 0.55f, 1.2f, 3600.0)
        return sealLoop(pcm, 18.0)
    }

    // ---------------------------------------------------------------------------------------
    // Apex flavouring: an optional, per-alien "evolved" variant (see Alien.apex) built by pitching
    // the base clip down and driving it harder into soft clipping -- deliberately simple and robust
    // (a resample + a waveshaper pass), and it never touches the delicate generator math above.
    // ---------------------------------------------------------------------------------------

    private fun resample(pcm: ShortArray, rate: Double): ShortArray {
        if (pcm.isEmpty() || rate <= 0.0) return pcm
        val outLen = max(1, (pcm.size / rate).toInt())
        return ShortArray(outLen) { i ->
            val srcPos = i * rate
            val i0 = srcPos.toInt().coerceIn(0, pcm.size - 1)
            val i1 = (i0 + 1).coerceAtMost(pcm.size - 1)
            val frac = srcPos - i0
            (pcm[i0] * (1 - frac) + pcm[i1] * frac).toInt().coerceIn(-32767, 32767).toShort()
        }
    }

    /**
     * Deeper and rougher: a lower playback rate, an extra soft-clip drive pass, and a light ring
     * modulation -- the same alien-metallic trick used throughout the base set -- so the evolved
     * form reads as more machine than creature, not just louder.
     */
    fun apexify(pcm: ShortArray, pitchRatio: Double = 0.72, drive: Double = 1.8, ringHz: Double = 38.0, ringMix: Double = 0.1): ShortArray {
        val slowed = resample(pcm, pitchRatio)
        val norm = tanh(drive)
        return ShortArray(slowed.size) { i ->
            val t = i / SR.toDouble()
            var x = slowed[i] / 32767.0
            x = tanh(x * drive) / norm
            if (ringMix > 0.0) {
                val ring = sin(TWO_PI * ringHz * t)
                x = x * (1 - ringMix) + x * ring * ringMix
            }
            (x * 32767.0).toInt().coerceIn(-32767, 32767).toShort()
        }
    }

    fun transformApex(): ShortArray = apexify(transform())
    fun revertApex(): ShortArray = apexify(revert())

    // ---------------------------------------------------------------------------------------
    // Identification cues: a small, deliberately lighter vocabulary of interface sounds --
    // a scan sweep, a lock-on confirmation, a rejection buzz -- for moments that are about the
    // *device's UI* rather than the ancient machinery itself. Kept simpler and shorter than the
    // horn/growl/arc set on purpose so they read as "interface", not another slice of the same
    // ancient tech; a light ring-modulation touch keeps them from sounding like a modern phone.
    // ---------------------------------------------------------------------------------------

    /**
     * A tightening ladder of ring-modulated blips, rising in pitch and quickening as it runs --
     * an alien identification scan rather than a plain menu blip.
     */
    fun scan(steps: Int = 6): ShortArray {
        val b = FloatArray(samples(0.8))
        for (i in 0 until steps) {
            val p = if (steps > 1) i / (steps - 1).toDouble() else 0.0
            val f = 380.0 + p * p * 1400.0
            val start = i * (0.09 - p * 0.045)
            mixInto(b, ringMod(edge(0.05, f, shape = 0.5, decay = 26.0), 46.0, 0.12), start, (0.42f + 0.16f * p.toFloat()))
        }
        mixInto(b, shimmer(0.55, A2, 0.05, 0.0), 0.0, 1f)
        return toPcm(reverb(b, 0.22f, 0.4, 0.6f), 0.75f)
    }

    /** A two-note ascending confirmation chirp plus a soft mechanical click: "lock-on". */
    fun recognized(): ShortArray {
        val b = FloatArray(samples(0.35))
        mixInto(b, edge(0.09, 660.0, shape = 0.35, decay = 22.0), 0.0, 0.7f)
        mixInto(b, edge(0.11, 990.0, shape = 0.35, decay = 18.0), 0.09, 0.75f)
        mixInto(b, clank(0.08, 900.0, drive = 1.6, seed = 810, decayMul = 2.2), 0.0, 0.25f)
        mixInto(b, shimmer(0.2, A3, 0.12, 0.0), 0.09, 1f)
        return toPcm(reverb(b, 0.28f, 0.5, 0.65f), 0.8f)
    }

    /** A short, dissonant descending two-tone buzz: a rejected scan or a locked feature. */
    fun errorBuzz(): ShortArray {
        val b = FloatArray(samples(0.42))
        mixInto(b, ringMod(edge(0.16, 220.0, shape = 0.85, decay = 9.0), 35.0, 0.3), 0.0, 0.8f)
        mixInto(b, ringMod(edge(0.20, 196.0, shape = 0.85, decay = 8.0), 35.0, 0.3), 0.1, 0.75f)
        mixInto(b, crackle(0.15, 0.2, seed = 920, amp0 = 0.2, amp1 = 0.4), 0.0, 0.4f)
        return toPcm(reverb(b, 0.2f, 0.35, 0.55f), 0.8f)
    }

    /** Recalibrate's own cue: a short scan ladder into the lock-on chirp -- "re-scanning" the
     *  roster, replacing the placeholder tick it used to borrow. */
    fun recalibrateCue(): ShortArray {
        val a = scan(5)
        val gap = ShortArray((0.02 * SR).toInt())
        val b = recognized()
        return a + gap + b
    }
}
