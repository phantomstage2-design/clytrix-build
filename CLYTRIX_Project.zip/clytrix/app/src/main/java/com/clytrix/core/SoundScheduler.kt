package com.clytrix.core

import java.util.concurrent.PriorityBlockingQueue
import java.util.concurrent.atomic.AtomicLong

/**
 * A tiny, Android-free priority scheduler for one-shot sound requests: hands out the
 * highest-priority entry first (a LOWER [Entry.priority] number wins), FIFO within the same
 * priority tier, and lets a caller COALESCE same-priority requests that share a [Entry.coalesceKey]
 * so a burst of low-priority requests (rapid dial ticks, specifically) never builds a backlog --
 * only the newest one survives.
 *
 * Deliberately has no Android dependency (no [android.media.AudioTrack], no [android.util.Log])
 * so it can be unit-tested on a plain JVM -- see SoundSchedulerTest. [SoundEngine] is the only
 * real caller, and owns all the actual audio I/O; this class only decides ORDER, never plays
 * anything itself.
 *
 * @param maxPerPriority an optional cap per priority tier for NON-coalesced entries (coalesced
 *   entries -- those with a non-null `coalesceKey` -- are exempt, since they can never build a
 *   backlog in the first place). [offer] returns false and drops the request if its tier is full.
 */
class SoundScheduler<T>(private val maxPerPriority: Map<Int, Int> = emptyMap()) {

    data class Entry<T>(val priority: Int, val seq: Long, val coalesceKey: Any?, val payload: T)

    private val seqGen = AtomicLong(0)
    private val queue = PriorityBlockingQueue<Entry<T>>(16, compareBy<Entry<T>>({ it.priority }, { it.seq }))

    // offer() is the only method that reads then conditionally writes (remove-then-put for
    // coalescing, count-then-put for the cap); PriorityBlockingQueue makes each individual
    // operation thread-safe, but not that whole sequence, so two overlapping offer() calls for
    // the same (priority, coalesceKey) could both pass the check before either puts, leaving two
    // entries where only one should survive -- or two calls at a full priority cap could both
    // read the pre-put count and both get accepted, one over the cap. offerLock makes the whole
    // sequence atomic. take()/size()/clear() are left unsynchronized: they only ever do one queue
    // operation each, which PriorityBlockingQueue already makes safe on its own.
    private val offerLock = Any()

    /**
     * Enqueues [payload] at [priority] (lower = more urgent).
     *
     * If [coalesceKey] is non-null, any entry still waiting (not yet taken) at the SAME priority
     * with the SAME key is removed first, so at most one entry per (priority, key) pair is ever
     * queued -- this is how dial ticks avoid building a backlog during a fast rotary spin.
     *
     * If [coalesceKey] is null, the request is never coalesced away, but is dropped (and this
     * returns false) once [maxPerPriority] for its tier is already queued, bounding memory against
     * a caller that queues critical sounds faster than they can ever play.
     */
    fun offer(priority: Int, payload: T, coalesceKey: Any? = null): Boolean = synchronized(offerLock) {
        if (coalesceKey != null) {
            queue.removeIf { it.priority == priority && it.coalesceKey == coalesceKey }
        } else {
            val cap = maxPerPriority[priority]
            if (cap != null && queue.count { it.priority == priority } >= cap) return@synchronized false
        }
        queue.put(Entry(priority, seqGen.incrementAndGet(), coalesceKey, payload))
        true
    }

    /**
     * Blocks until an entry is available, then removes and returns its payload: highest priority
     * (lowest [Entry.priority] number) first, oldest-first within a tier. Throws
     * [InterruptedException] (without catching it) if the calling thread is interrupted while
     * waiting, so a caller can use thread interruption as a clean shutdown signal.
     */
    @Throws(InterruptedException::class)
    fun take(): T = queue.take().payload

    /** Number of entries currently waiting (for diagnostics/tests only). */
    fun size(): Int = queue.size

    /** Discards everything currently queued without playing it. */
    fun clear() = queue.clear()
}
