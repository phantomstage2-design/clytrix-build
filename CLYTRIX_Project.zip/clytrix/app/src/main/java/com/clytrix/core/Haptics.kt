package com.clytrix.core

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * The watch vibrator. Every effect respects the Haptics switch and is scaled by
 * [Settings.hapticScale] (the user's intensity choice x the active power profile) -- never
 * silenced by a profile, only softened. Patterns are kept short (all well under a second except
 * the Ascension signature) so they read as intentional cues, not buzzing.
 *
 * Apexium's patterns are kept for the shared moments (open, close, revert, timeout, recalibrate);
 * CLYTRIX adds confirmation, a lighter selection tick, the Ascension signature, and a warning.
 */
class Haptics(context: Context, private val settings: Settings) {
    private val vibrator: Vibrator? = context.getSystemService(Vibrator::class.java)

    val available: Boolean get() = vibrator?.hasVibrator() == true
    val amplitudeControl: Boolean get() = vibrator?.hasAmplitudeControl() == true

    private fun scaled(amplitudes: IntArray, extra: Float = 1f): IntArray {
        val k = settings.hapticScale * extra
        return IntArray(amplitudes.size) { i ->
            val a = amplitudes[i]
            if (a <= 0) 0 else (a * k).toInt().coerceIn(1, 255)
        }
    }

    private fun play(timings: LongArray, amplitudes: IntArray) {
        if (!settings.hapticsOn) return
        val v = vibrator?.takeIf { it.hasVibrator() } ?: return
        try { v.vibrate(VibrationEffect.createWaveform(timings, scaled(amplitudes), -1)) } catch (_: Throwable) { }
    }

    private fun predefined(effect: Int) {
        if (!settings.hapticsOn) return
        val v = vibrator?.takeIf { it.hasVibrator() } ?: return
        try { v.vibrate(VibrationEffect.createPredefined(effect)) } catch (_: Throwable) { }
    }

    /** Selection movement: the system's own crisp tick (the lightest cue there is). */
    fun tick() = predefined(VibrationEffect.EFFECT_TICK)

    /** Device opening: segments releasing one after another. */
    fun open() = play(longArrayOf(0, 18, 30, 18, 30, 18, 30, 45), intArrayOf(0, 80, 0, 110, 0, 140, 0, 210))

    fun activate() = play(longArrayOf(0, 30, 50, 55, 60, 110), intArrayOf(0, 70, 0, 130, 0, 200))

    fun close() = play(longArrayOf(0, 40, 40, 30), intArrayOf(0, 150, 0, 90))

    /** Transformation confirmation: one short, firm "accepted" pulse. */
    fun confirm() = play(longArrayOf(0, 35), intArrayOf(0, 200))

    /** Transformation activation: a strong burst that fades out. */
    fun transform() = play(
        longArrayOf(0, 45, 30, 70, 40, 100, 50, 130, 60, 160),
        intArrayOf(0, 255, 0, 210, 0, 160, 0, 110, 0, 60),
    )

    /** Ascension: the burst, then a rising second wave -- light gathering, then release. */
    fun ascension() = play(
        longArrayOf(0, 50, 30, 80, 60, 40, 30, 60, 30, 90, 30, 160),
        intArrayOf(0, 255, 0, 200, 0, 90, 0, 140, 0, 200, 0, 255),
    )

    fun revert() = play(
        longArrayOf(0, 60, 50, 60, 45, 70, 40, 80, 35, 120),
        intArrayOf(0, 50, 0, 100, 0, 160, 0, 210, 0, 255),
    )

    /** Warning: three equal, insistent pulses. */
    fun warning() = play(longArrayOf(0, 90, 70, 90, 70, 90), intArrayOf(0, 230, 0, 230, 0, 230))

    fun timeout() = play(longArrayOf(0, 120, 80, 120, 80, 220), intArrayOf(0, 255, 0, 200, 0, 140))

    /** Recharge complete: a soft double tap. */
    fun recharged() = play(longArrayOf(0, 30, 60, 30), intArrayOf(0, 120, 0, 120))

    fun recalibrate() = play(longArrayOf(0, 25, 40, 25, 40, 25), intArrayOf(0, 180, 0, 180, 0, 180))

    /** One-time celebratory cue when Overdrive unlocks (deliberately not scaled down). */
    fun overdriveUnlocked() {
        if (!settings.hapticsOn) return
        val v = vibrator?.takeIf { it.hasVibrator() } ?: return
        try { v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 80, 60, 140), intArrayOf(0, 220, 0, 255), -1)) } catch (_: Throwable) { }
    }
}
