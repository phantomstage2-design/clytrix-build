package com.clytrix.core

/**
 * Real, measured rendering and input numbers for the Evolution Core and the Diagnostics Center.
 * Nothing here is estimated: every value comes from timestamps taken where frames are actually
 * drawn and where input is actually handled.
 *
 *  - Frame timing: [onFrame] is called from inside the device Canvas's draw block, so the gap
 *    between two calls is the real time between two rendered frames while something is animating.
 *    Gaps over [IDLE_GAP_MS] mean nothing was animating (not jank) and are ignored.
 *  - Draw cost: the time spent inside the draw block itself (CPU side of a frame).
 *  - Input latency: [onInput] stores the input event's own timestamp; the next rendered frame
 *    records how long it took for that input to reach the screen.
 *  - Jank: a frame interval over 1.5x the interval expected for the current frame-rate cap.
 *
 * Plain Kotlin (callers pass the clock values in), so it's covered by PerfMonitorTest on the JVM.
 * Calls arrive on the main thread; methods are synchronized anyway so diagnostics can read safely.
 */
class PerfMonitor {

    data class Window(
        val frames: Int,
        val fps: Float,
        val avgFrameMs: Float,
        val p95FrameMs: Float,
        val jankFraction: Float,
        val avgDrawMs: Float,
        val inputSamples: Int,
        val inputLatencyAvgMs: Float,
        val inputLatencyMaxMs: Float,
        val expectedFps: Int,
    )

    private val intervals = FloatArray(MAX_SAMPLES)
    private var intervalCount = 0
    private var lastFrameNanos = 0L
    private var hasLastFrame = false
    private var drawNanosSum = 0L
    private var drawCount = 0
    private var jankCount = 0
    private var expectedFps = 60
    private var activeNanos = 0L

    private var pendingInputUptime = 0L
    private var inputCount = 0
    private var inputSumMs = 0L
    private var inputMaxMs = 0L

    /** The most recently closed window, for display. */
    @Volatile var lastWindow: Window? = null
        private set

    /** Lifetime-of-process totals. */
    var totalFrames = 0L; private set
    var totalJank = 0L; private set

    /**
     * @param nowNanos monotonic clock (System.nanoTime) at the start of the draw.
     * @param nowUptimeMs uptime clock (SystemClock.uptimeMillis) -- same base as input events.
     * @param drawCostNanos how long the draw block took.
     * @param fpsCap the frame-rate cap in force (0 = display rate, treated as 60).
     */
    @Synchronized
    fun onFrame(nowNanos: Long, nowUptimeMs: Long, drawCostNanos: Long, fpsCap: Int) {
        expectedFps = if (fpsCap in 1..120) fpsCap else 60
        if (hasLastFrame) {
            val gapMs = (nowNanos - lastFrameNanos) / 1_000_000f
            if (gapMs in 0.5f..IDLE_GAP_MS) {
                if (intervalCount < MAX_SAMPLES) intervals[intervalCount++] = gapMs
                activeNanos += nowNanos - lastFrameNanos
                val budget = 1000f / expectedFps
                if (gapMs > budget * 1.5f) { jankCount++; totalJank++ }
                totalFrames++
            }
        }
        lastFrameNanos = nowNanos
        hasLastFrame = true
        if (drawCostNanos > 0) { drawNanosSum += drawCostNanos; drawCount++ }
        if (pendingInputUptime != 0L) {
            val lat = (nowUptimeMs - pendingInputUptime).coerceAtLeast(0L)
            if (lat < 2_000L) {
                inputCount++; inputSumMs += lat; if (lat > inputMaxMs) inputMaxMs = lat
            }
            pendingInputUptime = 0L
        }
    }

    /** @param eventUptimeMs the input event's own timestamp (uptime clock). */
    @Synchronized
    fun onInput(eventUptimeMs: Long) {
        if (pendingInputUptime == 0L) pendingInputUptime = eventUptimeMs
    }

    /** Frames recorded since the last [closeWindow]. */
    @Synchronized
    fun pendingFrames(): Int = intervalCount

    /**
     * Summarises everything since the previous call and starts a new window. Returns null (and
     * keeps accumulating) when fewer than [minFrames] animated frames were seen -- too few to say
     * anything honest about performance.
     */
    @Synchronized
    fun closeWindow(minFrames: Int = 30): Window? {
        if (intervalCount < minFrames) return null
        val sorted = intervals.copyOf(intervalCount).also { it.sort() }
        val sum = sorted.sum()
        val avg = sum / intervalCount
        val p95 = sorted[((intervalCount - 1) * 0.95f).toInt()]
        val activeSec = activeNanos / 1e9f
        val w = Window(
            frames = intervalCount,
            fps = if (activeSec > 0f) intervalCount / activeSec else 0f,
            avgFrameMs = avg,
            p95FrameMs = p95,
            jankFraction = jankCount.toFloat() / intervalCount,
            avgDrawMs = if (drawCount > 0) drawNanosSum / drawCount / 1e6f else 0f,
            inputSamples = inputCount,
            inputLatencyAvgMs = if (inputCount > 0) inputSumMs.toFloat() / inputCount else 0f,
            inputLatencyMaxMs = inputMaxMs.toFloat(),
            expectedFps = expectedFps,
        )
        lastWindow = w
        intervalCount = 0; jankCount = 0; drawNanosSum = 0; drawCount = 0; activeNanos = 0
        inputCount = 0; inputSumMs = 0; inputMaxMs = 0
        return w
    }

    /** Forget the frame chain (e.g. after the app was paused) so the pause isn't one long frame. */
    @Synchronized
    fun resetChain() { hasLastFrame = false; pendingInputUptime = 0L }

    companion object {
        const val MAX_SAMPLES = 4096
        const val IDLE_GAP_MS = 250f
    }
}
