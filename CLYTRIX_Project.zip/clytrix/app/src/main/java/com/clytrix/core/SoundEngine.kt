package com.clytrix.core

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.min

/**
 * Plays CLYTRIX's synthesized sound set; the app ships with no audio files.
 *
 * Apexium's engine, kept intact where it matters -- the same two playback paths:
 *  - ONE dedicated worker thread drains a [SoundScheduler] priority queue onto ONE shared,
 *    long-lived [AudioTrack]: at most one effect sounds at a time (no overlapping clips summing
 *    into distortion), critical cues jump ahead of dial ticks, and a fast bezel spin coalesces to
 *    a single queued tick. A queued critical sound plays next, never cuts the current one off.
 *  - The ambient hum keeps its own independent thread/track, so neither path can block the other.
 *
 * CLYTRIX additions:
 *  - Two voice sets ([VoiceSet]): the new Celestial set ([CelestialSynth]) and Apexium's Classic
 *    set ([AlienSynth]). Switching re-synthesizes on a background thread and swaps the whole set
 *    atomically ([reloadVoices]); a request can never see a half-built set.
 *  - Effects volume, applied per request to the shared track; the hum scales with it.
 *  - Silent mode: with "Respect silent mode" on, nothing plays while the watch is in Vibrate or
 *    Mute sound mode (the user can still force-play the test sound in Settings).
 *  - Power profiles: the hum only plays when the active profile allows it ([refreshHum]).
 *  - New cues: transformation confirmation, Ascension transform/revert, and a warning alert.
 *  - Status getters for the Diagnostics Center.
 */
class SoundEngine(context: Context, private val settings: Settings) {

    enum class Fx { Open, Activate, Close, Confirm, Warning, Timeout, Recharged, Recalibrate, Error }

    /** Wired in by MainActivity right after both are constructed; optional and null-checked. */
    var adaptiveCore: AdaptiveCore? = null

    private val audio: AudioManager? = context.applicationContext.getSystemService(AudioManager::class.java)

    // ------------------------------------------------------------------------------------------
    // Synthesis -- one immutable snapshot per voice set, swapped atomically.
    // ------------------------------------------------------------------------------------------

    private class SynthesizedSound(
        val voiceSet: VoiceSet,
        val buffers: Map<Fx, ShortArray>,
        val ticks: List<ShortArray>,
        val transformNormal: ShortArray,
        val transformAscended: ShortArray?,
        val revertNormal: ShortArray,
        val revertAscended: ShortArray?,
        val hum: ShortArray,
    )

    @Volatile private var synth: SynthesizedSound? = null
    private val generation = AtomicInteger(0)
    @Volatile var synthesizing: Boolean = false; private set
    @Volatile var lastSynthError: String? = null; private set
    @Volatile var lastSynthMs: Long = 0; private set
    private val effectsPlayed = AtomicInteger(0)

    private fun build(set: VoiceSet): SynthesizedSound = when (set) {
        VoiceSet.Celestial -> SynthesizedSound(
            voiceSet = set,
            buffers = mapOf(
                Fx.Open to CelestialSynth.open(), Fx.Activate to CelestialSynth.activate(),
                Fx.Close to CelestialSynth.close(), Fx.Confirm to CelestialSynth.confirm(),
                Fx.Warning to CelestialSynth.warning(), Fx.Timeout to CelestialSynth.timeout(),
                Fx.Recharged to CelestialSynth.recharged(), Fx.Recalibrate to CelestialSynth.recalibrate(),
                Fx.Error to CelestialSynth.error(),
            ),
            ticks = List(CelestialSynth.TICK_VARIANTS) { CelestialSynth.tick(it) },
            transformNormal = CelestialSynth.transform(),
            transformAscended = runCatching { CelestialSynth.ascension() }.getOrNull(),
            revertNormal = CelestialSynth.revert(),
            revertAscended = runCatching { CelestialSynth.revertAscended() }.getOrNull(),
            hum = CelestialSynth.hum(),
        )
        VoiceSet.Classic -> {
            val tNorm = AlienSynth.transform()
            val rNorm = AlienSynth.revert()
            SynthesizedSound(
                voiceSet = set,
                buffers = mapOf(
                    Fx.Open to AlienSynth.open(), Fx.Activate to AlienSynth.activate(),
                    Fx.Close to AlienSynth.close(), Fx.Confirm to AlienSynth.recognized(),
                    Fx.Warning to AlienSynth.scan(4), Fx.Timeout to AlienSynth.timeout(),
                    Fx.Recharged to AlienSynth.recharged(), Fx.Recalibrate to AlienSynth.recalibrateCue(),
                    Fx.Error to AlienSynth.errorBuzz(),
                ),
                ticks = List(TICK_VARIANTS) { AlienSynth.tick(it) },
                transformNormal = tNorm,
                transformAscended = runCatching { AlienSynth.apexify(tNorm) }.getOrNull(),
                revertNormal = rNorm,
                revertAscended = runCatching { AlienSynth.apexify(rNorm) }.getOrNull(),
                hum = AlienSynth.ambientHum(),
            )
        }
    }

    /** Starts background synthesis of the selected voice set. Safe to call more than once. */
    fun prepare() {
        if (synth != null || synthesizing) return
        reloadVoices()
    }

    /**
     * (Re)builds the selected voice set on a background thread and publishes it in one step. A
     * newer call supersedes an older one still running (generation check), so rapid toggling
     * never publishes a stale set.
     */
    fun reloadVoices() {
        val gen = generation.incrementAndGet()
        val set = settings.voiceSet
        synthesizing = true
        Thread({
            val started = System.currentTimeMillis()
            try {
                val built = build(set)
                if (generation.get() != gen) return@Thread
                val humWasPlaying = humThread != null
                synth = built
                lastSynthMs = System.currentTimeMillis() - started
                lastSynthError = null
                startWorker()
                if (humWasPlaying) { stopHumPlayback(); }
                refreshHum()
            } catch (e: Throwable) {
                lastSynthError = e.javaClass.simpleName + ": " + (e.message ?: "")
                Log.e(TAG, "Sound synthesis failed", e)
            } finally {
                if (generation.get() == gen) synthesizing = false
            }
        }, "ClytrixSoundPrep").apply { isDaemon = true; priority = Thread.NORM_PRIORITY - 1 }.start()
    }

    // ------------------------------------------------------------------------------------------
    // One-shot effects: one shared AudioTrack, one worker thread, scheduled by SoundScheduler.
    // ------------------------------------------------------------------------------------------

    private data class Request(val name: String, val pcm: ShortArray, val volume: Float)

    private val scheduler = SoundScheduler<Request>(maxPerPriority = mapOf(PRIORITY_CRITICAL to MAX_QUEUED_CRITICAL))
    private val workerStarted = AtomicBoolean(false)
    private val workerShouldRun = AtomicBoolean(true)
    private var worker: Thread? = null

    private val effectLock = Any()
    private var effectTrack: AudioTrack? = null
    private var totalFramesWritten: Long = 0

    private fun startWorker() {
        if (!workerStarted.compareAndSet(false, true)) return
        val t = Thread({ runWorker() }, "ClytrixSoundFx")
        t.isDaemon = true
        worker = t
        t.start()
    }

    private fun runWorker() {
        while (workerShouldRun.get()) {
            val req = try { scheduler.take() } catch (e: InterruptedException) { break }
            if (!workerShouldRun.get()) break
            playOneBuffer(req)
        }
        releaseEffectTrack()
    }

    private fun ensureEffectTrack(): AudioTrack? {
        synchronized(effectLock) { effectTrack }?.let { if (it.state == AudioTrack.STATE_INITIALIZED) return it }
        val track = buildTrack(AudioAttributes.CONTENT_TYPE_SONIFICATION) ?: run {
            adaptiveCore?.reportSoundFailure()
            return null
        }
        adaptiveCore?.reportSoundSuccess()
        track.play()
        synchronized(effectLock) {
            effectTrack = track
            totalFramesWritten = 0
        }
        return track
    }

    private fun buildTrack(contentType: Int): AudioTrack? {
        val minBuf = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(contentType)
                        .build(),
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SR)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                )
                .setBufferSizeInBytes(maxOf(minBuf, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Throwable) {
            Log.e(TAG, "Could not create an AudioTrack", e)
            return null
        }
        if (track.state != AudioTrack.STATE_INITIALIZED) {
            Log.e(TAG, "AudioTrack failed to initialise (state=${track.state})")
            try { track.release() } catch (_: Throwable) { }
            return null
        }
        return track
    }

    private fun playOneBuffer(req: Request) {
        val track = ensureEffectTrack() ?: return
        try {
            try { track.setVolume(req.volume) } catch (_: Throwable) { }
            var offset = 0
            var consecutiveFailures = 0
            while (offset < req.pcm.size) {
                val n = track.write(req.pcm, offset, min(2048, req.pcm.size - offset))
                if (n > 0) {
                    offset += n
                    totalFramesWritten += n
                    consecutiveFailures = 0
                } else {
                    // Non-positive write: back off briefly and give up after a few tries rather than
                    // busy-spinning (Apexium fix, kept).
                    consecutiveFailures++
                    if (consecutiveFailures > MAX_WRITE_RETRIES) {
                        Log.e(TAG, "AudioTrack.write returned $n for ${req.name}, giving up")
                        releaseEffectTrack()
                        return
                    }
                    try { Thread.sleep(WRITE_RETRY_BACKOFF_MS) } catch (e: InterruptedException) { return }
                }
            }
            effectsPlayed.incrementAndGet()
            waitForDrain(track, totalFramesWritten)
        } catch (e: Throwable) {
            Log.e(TAG, "Playing ${req.name} failed", e)
            releaseEffectTrack()
        }
    }

    /** Blocks until [framesWritten] frames have actually played, bounded by [DRAIN_TIMEOUT_MS]. */
    private fun waitForDrain(track: AudioTrack, framesWritten: Long) {
        val deadline = System.currentTimeMillis() + DRAIN_TIMEOUT_MS
        try {
            while (System.currentTimeMillis() < deadline) {
                val played = track.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                if (played >= framesWritten) return
                Thread.sleep(DRAIN_POLL_MS)
            }
            Log.w(TAG, "Drain wait timed out after ${DRAIN_TIMEOUT_MS}ms")
        } catch (e: InterruptedException) {
            // shutting down
        }
    }

    private fun releaseEffectTrack() {
        val track = synchronized(effectLock) {
            val t = effectTrack ?: return
            effectTrack = null
            t
        }
        try { track.stop() } catch (_: Throwable) { }
        try { track.release() } catch (_: Throwable) { }
    }

    private val effectVolume: Float get() = (settings.effectsVolume / 100f).coerceIn(0f, 1f)

    /** True when the user wants sound and the watch isn't in Vibrate/Mute (if respected). */
    fun audible(): Boolean {
        if (!settings.soundOn || settings.effectsVolume <= 0) return false
        if (settings.respectSilent && isWatchSilenced()) return false
        return true
    }

    fun isWatchSilenced(): Boolean = try {
        val mode = audio?.ringerMode ?: AudioManager.RINGER_MODE_NORMAL
        mode == AudioManager.RINGER_MODE_SILENT || mode == AudioManager.RINGER_MODE_VIBRATE
    } catch (_: Throwable) { false }

    /** Plays a fixed effect. [force] ignores sound on/off, volume 0 and silent mode. */
    fun play(fx: Fx, force: Boolean = false) {
        if (!force && !audible()) return
        val data = synth?.buffers?.get(fx)
        if (data == null) { Log.w(TAG, "Sound $fx requested before synthesis finished"); return }
        enqueueCritical(fx.name, data, if (force) maxOf(effectVolume, 0.7f) else effectVolume)
    }

    fun playTransform(ascended: Boolean, force: Boolean = false) {
        if (!force && !audible()) return
        val s = synth ?: return
        // Falls back to the standard clip if the Ascension one isn't ready (or failed).
        val data = (if (ascended) s.transformAscended else null) ?: s.transformNormal
        enqueueCritical(if (ascended) "Ascension" else "Transform", data, if (force) maxOf(effectVolume, 0.7f) else effectVolume)
    }

    fun playRevert(ascended: Boolean) {
        if (!audible()) return
        val s = synth ?: return
        val data = (if (ascended) s.revertAscended else null) ?: s.revertNormal
        enqueueCritical(if (ascended) "RevertAscended" else "Revert", data, effectVolume)
    }

    fun tick(step: Int) {
        if (!audible()) return
        val list = synth?.ticks
        if (list.isNullOrEmpty()) return
        scheduler.offer(PRIORITY_TICK, Request("Tick", list[Math.floorMod(step, list.size)], effectVolume), coalesceKey = TICK_COALESCE_KEY)
    }

    private fun enqueueCritical(name: String, data: ShortArray, volume: Float) {
        val accepted = scheduler.offer(PRIORITY_CRITICAL, Request(name, data, volume))
        if (!accepted) Log.w(TAG, "Dropping $name -- $MAX_QUEUED_CRITICAL critical sounds already queued")
    }

    // ------------------------------------------------------------------------------------------
    // Ambient hum: its own track/thread (Apexium design). [humRequested] = the dial is live and
    // would like a hum; [refreshHum] decides whether it may actually play right now.
    // ------------------------------------------------------------------------------------------

    private val humLock = Any()
    @Volatile private var humThread: Thread? = null
    @Volatile private var humTrack: AudioTrack? = null
    @Volatile private var humWanted = false
    @Volatile private var humRequested = false
    @Volatile private var humVolumeTarget = HUM_VOLUME

    val humPlaying: Boolean get() = humTrack != null

    /** The dial became live: the hum may play (subject to settings/profile/silent mode). */
    fun startHum() { humRequested = true; refreshHum() }

    /** The dial closed: fade the hum out. */
    fun stopHum() { humRequested = false; refreshHum() }

    /** Re-evaluates whether the hum should be playing; call after any related setting changes. */
    fun refreshHum() {
        val allowed = humRequested && settings.effectiveHumOn && audible()
        if (allowed) {
            humVolumeTarget = targetHumVolume()
            humTrack?.let { t -> try { t.setVolume(humVolumeTarget) } catch (_: Throwable) { } }
            humWanted = true
            startHumInternal()
        } else {
            stopHumPlayback()
        }
    }

    fun onHumSettingChanged() = refreshHum()

    /** Active power profile changed: re-scale or stop/start the hum without a gap where possible. */
    fun onPowerProfileChanged() = refreshHum()

    private fun targetHumVolume(): Float = HUM_VOLUME * effectVolume * (if (settings.batterySaverActive) SAVER_HUM_SCALE else 1f)

    private fun stopHumPlayback() {
        val captured = synchronized(humLock) {
            humWanted = false
            val t = humTrack
            val w = humThread
            humThread = null
            humTrack = null
            if (t != null && w != null) t to w else { w?.interrupt(); null }
        }
        if (captured == null) return
        val (track, worker) = captured
        Thread({
            try {
                val steps = 8
                for (s in steps downTo 0) {
                    try { track.setVolume(humVolumeTarget * s / steps) } catch (_: Throwable) { break }
                    Thread.sleep(18)
                }
            } finally {
                worker.interrupt()
            }
        }, "ClytrixHumStop").apply { isDaemon = true }.start()
    }

    private fun startHumInternal() {
        synchronized(humLock) {
            if (!humWanted) return
            if (humThread != null) return
            val data = synth?.hum ?: return
            val t = Thread({ runHum(data) }, "ClytrixHum")
            t.isDaemon = true
            humThread = t
            t.start()
        }
    }

    private fun runHum(data: ShortArray) {
        var track: AudioTrack? = null
        try {
            track = buildTrack(AudioAttributes.CONTENT_TYPE_MUSIC)
            if (track == null) {
                adaptiveCore?.reportSoundFailure()
                return
            }
            adaptiveCore?.reportSoundSuccess()
            synchronized(humLock) {
                if (humThread !== Thread.currentThread() || !humWanted) {
                    try { track.release() } catch (_: Throwable) { }
                    track = null
                    return
                }
                humTrack = track
            }
            val t = track!!
            t.setVolume(0f)
            t.play()
            humVolumeTarget = targetHumVolume()
            for (s in 1..12) {
                if (!humWanted || Thread.currentThread().isInterrupted) break
                t.setVolume(humVolumeTarget * s / 12)
                Thread.sleep(18)
            }
            var writeFailed = false
            outer@ while (humWanted && !Thread.currentThread().isInterrupted && !writeFailed) {
                var offset = 0
                var consecutiveFailures = 0
                while (offset < data.size) {
                    val n = t.write(data, offset, min(2048, data.size - offset))
                    if (n > 0) {
                        offset += n
                        consecutiveFailures = 0
                    } else {
                        consecutiveFailures++
                        if (consecutiveFailures > MAX_WRITE_RETRIES) {
                            Log.e(TAG, "AudioTrack.write returned $n for ambient hum, stopping")
                            writeFailed = true
                            break@outer
                        }
                        try { Thread.sleep(WRITE_RETRY_BACKOFF_MS) } catch (e: InterruptedException) { break@outer }
                    }
                    if (!humWanted || Thread.currentThread().isInterrupted) break@outer
                }
            }
            t.stop()
        } catch (e: InterruptedException) {
            // normal stop path
        } catch (e: Throwable) {
            Log.e(TAG, "Playing ambient hum failed", e)
        } finally {
            synchronized(humLock) {
                if (humTrack === track) humTrack = null
                if (humThread === Thread.currentThread()) humThread = null
            }
            try { track?.release() } catch (_: Throwable) { }
        }
    }

    // ------------------------------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------------------------------

    /** Stops everything and releases every AudioTrack (MainActivity.onDestroy). */
    fun release() {
        humRequested = false
        stopHumPlayback()
        workerShouldRun.set(false)
        scheduler.clear()
        worker?.interrupt()
        worker?.let { try { it.join(1000) } catch (_: InterruptedException) { } }
        releaseEffectTrack()
    }

    // ------------------------------------------------------------------------------------------
    // Diagnostics
    // ------------------------------------------------------------------------------------------

    val isReady: Boolean get() = synth != null
    val loadedVoiceSet: VoiceSet? get() = synth?.voiceSet
    val workerAlive: Boolean get() = worker?.isAlive == true
    val effectsPlayedCount: Int get() = effectsPlayed.get()
    val queued: Int get() = scheduler.size()

    /** Builds and immediately releases a track: proves the audio output can initialise, silently. */
    fun probeOutput(): Boolean {
        val t = buildTrack(AudioAttributes.CONTENT_TYPE_SONIFICATION) ?: return false
        try { t.release() } catch (_: Throwable) { }
        return true
    }

    fun mediaVolume(): Pair<Int, Int>? = try {
        val am = audio ?: throw IllegalStateException()
        am.getStreamVolume(AudioManager.STREAM_MUSIC) to am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    } catch (_: Throwable) { null }

    fun hasOutputDevice(): Boolean = try {
        audio?.getDevices(AudioManager.GET_DEVICES_OUTPUTS)?.any {
            it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER ||
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET
        } == true
    } catch (_: Throwable) { false }

    fun volumeLabel(): String {
        val v = mediaVolume() ?: return "Audio unavailable"
        return when {
            !hasOutputDevice() -> "No speaker or headphones found"
            settings.respectSilent && isWatchSilenced() -> "Watch is in silent/vibrate mode. Tap to test anyway"
            v.first == 0 -> "Media volume is 0/${v.second}. Tap to raise"
            else -> "Media volume ${v.first}/${v.second}. Tap to test"
        }
    }

    /** The only place the engine touches the system media volume -- only on the user's explicit
     *  "test sound" tap in Settings, never automatically. */
    fun testAndFixVolume() {
        try {
            val am = audio
            if (am != null) {
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                val cur = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                val target = (max * 0.7f).toInt().coerceAtLeast(1)
                if (cur < target) am.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not change media volume", e)
        }
        play(Fx.Confirm, force = true)
    }

    private companion object {
        const val SR = AlienSynth.SR
        const val TAG = "ClytrixSound"
        const val TICK_VARIANTS = 7
        const val HUM_VOLUME = 0.35f
        const val SAVER_HUM_SCALE = 0.45f

        const val PRIORITY_CRITICAL = 0
        const val PRIORITY_TICK = 1
        const val MAX_QUEUED_CRITICAL = 4
        val TICK_COALESCE_KEY = Any()

        const val MAX_WRITE_RETRIES = 5
        const val WRITE_RETRY_BACKOFF_MS = 20L

        // Longest clip: Ascension (~7.4 s with its reverb tail) -- plus margin.
        const val DRAIN_TIMEOUT_MS = 12_000L
        const val DRAIN_POLL_MS = 20L
    }
}
