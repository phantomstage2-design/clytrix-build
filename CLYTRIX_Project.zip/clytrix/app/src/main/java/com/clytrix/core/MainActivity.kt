package com.clytrix.core

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import com.clytrix.core.ui.ClytrixTheme
import com.clytrix.core.ui.CoreScreen
import com.clytrix.core.ui.CrtOverlay
import com.clytrix.core.ui.SettingsDeps
import com.clytrix.core.ui.SettingsScreen
import com.clytrix.core.ui.paletteFor
import com.clytrix.core.ui.rememberArt
import org.json.JSONArray
import org.json.JSONObject

/**
 * Owns the object graph and the lifecycle. Order matters and is kept from Apexium: CrashGuard
 * first, then storage and settings, then crash recovery, then audio, then the adaptive systems.
 *
 * Lifecycle rules (battery): sensors, the battery receiver, the Evolution Core tick and the hum
 * only run between onResume and onPause. Nothing is scheduled in the background.
 */
class MainActivity : ComponentActivity() {

    private lateinit var customAliens: CustomAliens
    private lateinit var settings: Settings
    private lateinit var sound: SoundEngine
    private lateinit var haptics: Haptics
    private lateinit var controller: CoreController
    private lateinit var slap: SlapDetector
    private lateinit var adaptiveCore: AdaptiveCore
    private lateinit var diagnostics: Diagnostics
    private val perf = PerfMonitor()
    private var resumed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashGuard.install(this)

        customAliens = CustomAliens(this)
        settings = Settings(this, customAliens, AdaptiveTuner(this), Progress(this))
        CrashGuard.consumePendingRecovery(this)?.let { crumb ->
            if (crumb.startsWith("alien:")) settings.quarantineAlien(crumb.removePrefix("alien:"))
        }
        sound = SoundEngine(this, settings).also { it.prepare() }
        haptics = Haptics(this, settings)
        adaptiveCore = AdaptiveCore(this, settings, perf)
        sound.adaptiveCore = adaptiveCore
        controller = CoreController(settings, sound, haptics, perf)
        slap = SlapDetector(this, threshold = { settings.slapThreshold }, onSlap = { controller.onSlap() })
        diagnostics = Diagnostics(this, settings, sound, haptics, controller, adaptiveCore, customAliens)

        adaptiveCore.onProfileChanged = { _, _, lowBattery ->
            sound.onPowerProfileChanged()
            updateSlapRegistration()
            if (lowBattery) { sound.play(SoundEngine.Fx.Warning); haptics.warning() }
        }
        // Resolve the profile once before the first frame so the dial starts in the right mode.
        adaptiveCore.evaluate()

        MiraLink.load(this)
        MiraLink.register(miraHost)

        setContent {
            ClytrixApp(
                controller = controller,
                deps = { art ->
                    SettingsDeps(settings, sound, adaptiveCore, diagnostics, controller, art) { updateSlapRegistration() }
                },
                perf = perf,
                customAliens = customAliens,
                onSlapConfigChanged = { updateSlapRegistration() },
            )
        }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        controller.onResumed()
        updateSlapRegistration()
        adaptiveCore.start()
        // The hum belongs only to a live dial (selecting or transformed).
        if (controller.isDialActive()) sound.startHum() else sound.refreshHum()
    }

    override fun onPause() {
        resumed = false
        slap.stop()
        sound.stopHum()
        adaptiveCore.stop()
        perf.resetChain()
        // Leave a small status snapshot for the Mira link to answer from while CLYTRIX is closed.
        runCatching { MiraLink.saveSnapshot(this, miraHost.batteryStatus()) }
        super.onPause()
    }

    /** Motion activation listens only while visible and switched on, at the profile's rate. */
    private fun updateSlapRegistration() {
        slap.stop()
        if (resumed && settings.slapOn) slap.start(fast = settings.activeProfile.fastSensors)
    }

    override fun onDestroy() {
        if (::settings.isInitialized) MiraLink.unregister(miraHost)
        // onDestroy can run after a partial onCreate failure; guard every lateinit.
        if (::sound.isInitialized) sound.release()
        super.onDestroy()
    }

    // ---- what the optional Mira AI link may ask of the running app -----------------------------------

    private val miraHost = object : MiraLink.Host {
        override fun batteryStatus(): JSONObject {
            val pct = adaptiveCore.batteryPct
            return JSONObject()
                .put("battery_pct", pct)
                .put("charging", adaptiveCore.charging)
                .put("power_mode", settings.powerMode.name)
                .put("active_profile", settings.activeProfile.name)
                .put("reason", settings.profileReason)
                .put("speech_text", "CLYTRIX is in ${settings.activeProfile.label} mode" +
                    if (pct >= 0) ". The watch battery is at $pct percent." else ".")
        }

        override fun setPowerMode(mode: PowerMode) {
            settings.updatePowerMode(mode)
            adaptiveCore.evaluate()
        }

        override fun diagnosticsSummary(): JSONObject {
            val crash = CrashGuard.record(this@MainActivity)
            val w = perf.lastWindow
            val last = diagnostics.lastResults
            val fails = last.count { it.result == Diagnostics.Result.FAIL }
            val warns = last.count { it.result == Diagnostics.Result.WARNING }
            val o = JSONObject()
                .put("state", controller.phase.name)
                .put("profile", settings.activeProfile.name)
                .put("fps", w?.fps?.toDouble())
                .put("jank_fraction", w?.jankFraction?.toDouble())
                .put("sound_ready", sound.isReady)
                .put("crashes_24h", crash.recentCount())
                .put("uptime_ms", diagnostics.uptimeMs())
                .put("last_full_diagnostic_at", diagnostics.lastRunAt)
            if (last.isNotEmpty()) o.put("checks", JSONArray().apply {
                last.forEach { put(JSONObject().put("name", it.name).put("result", it.result.name)) }
            })
            val speech = when {
                last.isEmpty() -> "CLYTRIX is running in ${settings.activeProfile.label} mode. No full diagnostic has been run yet."
                fails > 0 -> "The last diagnostic found $fails failure${if (fails > 1) "s" else ""} and $warns warning${if (warns != 1) "s" else ""}."
                warns > 0 -> "The last diagnostic passed with $warns warning${if (warns > 1) "s" else ""}."
                else -> "The last diagnostic passed every check that ran."
            }
            return o.put("speech_text", speech)
        }

        override fun evolutionStatus(): JSONObject {
            val evo = adaptiveCore.evolution
            val cw = evo.currentWindow
            return JSONObject()
                .put("enabled", settings.adaptiveCoreOn)
                .put("adjustments", evo.adjustmentsTotal)
                .put("rollbacks", evo.rollbacksTotal)
                .put("last_optimization", evo.lastOptimization)
                .put("profile", settings.activeProfile.name)
                .put("fps", cw?.fps?.toDouble())
                .put("jank_fraction", cw?.jankFraction?.toDouble())
                .put("speech_text", if (!settings.adaptiveCoreOn) "The Evolution Core is switched off." else
                    "The Evolution Core has made ${evo.adjustmentsTotal} adjustments and rolled back ${evo.rollbacksTotal}." +
                        (cw?.let { " It's currently measuring ${"%.0f".format(it.fps)} frames per second." } ?: ""))
        }

        override fun recommendations(): JSONObject {
            val evo = adaptiveCore.evolution
            val recs = evo.recommendations(EvolutionPolicy.RecInputs(
                crtOn = settings.crtOn, particlesOn = settings.particlesOn, stayAwake = settings.stayAwake,
                ambientHumOn = settings.ambientHumOn, powerMode = settings.powerMode,
                batteryPct = adaptiveCore.batteryPct, charging = adaptiveCore.charging,
                jankEma = evo.statsFor(settings.activeProfile)?.jankEma,
                drainPerHour = evo.statsFor(settings.activeProfile)?.takeIf { it.drainSamples > 0 }?.drainPerHourEma,
                soundFailures = adaptiveCore.soundFailuresSession,
                recentCrashes = CrashGuard.record(this@MainActivity).recentCount(),
            ))
            return JSONObject()
                .put("recommendations", JSONArray().apply { recs.forEach { put(JSONObject().put("id", it.id).put("title", it.title).put("detail", it.detail)) } })
                .put("speech_text", if (recs.isEmpty()) "CLYTRIX has no recommendations right now." else
                    "CLYTRIX recommends: ${recs.joinToString("; ") { it.title }}. You can apply them on the watch.")
        }

        override fun openDial(): Boolean = controller.openDial()
        override fun selectFavorite(): Alien? = controller.selectFavorite()
        override fun selectForm(name: String): Alien? = controller.selectForm(name)
    }
}

@Composable
private fun ClytrixApp(
    controller: CoreController,
    deps: (com.clytrix.core.ui.Art) -> SettingsDeps,
    perf: PerfMonitor,
    customAliens: CustomAliens,
    onSlapConfigChanged: () -> Unit,
) {
    var screen by rememberSaveable { mutableStateOf(SCREEN_CORE) }
    val settings = controller.settings

    val view = LocalView.current
    SideEffect { view.keepScreenOn = settings.stayAwake }
    LaunchedEffect(settings.slapOn) { onSlapConfigChanged() }
    LaunchedEffect(screen) { if (screen == SCREEN_CORE) controller.onResumed() }

    // One shared image cache for the whole app, hoisted above every screen (a photo is decoded once).
    val art = rememberArt(customAliens, settings.aliens) { broken -> settings.quarantineAlien(broken.id) }
    val settingsDeps = remember(art) { deps(art) }

    ClytrixTheme(pal = paletteFor(settings.skin)) {
        Box(modifier = Modifier.fillMaxSize()) {
            when (screen) {
                SCREEN_CORE -> CoreScreen(controller = controller, art = art, perf = perf, onOpenSettings = { screen = SCREEN_SETTINGS })
                else -> SettingsScreen(settingsDeps, onBack = { screen = SCREEN_CORE })
            }
            // Drawn last, never intercepts input (a Canvas with no pointer handling).
            if (settings.effectiveCrtOn) CrtOverlay(modifier = Modifier.fillMaxSize())
        }
    }
}

private const val SCREEN_CORE = 0
private const val SCREEN_SETTINGS = 1
