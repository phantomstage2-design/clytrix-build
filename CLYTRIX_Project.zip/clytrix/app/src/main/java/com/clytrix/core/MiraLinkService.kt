package com.clytrix.core

import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.WearableListenerService

/**
 * Receives Mira AI link requests from the CLYTRIX Link relay on the paired phone, even when the
 * CLYTRIX screen isn't open (in that case only the status snapshot and power-mode changes are
 * available; anything that needs the dial answers "app_not_open"). All checks -- link switched on,
 * rate limit, pairing token, per-command permission -- happen in [MiraLink.handle].
 */
class MiraLinkService : WearableListenerService() {
    override fun onMessageReceived(event: MessageEvent) {
        if (event.path != MiraLink.REQUEST_PATH) return
        MiraLink.handle(applicationContext, event.sourceNodeId, event.path, event.data ?: ByteArray(0))
    }
}
