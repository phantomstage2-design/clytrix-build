package com.clytrix.core.ui

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.clytrix.core.Skin

/**
 * One colour theme for the CLYTRIX device. Every theme shares the same materials -- deep black
 * case, brushed silver, celestial gold -- and differs in its *light*: the core, the energy and the
 * glow. [Skin.Emerald] is the default: radiant emerald with gold on deep black, luminous white
 * highlights.
 */
@Immutable
data class Palette(
    val coreA: Color,       // bright centre of the core
    val coreB: Color,       // deep edge of the core
    val glow: Color,        // energy light: conduits, selection ring, flash
    val accent: Color,      // luminous highlight (near-white, tinted)
    val gold: Color = Color(0xFFE2C062),
    val goldDeep: Color = Color(0xFF8A6A22),
    val silver: Color = Color(0xFFB9C2C8),
    val metalA: Color = Color(0xFF2A2F33),   // segment plate, lit edge
    val metalB: Color = Color(0xFF0B0D0F),   // segment plate, shadow
    val caseA: Color = Color(0xFF1A1E21),
    val caseB: Color = Color(0xFF020304),
)

fun paletteFor(skin: Skin): Palette = when (skin) {
    Skin.Emerald -> Palette(coreA = Color(0xFF8CFFD0), coreB = Color(0xFF007A4D), glow = Color(0xFF2CE6A0), accent = Color(0xFFF2FFF8))
    Skin.Gold -> Palette(coreA = Color(0xFFFFF0B0), coreB = Color(0xFF9A6A00), glow = Color(0xFFFFD25A), accent = Color(0xFFFFFBEA),
        gold = Color(0xFFF4E2A0))
    Skin.Sapphire -> Palette(coreA = Color(0xFFB8D8FF), coreB = Color(0xFF1336A8), glow = Color(0xFF5C9CFF), accent = Color(0xFFF0F6FF))
    Skin.Amethyst -> Palette(coreA = Color(0xFFE7C4FF), coreB = Color(0xFF4A1580), glow = Color(0xFFB57BFF), accent = Color(0xFFFAF2FF))
    Skin.Aurora -> Palette(coreA = Color(0xFFB4FFF4), coreB = Color(0xFF00686A), glow = Color(0xFF3FE8DA), accent = Color(0xFFEFFFFD))
    Skin.Seraph -> Palette(coreA = Color(0xFFFFD0E4), coreB = Color(0xFF8A1A4A), glow = Color(0xFFFF7FB2), accent = Color(0xFFFFF3F8))
    Skin.Ember -> Palette(coreA = Color(0xFFFFD6A6), coreB = Color(0xFF9A2C00), glow = Color(0xFFFF8A3D), accent = Color(0xFFFFF5EC))
    Skin.Lunar -> Palette(coreA = Color(0xFFFFFFFF), coreB = Color(0xFF5E6B78), glow = Color(0xFFDDE7F2), accent = Color(0xFFFFFFFF),
        gold = Color(0xFFD9DEE4), goldDeep = Color(0xFF6E7782))
}

/** Dimmed crimson used while the device recharges after a chosen time limit ran out. */
fun rechargePalette(base: Palette): Palette = base.copy(
    coreA = Color(0xFFFF9E8E), coreB = Color(0xFF6A0E06), glow = Color(0xFFFF5A44), accent = Color(0xFFFFE6E0),
)

/**
 * Ascension: the theme's light pushed toward white-gold and intensified -- an exalted form of the
 * same colours rather than a different skin.
 */
fun ascensionPalette(base: Palette): Palette = base.copy(
    coreA = lerp(base.coreA, Color.White, 0.45f),
    coreB = lerp(base.coreB, base.gold, 0.35f),
    glow = lerp(base.glow, Color(0xFFFFF1C2), 0.5f),
    accent = Color.White,
    gold = lerp(base.gold, Color(0xFFFFF4CF), 0.35f),
)

/** Warm gold used for the Overdrive (no-timer) indicator. */
val overdriveGlow = Color(0xFFFFD34D)
