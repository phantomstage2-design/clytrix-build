package com.clytrix.core

import android.content.Context

/**
 * A minimal safety net, not a crash reporter (from Apexium): it records what the app was doing
 * right before an uncaught crash (which form it was drawing, if any) so the *next* launch can
 * recover gracefully instead of failing in the same place again. Never swallows the crash itself;
 * the system's normal crash handling still runs exactly as before.
 *
 * CLYTRIX additions, for the Diagnostics Center and the Evolution Core: a lifetime crash count,
 * the last few crash timestamps (to spot *recurring* crashes), and whether this launch recovered.
 * Only the exception class and message are kept -- no stack traces, no user data.
 */
object CrashGuard {
    private const val PREFS = "clytrix_crashguard"
    @Volatile private var breadcrumb: String = "unknown"

    /** True when this process started by recovering from a crash in the previous one. */
    @Volatile var recoveredThisLaunch: Boolean = false
        private set

    /** Call as early as possible in the app's startup. Safe to call more than once. */
    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        if (previous is GuardHandler) return
        Thread.setDefaultUncaughtExceptionHandler(GuardHandler(app, previous))
    }

    private class GuardHandler(
        private val app: Context,
        private val previous: Thread.UncaughtExceptionHandler?,
    ) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(thread: Thread, error: Throwable) {
            try {
                val sp = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val now = System.currentTimeMillis()
                val history = (sp.getString("crashTimes", "") ?: "")
                    .split(",").mapNotNull { it.toLongOrNull() }.takeLast(4) + now
                // commit(), not apply(): the process can be killed the moment this returns.
                sp.edit()
                    .putString("lastBreadcrumb", breadcrumb)
                    .putString("lastError", (error.javaClass.simpleName + ": " + (error.message ?: "")).take(160))
                    .putLong("lastCrashAt", now)
                    .putInt("crashCount", sp.getInt("crashCount", 0) + 1)
                    .putString("crashTimes", history.joinToString(","))
                    .putBoolean("pendingRecovery", true)
                    .commit()
            } catch (t: Throwable) {
                // Never let the crash-recorder itself get in the way of the real crash handling.
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** A short tag for whatever the app is doing right now, e.g. "alien:form_ab12cd". */
    fun mark(tag: String) { breadcrumb = tag }

    /** Non-null exactly once after a crash, describing what to recover from; clears itself. */
    fun consumePendingRecovery(context: Context): String? {
        val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!sp.getBoolean("pendingRecovery", false)) return null
        val crumb = sp.getString("lastBreadcrumb", null)
        sp.edit().putBoolean("pendingRecovery", false).apply()
        recoveredThisLaunch = true
        return crumb
    }

    data class Record(val count: Int, val lastError: String?, val lastAt: Long, val recentTimes: List<Long>) {
        /** Crashes in the last 24 hours -- "recurring" when 2 or more. */
        fun recentCount(now: Long = System.currentTimeMillis()): Int = recentTimes.count { now - it < 86_400_000L }
    }

    fun record(context: Context): Record {
        val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Record(
            count = sp.getInt("crashCount", 0),
            lastError = sp.getString("lastError", null),
            lastAt = sp.getLong("lastCrashAt", 0L),
            recentTimes = (sp.getString("crashTimes", "") ?: "").split(",").mapNotNull { it.toLongOrNull() },
        )
    }
}
