package com.clytrix.core

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.BatteryManager
import android.os.Build
import android.os.Process
import android.os.SystemClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

/**
 * The SYSTEM DIAGNOSTICS center's data and tests.
 *
 * [live] reports current values straight from their sources (no estimates presented as
 * measurements; where something can't be measured on this device it says so). [runFull] performs
 * the self-tests and reports PASS / WARNING / FAIL / NOT TESTED honestly: a hardware check only
 * passes if it actually ran, and checks that need the user (feeling a vibration, turning the bezel)
 * say exactly what was and wasn't verified.
 *
 * Reports contain no photos, no form names, no account data -- counts and app state only.
 */
class Diagnostics(
    private val context: Context,
    private val settings: Settings,
    private val sound: SoundEngine,
    private val haptics: Haptics,
    private val controller: CoreController,
    private val adaptive: AdaptiveCore,
    private val customAliens: CustomAliens,
) {
    enum class Result { PASS, WARNING, FAIL, NOT_TESTED }

    data class Check(val name: String, val result: Result, val detail: String)
    data class Row(val label: String, val value: String)
    data class Section(val title: String, val rows: List<Row>)

    /** Results of the most recent full diagnostic this session, and when it ran. */
    var lastResults: List<Check> = emptyList(); private set
    var lastRunAt: Long = 0L; private set

    private val perf get() = adaptive.perf
    private val evo get() = adaptive.evolution

    fun uptimeMs(): Long = SystemClock.elapsedRealtime() - Process.getStartElapsedRealtime()

    // ---- live readings ------------------------------------------------------------------------------

    fun live(): List<Section> {
        val crash = CrashGuard.record(context)
        val w = perf.lastWindow
        val rt = Runtime.getRuntime()
        val heapUsed = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        val heapMax = rt.maxMemory() / (1024 * 1024)
        val currentNowMa = currentNowMa()
        val evStats = evo.statsFor(settings.activeProfile)
        val sensors = SensorActivity.snapshot()

        return listOf(
            Section("SYSTEM HEALTH", listOf(
                Row("Application", if (controller.illegalTransitions == 0) "Running normally" else "Running (state warnings: ${controller.illegalTransitions})"),
                Row("Device state", controller.phase.name),
                Row("Operating mode", "${settings.powerMode.label} → ${settings.activeProfile.label}"),
                Row("Last detected error", crash.lastError?.let { "$it (${fmtTime(crash.lastAt)})" } ?: "None recorded"),
                Row("Crash recovery", when {
                    CrashGuard.recoveredThisLaunch -> "Recovered from a crash at this launch"
                    crash.count == 0 -> "Armed · no crashes recorded"
                    else -> "Armed · ${crash.count} crash(es) total, ${crash.recentCount()} in 24 h"
                }),
                Row("App uptime", fmtDuration(uptimeMs())),
            )),
            Section("BATTERY", listOf(
                Row("Watch battery", if (adaptive.batteryPct >= 0) "${adaptive.batteryPct}%" + if (adaptive.charging) " · charging" else "" else "Waiting for reading"),
                Row("Selected mode", settings.powerMode.label),
                Row("Optimization activity", settings.profileReason),
                Row("Background processing", buildString {
                    append(if (adaptive.isRunning) "Optimizer active while visible" else "Optimizer paused")
                    append(" · sound worker ${if (sound.workerAlive) "running" else "idle"}")
                    append(" · hum ${if (sound.humPlaying) "playing" else "off"}")
                }),
                Row("App energy estimate", evStats?.takeIf { it.drainSamples >= 1 }?.let {
                    "~${"%.1f".format(it.drainPerHourEma)}%/h measured on ${settings.activeProfile.label} (${it.drainSamples} sample(s), whole watch while CLYTRIX is on screen)"
                } ?: "Not measurable yet (needs a 1% drop while on screen, not charging)"),
                Row("Current draw", currentNowMa?.let { "$it mA (whole watch, instantaneous)" } ?: "Not reported by this watch"),
            )),
            Section("PERFORMANCE", listOf(
                Row("Animation frame rate", w?.let { "${"%.1f".format(it.fps)} fps (cap ${if (it.expectedFps >= 60) "display" else "${it.expectedFps}"})" } ?: "Measuring… (open the dial for a few seconds)"),
                Row("Frame timing", w?.let { "avg ${"%.1f".format(it.avgFrameMs)} ms · p95 ${"%.1f".format(it.p95FrameMs)} ms · janky ${pct(it.jankFraction)} · draw ${"%.2f".format(it.avgDrawMs)} ms" } ?: "—"),
                Row("Memory", "App heap ${heapUsed}/${heapMax} MB · system free ${adaptive.availMemMb}/${adaptive.totalMemMb} MB" + if (adaptive.lowMemory) " · LOW" else ""),
                Row("Input responsiveness", w?.takeIf { it.inputSamples > 0 }?.let { "input→screen avg ${"%.0f".format(it.inputLatencyAvgMs)} ms, max ${"%.0f".format(it.inputLatencyMaxMs)} ms (${it.inputSamples} inputs)" } ?: "No inputs measured in the last window"),
                Row("Sound engine", when {
                    sound.synthesizing -> "Synthesizing ${settings.voiceSet.label} set…"
                    sound.isReady -> "Ready · ${sound.loadedVoiceSet?.label} set · ${sound.effectsPlayedCount} played · built in ${sound.lastSynthMs} ms" +
                        if (adaptive.soundFailuresSession > 0) " · ${adaptive.soundFailuresSession} start failure(s)" else ""
                    else -> "Not ready" + (sound.lastSynthError?.let { ": $it" } ?: "")
                }),
                Row("Sensor activity", if (sensors.isEmpty()) "No sensors registered" else sensors.entries.joinToString(" · ") { "${it.key} (${it.value})" }),
                Row("Thermal status", thermalLabel(adaptive.thermalStatus)),
            )),
            Section("EVOLUTION CORE", listOf(
                Row("Optimization status", if (settings.adaptiveCoreOn) "Active · ${adaptive.budgetRemaining()} adjustment(s) left today" else "Off (observe only)"),
                Row("Adjustments made", "${evo.adjustmentsTotal} total · ${evo.rollbacksTotal} rolled back"),
                Row("Most recent optimization", evo.lastOptimization ?: "None yet"),
                Row("Previous vs current", compareWindows(evo.previousWindow, evo.currentWindow)),
                Row("Rollback history", evo.historySnapshot().filter { it.status == EvolutionCore.Status.RolledBack || it.status == EvolutionCore.Status.Reverted }
                    .take(3).joinToString("\n") { "${fmtTime(it.at)} ${it.knob}: ${it.to} → ${it.from}" }.ifEmpty { "None" }),
                Row("Particle trim", pct(settings.evoParticleScale)),
            )),
            Section("MIRA AI LINK", listOf(
                Row("Connection", when {
                    !MiraLink.enabled -> "Off"
                    !MiraLink.isPaired -> "On · not paired"
                    MiraLink.lastSuccessAt > 0 && System.currentTimeMillis() - MiraLink.lastSuccessAt < 10 * 60_000L -> "Connected · ${MiraLink.pairedClient}"
                    else -> "Paired with ${MiraLink.pairedClient} · no recent contact"
                }),
                Row("Last successful communication", if (MiraLink.lastSuccessAt > 0) fmtTime(MiraLink.lastSuccessAt) else "Never"),
                Row("Connection errors", MiraLink.lastError ?: "None"),
                Row("Permissions granted", listOfNotNull(
                    "control".takeIf { MiraLink.allowControl }, "data".takeIf { MiraLink.allowData },
                    "spoken reports".takeIf { MiraLink.spokenReports },
                ).joinToString(", ").ifEmpty { "None" }),
                Row("Data sharing", if (MiraLink.allowData) "On: battery, diagnostics and Evolution summaries only" else "Off"),
            )),
        )
    }

    private fun compareWindows(a: PerfMonitor.Window?, b: PerfMonitor.Window?): String = when {
        b == null -> "Not enough frames measured yet"
        a == null -> "Now ${"%.1f".format(b.fps)} fps, janky ${pct(b.jankFraction)} (no earlier window)"
        else -> "${"%.1f".format(a.fps)} → ${"%.1f".format(b.fps)} fps · janky ${pct(a.jankFraction)} → ${pct(b.jankFraction)}"
    }

    private fun currentNowMa(): Int? = try {
        val bm = context.getSystemService(BatteryManager::class.java)
        val ua = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: Int.MIN_VALUE
        if (ua == Int.MIN_VALUE || ua == 0) null else kotlin.math.abs(ua) / 1000
    } catch (_: Throwable) { null }

    // ---- RUN FULL DIAGNOSTIC -------------------------------------------------------------------------

    suspend fun runFull(): List<Check> {
        val checks = ArrayList<Check>()
        checks += checkAudio()
        checks += withContext(Dispatchers.IO) { checkSettings() }
        checks += checkStateMachine()
        checks += checkHaptics()
        checks += checkSensors()
        checks += checkBezel()
        checks += withContext(Dispatchers.IO) { checkBackup() }
        checks += checkMira()
        checks += checkEvolution()
        lastResults = checks
        lastRunAt = System.currentTimeMillis()
        return checks
    }

    private suspend fun checkAudio(): Check {
        val name = "Audio engine initialization"
        if (sound.synthesizing && !sound.isReady) return Check(name, Result.WARNING, "Sound set is still being synthesized; run again in a few seconds")
        if (!sound.isReady) return Check(name, Result.FAIL, "Sound set not built" + (sound.lastSynthError?.let { ": $it" } ?: ""))
        val probe = withContext(Dispatchers.IO) { sound.probeOutput() }
        if (!probe) return Check(name, Result.FAIL, "Audio output could not be initialized")
        val vol = sound.mediaVolume()
        return when {
            !sound.hasOutputDevice() -> Check(name, Result.WARNING, "Engine OK, but no speaker or headphones reported")
            vol != null && vol.first == 0 -> Check(name, Result.WARNING, "Engine OK; media volume is 0")
            !settings.soundOn -> Check(name, Result.WARNING, "Engine OK; Sound is switched off in Settings")
            sound.isWatchSilenced() && settings.respectSilent -> Check(name, Result.WARNING, "Engine OK; watch is in silent/vibrate mode")
            else -> Check(name, Result.PASS, "${sound.loadedVoiceSet?.label} set loaded, output initialized (not played aloud)")
        }
    }

    private fun checkSettings(): Check {
        val ok = settings.persistenceSelfTest()
        return if (ok) Check("Settings persistence", Result.PASS, "Write, read back and remove succeeded")
        else Check("Settings persistence", Result.FAIL, "A test value did not survive a write/read round-trip")
    }

    private fun checkStateMachine(): Check {
        val name = "Transformation state machine"
        val graphOk = PhaseGraph.everyPhaseCanRest()
        val inRange = controller.roster.isEmpty() || controller.index in controller.roster.indices
        return when {
            !graphOk -> Check(name, Result.FAIL, "Transition table has a state that can't return to rest")
            controller.illegalTransitions > 0 -> Check(name, Result.WARNING, "${controller.illegalTransitions} unexpected transition(s) this session; last ${controller.lastIllegalTransition}")
            !inRange -> Check(name, Result.WARNING, "Selection index out of range (will self-correct on resume)")
            else -> Check(name, Result.PASS, "Transition table valid; ${controller.transformCount} transformation(s) this session with no illegal transitions; now ${controller.phase}")
        }
    }

    private fun checkHaptics(): Check = when {
        !haptics.available -> Check("Haptic availability", Result.FAIL, "No vibrator reported by the system")
        !settings.hapticsOn -> Check("Haptic availability", Result.WARNING, "Vibrator present; Haptics switched off in Settings")
        else -> Check("Haptic availability", Result.PASS,
            "Vibrator present" + (if (haptics.amplitudeControl) " with amplitude control" else " (on/off only)") + " · not physically verified")
    }

    private fun checkSensors(): Check {
        val sm = context.getSystemService(SensorManager::class.java)
        val linear = sm?.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION) != null
        val accel = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
        val gravity = sm?.getDefaultSensor(Sensor.TYPE_GRAVITY) != null
        val found = listOfNotNull("accelerometer".takeIf { accel }, "linear acceleration".takeIf { linear }, "gravity".takeIf { gravity })
        return when {
            !accel && !linear -> Check("Sensor availability", Result.FAIL, "No motion sensors: tilt and motion activation unavailable")
            !linear || !gravity -> Check("Sensor availability", Result.WARNING, "Found ${found.joinToString()}; using fallbacks for the rest")
            else -> Check("Sensor availability", Result.PASS, "Found ${found.joinToString()}")
        }
    }

    private fun checkBezel(): Check {
        val n = controller.rotaryEvents
        return if (n > 0) Check("Bezel event handling", Result.PASS, "$n rotary event(s) received and handled this session")
        else Check("Bezel event handling", Result.NOT_TESTED, "No bezel turns yet this session. Turn the bezel on the dial, then run again")
    }

    private fun checkBackup(): Check {
        val (ok, detail) = Backup.selfTest(context, customAliens, settings)
        return Check("Backup subsystem integrity", if (ok) Result.PASS else Result.FAIL, detail)
    }

    private suspend fun checkMira(): Check {
        val name = "Mira AI connectivity"
        if (!MiraLink.enabled) return Check(name, Result.NOT_TESTED, "Link is off (optional)")
        if (!MiraLink.isPaired) return Check(name, Result.NOT_TESTED, "Link is on but not paired")
        val reachable = withTimeoutOrNull(4_000L) {
            suspendCancellableCoroutine<Boolean?> { cont -> MiraLink.checkReachable(context) { if (cont.isActive) cont.resume(it) } }
        }
        val recent = MiraLink.lastSuccessAt > 0 && System.currentTimeMillis() - MiraLink.lastSuccessAt < 10 * 60_000L
        return when {
            reachable == true && recent -> Check(name, Result.PASS, "Paired phone reachable; Mira last talked to CLYTRIX ${fmtTime(MiraLink.lastSuccessAt)}")
            reachable == true -> Check(name, Result.WARNING, "Paired phone reachable, but Mira hasn't sent a request in the last 10 minutes (Mira itself not verified)")
            reachable == false -> Check(name, Result.FAIL, "Paired phone not reachable over the Data Layer")
            else -> Check(name, Result.NOT_TESTED, "Couldn't query the Data Layer in time")
        }
    }

    private fun checkEvolution(): Check {
        val problems = evo.configProblems()
        return if (problems.isEmpty()) Check("Evolution Core configuration", Result.PASS,
            "Limits consistent; trim ${pct(settings.evoParticleScale)}; ${evo.historySnapshot().size} adjustment(s) in history")
        else Check("Evolution Core configuration", Result.WARNING, problems.joinToString("; "))
    }

    // ---- report export ------------------------------------------------------------------------------

    fun reportText(): String = buildString {
        appendLine("CLYTRIX DIAGNOSTIC REPORT")
        appendLine("Generated: ${fmtTime(System.currentTimeMillis())}")
        appendLine("App: CLYTRIX ${appVersion()} · Device: ${Build.MANUFACTURER} ${Build.MODEL} · Android API ${Build.VERSION.SDK_INT}")
        appendLine("Forms in roster: ${settings.aliens.size} (names and photos are not included)")
        appendLine()
        if (lastResults.isNotEmpty()) {
            appendLine("FULL DIAGNOSTIC (${fmtTime(lastRunAt)})")
            for (c in lastResults) appendLine("  [${c.result}] ${c.name}: ${c.detail}")
            appendLine()
        } else {
            appendLine("FULL DIAGNOSTIC: not run this session")
            appendLine()
        }
        for (s in live()) {
            appendLine(s.title)
            for (r in s.rows) appendLine("  ${r.label}: ${r.value.replace("\n", "\n    ")}")
            appendLine()
        }
        appendLine("EVOLUTION CORE LEARNED STATS")
        for (p in Profile.values()) {
            val st = evo.statsFor(p)
            appendLine("  ${p.label}: " + (st?.let { "${it.windows} windows, jank ${pct(it.jankEma)}, frame ${"%.1f".format(it.frameMsEma)} ms, drain " +
                if (it.drainSamples > 0) "${"%.1f".format(it.drainPerHourEma)}%/h (${it.drainSamples})" else "n/a" } ?: "no data"))
        }
        appendLine()
        appendLine("RECENT ADJUSTMENTS")
        val h = evo.historySnapshot().take(10)
        if (h.isEmpty()) appendLine("  none")
        for (a in h) appendLine("  ${fmtTime(a.at)} [${a.status}] ${a.knob} ${a.from} → ${a.to} · ${a.reason}")
        appendLine()
        appendLine("Notes: values marked measured come from frame timestamps, input events and battery broadcasts on this watch.")
    }

    /** Writes the report to cache/diagnostics (shared via FileProvider) and returns it. */
    fun exportReport(): File? = try {
        val dir = File(context.cacheDir, "diagnostics").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        File(dir, "clytrix_diagnostics_$stamp.txt").apply { writeText(reportText()) }
    } catch (e: Exception) { null }

    private fun appVersion(): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
    } catch (_: Exception) { "?" }

    companion object {
        fun pct(f: Float) = "${(f * 100).toInt()}%"
        fun fmtTime(ms: Long): String = if (ms <= 0) "—" else SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(ms))
        fun fmtDuration(ms: Long): String {
            val s = ms / 1000
            return when {
                s < 60 -> "${s}s"
                s < 3600 -> "${s / 60}m ${s % 60}s"
                else -> "${s / 3600}h ${(s % 3600) / 60}m"
            }
        }
        fun thermalLabel(t: Int): String = when (t) {
            0 -> "Normal"; 1 -> "Light"; 2 -> "Moderate"; 3 -> "Severe"; 4 -> "Critical"; 5 -> "Emergency"; 6 -> "Shutdown"
            else -> "Not reported"
        }
    }
}
