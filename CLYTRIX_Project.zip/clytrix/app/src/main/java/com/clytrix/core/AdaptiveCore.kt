package com.clytrix.core

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Apexium's Adaptive Core, extended into the executor for CLYTRIX's Smart Battery Management and
 * the Evolution Core. Still a small, transparent, rule-based system (no model, no network), with
 * the same three guard-rails it always had:
 *  - a WHITELIST: it can only change the power profile, the particle-density trim, and -- only
 *    after the user taps Apply -- the handful of settings named in EvolutionPolicy's
 *    recommendations. It never touches the roster, photos, or anything destructive.
 *  - a DAILY BUDGET ([DAILY_BUDGET]) on discretionary autonomous adjustments. Battery-protecting
 *    switches are "essential": always allowed, still logged.
 *  - a LOG of every adjustment with a plain-language reason (Settings > Evolution Core), and
 *    rollback for each one.
 *
 * Runs only while CLYTRIX is visible ([start]/[stop] from onResume/onPause): a battery receiver
 * plus one evaluation every [TICK_MS]. Nothing runs in the background.
 */
class AdaptiveCore(
    private val context: Context,
    private val settings: Settings,
    val perf: PerfMonitor,
) {
    data class LogEntry(val at: Long, val message: String)

    private val sp = context.applicationContext.getSharedPreferences("clytrix_adaptive_core", Context.MODE_PRIVATE)
    private val power = context.applicationContext.getSystemService(PowerManager::class.java)
    private val activity = context.applicationContext.getSystemService(ActivityManager::class.java)
    private val handler = Handler(Looper.getMainLooper())

    val evolution = EvolutionCore(context, settings) { msg, essential -> spend(msg, essential) }

    /** Called on the main thread whenever the active profile changes; [auto] = not the user. */
    var onProfileChanged: ((profile: Profile, auto: Boolean, lowBattery: Boolean) -> Unit)? = null

    private var budgetDay: Long = sp.getLong("budgetDay", dayBucket())
    private var budgetUsed: Int = sp.getInt("budgetUsed", 0)
    private var lastSwitchAt = 0L
    private var running = false

    private var soundFailStreak = 0
    /** Sound start failures this process (for diagnostics and recommendations). */
    var soundFailuresSession by mutableIntStateOf(0); private set

    var batteryPct by mutableIntStateOf(-1); private set
    var charging by mutableStateOf(false); private set
    var thermalStatus by mutableIntStateOf(-1); private set
    var lowMemory by mutableStateOf(false); private set
    var availMemMb by mutableIntStateOf(0); private set
    var totalMemMb by mutableIntStateOf(0); private set
    var lastEvaluatedAt by mutableStateOf(0L); private set

    private val log = ArrayDeque<LogEntry>().apply {
        sp.getString("log", null)?.split("\n")?.filter { it.isNotBlank() }?.forEach { line ->
            val parts = line.split("|", limit = 2)
            val at = parts.getOrNull(0)?.toLongOrNull() ?: return@forEach
            addLast(LogEntry(at, parts.getOrElse(1) { "" }))
        }
        while (size > MAX_LOG) removeFirst()
    }

    /** Most recent adjustment first, for display. */
    fun recentLog(): List<LogEntry> = log.toList().asReversed()

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) {
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) batteryPct = (level * 100f / scale).toInt()
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
            if (batteryPct >= 0) evolution.onBattery(batteryPct, charging, settings.activeProfile)
            evaluate()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            evolution.onWindow(perf.closeWindow(), settings.activeProfile)
            evaluate()
            handler.postDelayed(this, TICK_MS)
        }
    }

    /** Registers the battery listener and the evaluation tick; pair with [stop]. */
    fun start() {
        if (running) return
        running = true
        try {
            context.applicationContext.registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (e: Throwable) {
            Log.w(TAG, "Could not register battery receiver", e)
        }
        perf.resetChain()
        evaluate()
        handler.postDelayed(ticker, TICK_MS)
    }

    fun stop() {
        if (!running) return
        running = false
        handler.removeCallbacks(ticker)
        try { context.applicationContext.unregisterReceiver(batteryReceiver) } catch (_: Throwable) { }
        evolution.resetDrainAnchor()
    }

    val isRunning: Boolean get() = running

    /** Call whenever SoundEngine's AudioTrack fails to initialise. Thread-safe enough: posts to main. */
    fun reportSoundFailure() {
        handler.post {
            soundFailuresSession += 1
            soundFailStreak += 1
            if (soundFailStreak >= SOUND_FAIL_LIMIT && settings.soundOn && settings.adaptiveCoreOn) {
                if (spend("Sound kept failing to start on this device, so it was turned off automatically. You can turn it back on in Sound and Haptics.", true)) {
                    settings.updateSoundOn(false)
                    soundFailStreak = 0
                }
            }
        }
    }

    /** Call whenever SoundEngine successfully starts a clip -- clears the failure streak. */
    fun reportSoundSuccess() { handler.post { soundFailStreak = 0 } }

    fun signals(): EvolutionPolicy.Signals = EvolutionPolicy.Signals(
        batteryPct = batteryPct,
        charging = charging,
        systemSaver = power?.isPowerSaveMode == true,
        thermal = thermalStatus,
        lowMemory = lowMemory,
    )

    // ---- the policy ---------------------------------------------------------------------------------

    /** Re-reads conditions and applies the right profile. Called on every mode change, battery
     *  update and tick; cheap enough to call freely. */
    fun evaluate() {
        sampleSystem()
        lastEvaluatedAt = System.currentTimeMillis()
        val mode = settings.powerMode
        val current = settings.activeProfile
        val fixed = mode.fixedProfile()
        when {
            fixed != null -> apply(fixed, "${fixed.label}: selected by you", auto = false)
            !settings.adaptiveCoreOn -> apply(Profile.Balanced, "Balanced: Evolution Core is off, so Adaptive mode holds Balanced", auto = false)
            else -> {
                val hold = evolution.activeHold()
                val s = signals()
                if (hold != null && EvolutionPolicy.conditionRank(s) <= hold.rank && hold.rank in settings.adaptiveCeiling..settings.adaptiveFloor) {
                    apply(hold, "${hold.label}: held after your rollback", auto = false)
                    return
                }
                val since = if (lastSwitchAt == 0L) Long.MAX_VALUE else SystemClock.elapsedRealtime() - lastSwitchAt
                val d = EvolutionPolicy.choose(current, evolution.statsSnapshot(), s, settings.adaptiveCeiling, settings.adaptiveFloor, since)
                if (d.changed) {
                    // Moving to a lighter profile protects the battery/heat: essential, never budget-blocked.
                    val essential = d.profile.rank > current.rank
                    if (!spend(d.reason, essential)) { settings.profileReason = "${current.label}: daily adjustment budget used"; return }
                    evolution.recordProfileSwitch(current, d.profile, d.reason)
                }
                apply(d.profile, d.reason, auto = d.changed)
            }
        }
    }

    private fun apply(p: Profile, reason: String, auto: Boolean) {
        settings.profileReason = reason
        val prev = settings.activeProfile
        if (p == prev) return
        settings.activeProfile = p
        lastSwitchAt = SystemClock.elapsedRealtime()
        evolution.resetDrainAnchor()
        if (auto) settings.profileNotice = "${p.label.uppercase()} ENGAGED"
        val lowBattery = auto && p == Profile.Ultra && !charging && batteryPct in 1..15
        onProfileChanged?.invoke(p, auto, lowBattery)
    }

    private fun sampleSystem() {
        thermalStatus = try { power?.currentThermalStatus ?: -1 } catch (_: Throwable) { -1 }
        try {
            val mi = ActivityManager.MemoryInfo()
            activity?.getMemoryInfo(mi)
            lowMemory = mi.lowMemory
            availMemMb = (mi.availMem / (1024 * 1024)).toInt()
            totalMemMb = (mi.totalMem / (1024 * 1024)).toInt()
        } catch (_: Throwable) { }
    }

    /**
     * Logs [message] and, unless [essential], spends one unit of today's budget; returns false
     * (changing nothing) once [DAILY_BUDGET] is used up.
     */
    fun spend(message: String, essential: Boolean = false): Boolean {
        val today = dayBucket()
        if (today != budgetDay) { budgetDay = today; budgetUsed = 0 }
        if (!essential && budgetUsed >= DAILY_BUDGET) return false
        if (!essential) budgetUsed += 1
        log.addLast(LogEntry(System.currentTimeMillis(), message))
        while (log.size > MAX_LOG) log.removeFirst()
        sp.edit()
            .putLong("budgetDay", budgetDay)
            .putInt("budgetUsed", budgetUsed)
            .putString("log", log.joinToString("\n") { "${it.at}|${it.message.replace("\n", " ")}" })
            .apply()
        return true
    }

    fun budgetRemaining(): Int {
        if (dayBucket() != budgetDay) return DAILY_BUDGET
        return (DAILY_BUDGET - budgetUsed).coerceAtLeast(0)
    }

    private fun dayBucket(): Long = System.currentTimeMillis() / 86_400_000L

    companion object {
        private const val TAG = "ClytrixAdaptiveCore"
        const val SOUND_FAIL_LIMIT = 3
        const val DAILY_BUDGET = 12
        const val MAX_LOG = 12
        const val TICK_MS = 30_000L
    }
}
