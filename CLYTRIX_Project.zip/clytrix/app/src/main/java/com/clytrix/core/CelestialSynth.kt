package com.clytrix.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

/**
 * CLYTRIX's own sound set: luminous, bell-and-choir "celestial machinery", synthesized entirely
 * from maths like Apexium's [AlienSynth] (no audio files, nothing sampled from anywhere). It reuses
 * AlienSynth's proven building blocks for the *mechanical* layer -- [AlienSynth.clank] latches,
 * [AlienSynth.whir] servos, [AlienSynth.powerBoom] weight, [AlienSynth.reverb] -- and adds four
 * celestial voices of its own:
 *
 *  - [bell]: an inharmonic glass/bronze bell (partials at 1, 2, 2.76, 4.07, 5.43 x the fundamental,
 *    each decaying at its own rate, the pair of top partials slightly detuned so it shimmers).
 *  - [pad]: a slow "choir" swell of detuned sines with a soft octave and fifth -- light, not drone.
 *  - [sparkle]: scattered tiny high bells, like starlight.
 *  - [riser]: a smooth FM glide upward (or downward) -- energy gathering.
 *
 * Everything is tuned to one bright, open (D major pentatonic) palette so the whole device sounds
 * like one instrument. The Ascension variant is a fuller second wave on top of the transformation,
 * an octave higher, rather than a pitched-down copy.
 *
 * Plain Kotlin, no Android: covered by CelestialSynthTest (every clip renders, is non-empty, has no
 * NaN/clipping overflow, and the hum loops without a click).
 */
object CelestialSynth {
    const val SR = AlienSynth.SR
    private const val TWO_PI = 2.0 * PI

    // D major pentatonic palette (Hz)
    private const val D3 = 146.83
    private const val A3 = 220.0
    private const val D4 = 293.66
    private const val A4 = 440.0
    private const val D5 = 587.33
    private const val E5 = 659.26
    private const val A5 = 880.0
    private const val D6 = 1174.66
    private const val A6 = 1760.0
    private const val D7 = 2349.32
    private val TICK_NOTES = doubleArrayOf(1174.66, 1318.51, 1479.98, 1760.0, 1975.53, 2349.32, 2637.02)

    // -------------------------------------------------------------------------------------------
    // Building blocks
    // -------------------------------------------------------------------------------------------

    private fun n(seconds: Double) = max(1, (seconds * SR).toInt())

    private fun mix(dst: FloatArray, src: FloatArray, atSec: Double, gain: Float = 1f) {
        val off = (atSec * SR).toInt()
        val fadeIn = (0.003 * SR).toInt()
        val fadeOut = (0.02 * SR).toInt()
        for (i in src.indices) {
            val j = off + i
            if (j !in dst.indices) continue
            var g = gain
            if (i < fadeIn) g *= i / fadeIn.toFloat()
            val left = src.size - i
            if (left < fadeOut) g *= left / fadeOut.toFloat()
            dst[j] += src[i] * g
        }
    }

    /** Inharmonic bell. [decay] = fundamental decay rate (higher = shorter); [bright] scales upper partials. */
    fun bell(dur: Double, f: Double, decay: Double = 3.0, bright: Double = 1.0): FloatArray {
        val ratios = doubleArrayOf(1.0, 2.0, 2.76, 4.07, 5.43)
        val amps = doubleArrayOf(1.0, 0.42, 0.58 * bright, 0.30 * bright, 0.17 * bright)
        val decays = doubleArrayOf(1.0, 1.35, 1.9, 2.6, 3.4)
        val out = FloatArray(n(dur))
        for (k in ratios.indices) {
            val fk = f * ratios[k]
            if (fk > SR * 0.45) continue
            val beat = if (k >= 3) 0.9 else 0.0
            for (i in out.indices) {
                val t = i / SR.toDouble()
                val env = exp(-decay * decays[k] * t) * min(1.0, t / 0.002)
                var s = sin(TWO_PI * fk * t)
                if (beat > 0.0) s = 0.5 * (s + sin(TWO_PI * (fk + beat) * t))
                out[i] += (amps[k] * s * env).toFloat()
            }
        }
        return out
    }

    /** Choir-like swell: detuned sines plus a soft octave and fifth. */
    fun pad(dur: Double, f: Double, attack: Double, release: Double, voices: Int = 5, detuneCents: Double = 9.0): FloatArray {
        val out = FloatArray(n(dur))
        val total = dur
        for (v in 0 until voices) {
            val cents = if (voices == 1) 0.0 else (v / (voices - 1.0) - 0.5) * 2 * detuneCents
            val fv = f * 2.0.pow(cents / 1200.0)
            val ph = v * 1.7
            for (i in out.indices) {
                val t = i / SR.toDouble()
                val env = when {
                    t < attack -> (t / attack).pow(1.6)
                    t > total - release -> ((total - t) / release).coerceIn(0.0, 1.0).pow(1.3)
                    else -> 1.0
                }
                val vib = 1.0 + 0.0025 * sin(TWO_PI * (4.6 + v * 0.3) * t + ph)
                val s = sin(TWO_PI * fv * vib * t + ph) + 0.28 * sin(TWO_PI * 2 * fv * t + ph) + 0.18 * sin(TWO_PI * 1.5 * fv * t)
                out[i] += (s * env / voices).toFloat()
            }
        }
        return out
    }

    /** Scattered tiny high bells. */
    fun sparkle(dur: Double, count: Int, seed: Int, fLo: Double = 2200.0, fHi: Double = 5200.0): FloatArray {
        val out = FloatArray(n(dur))
        val rnd = Random(seed)
        repeat(count) {
            val at = rnd.nextDouble() * dur * 0.9
            val f = fLo + rnd.nextDouble() * (fHi - fLo)
            val b = bell(0.18 + rnd.nextDouble() * 0.2, f, decay = 14.0 + rnd.nextDouble() * 10, bright = 0.4)
            mix(out, b, at, (0.25 + rnd.nextDouble() * 0.35).toFloat())
        }
        return out
    }

    /** Smooth FM glide from [f0] to [f1], amplitude swelling toward the end (or fading if [fall]). */
    fun riser(dur: Double, f0: Double, f1: Double, fall: Boolean = false): FloatArray =
        AlienSynth.glide(dur, f0, f1, curve = 1.2, ratio = 2.0, index = 0.9) { p ->
            if (fall) (1 - p).pow(1.4) * min(1.0, p * 20) else p.pow(1.5) * min(1.0, (1 - p) * 25)
        }

    /** Gentle one-pole low-pass, much brighter than AlienSynth's 3.2 kHz "warm" pass, so bells ring. */
    private fun lowpass(x: FloatArray, cutoffHz: Double): FloatArray {
        val a = (1.0 - exp(-TWO_PI * cutoffHz / SR)).toFloat()
        val out = FloatArray(x.size)
        var y = 0f
        for (i in x.indices) { y += a * (x[i] - y); out[i] = y }
        return out
    }

    /** Normalise to [peak], soft-clip, short edge fades, 16-bit PCM. */
    fun toPcm(input: FloatArray, peak: Float = 0.82f, cutoffHz: Double = 7500.0): ShortArray {
        val x = lowpass(input, cutoffHz)
        var m = 0f
        for (v in x) m = max(m, abs(v))
        val g = if (m > 1e-6f) 1f / m else 1f
        val norm = tanh(1.3f)
        val fade = (0.02 * SR).toInt()
        return ShortArray(x.size) { i ->
            var v = tanh(x[i] * g * 1.3f) / norm * peak
            if (i < 32) v *= i / 32f
            if (i > x.size - fade) v *= (x.size - i) / fade.toFloat()
            (v * Short.MAX_VALUE).toInt().coerceIn(-32767, 32767).toShort()
        }
    }

    private fun reversed(x: FloatArray) = FloatArray(x.size) { x[x.size - 1 - it] }

    // -------------------------------------------------------------------------------------------
    // The sound set
    // -------------------------------------------------------------------------------------------

    /** Selection movement: a crystal tick, a different pentatonic note per step. */
    fun tick(k: Int): ShortArray {
        val b = FloatArray(n(0.24))
        mix(b, bell(0.2, TICK_NOTES[Math.floorMod(k, TICK_NOTES.size)], decay = 16.0, bright = 0.7), 0.0, 0.55f)
        mix(b, AlienSynth.clank(0.04, 1900.0, drive = 1.3, seed = 300 + k, decayMul = 3.0), 0.0, 0.12f)
        return toPcm(AlienSynth.reverb(b, 0.12f, 0.12, 0.5f), 0.55f)
    }

    /** Mechanical opening: a servo spinning up, eight segment latches releasing in sequence,
     *  a choir swell, and two bells as the core is uncovered. */
    fun open(): ShortArray {
        val b = FloatArray(n(2.0))
        mix(b, AlienSynth.whir(1.0, 80.0, 900.0, motorHz = 11.0, q = 5.0, seed = 21, noiseGain = 0.8), 0.0, 0.33f)
        for (i in 0 until 8) mix(b, AlienSynth.clank(0.12, 420.0 + i * 22, drive = 1.6, seed = 40 + i, decayMul = 1.6), 0.15 + i * 0.07, 0.32f)
        mix(b, pad(1.7, D3, attack = 0.8, release = 0.6), 0.0, 0.5f)
        mix(b, riser(1.0, A3, A5), 0.3, 0.18f)
        mix(b, bell(1.4, D5, decay = 2.2), 0.86, 0.55f)
        mix(b, bell(1.4, A5, decay = 2.6), 0.92, 0.4f)
        mix(b, sparkle(0.7, 10, seed = 11), 0.9, 0.25f)
        return toPcm(AlienSynth.reverb(b, 0.5f, 1.6, 0.84f), 0.8f)
    }

    /** Core activation: a widening three-voice choir, a deep pulse of power, a rising glide and a
     *  bright bell cascade as the core lights. */
    fun activate(): ShortArray {
        val b = FloatArray(n(2.6))
        mix(b, pad(2.5, D3, attack = 0.5, release = 1.2), 0.0, 0.6f)
        mix(b, pad(2.4, A3, attack = 0.7, release = 1.2), 0.05, 0.45f)
        mix(b, pad(2.2, D4, attack = 0.9, release = 1.0), 0.1, 0.35f)
        mix(b, AlienSynth.powerBoom(0.9, 36.0, 3.5, drive = 3.0), 0.0, 0.65f)
        mix(b, riser(1.2, D4, D6), 0.0, 0.22f)
        mix(b, bell(1.5, D5, decay = 2.0), 1.0, 0.5f)
        mix(b, bell(1.5, A5, decay = 2.3), 1.06, 0.42f)
        mix(b, bell(1.4, D6, decay = 2.7), 1.12, 0.32f)
        mix(b, sparkle(1.0, 18, seed = 12), 1.0, 0.3f)
        return toPcm(AlienSynth.reverb(b, 0.6f, 2.2, 0.88f), 0.85f)
    }

    /** Closing: servo winding down, the segment latches re-seating in reverse, a fading chord. */
    fun close(): ShortArray {
        val b = FloatArray(n(1.5))
        mix(b, AlienSynth.whir(0.7, 900.0, 70.0, motorHz = 15.0, q = 5.0, seed = 61, curve = 1.2, noiseGain = 0.8), 0.0, 0.33f)
        for (i in 0 until 8) mix(b, AlienSynth.clank(0.1, 560.0 - i * 18, drive = 1.6, seed = 70 + i, decayMul = 1.8), 0.05 + i * 0.05, 0.3f)
        mix(b, pad(1.0, D3, attack = 0.04, release = 0.8), 0.0, 0.35f)
        mix(b, bell(1.0, A4, decay = 3.0), 0.42, 0.35f)
        mix(b, AlienSynth.powerBoom(0.4, 44.0, 7.0, drive = 2.5), 0.42, 0.45f)
        return toPcm(AlienSynth.reverb(b, 0.42f, 1.1, 0.82f), 0.78f)
    }

    /** Transformation confirmation: two rising bells -- "accepted". */
    fun confirm(): ShortArray {
        val b = FloatArray(n(0.55))
        mix(b, bell(0.4, D6, decay = 9.0), 0.0, 0.6f)
        mix(b, bell(0.45, A6, decay = 8.0), 0.08, 0.6f)
        mix(b, sparkle(0.3, 5, seed = 13), 0.05, 0.2f)
        return toPcm(AlienSynth.reverb(b, 0.25f, 0.4, 0.6f), 0.72f)
    }

    private fun transformRaw(ascension: Boolean): FloatArray {
        val b = FloatArray(n(if (ascension) 4.4 else 3.2))
        // the release: a mechanical lock, a deep pulse and a bright bloom of light
        mix(b, AlienSynth.clank(0.3, 140.0, drive = 2.4, seed = 81, decayMul = 0.8), 0.0, 0.5f)
        mix(b, AlienSynth.powerBoom(1.2, 30.0, 2.4, drive = 4.0), 0.02, 1.25f)
        mix(b, AlienSynth.noiseSweep(0.8, 300.0, 6000.0, decay = 2.4, seed = 87), 0.02, 0.45f)
        // the radiant chord: five bells at once
        val chord = doubleArrayOf(D4, A4, D5, A5, D6)
        for ((i, f) in chord.withIndex()) mix(b, bell(2.2, f, decay = 1.2 + i * 0.15), 0.03 + i * 0.012, 0.6f - i * 0.06f)
        mix(b, riser(1.4, A4, A6), 0.0, 0.24f)
        mix(b, sparkle(1.6, 28, seed = 88), 0.05, 0.35f)
        // the choir that carries the new form
        mix(b, pad(3.0, D3, attack = 0.2, release = 2.0), 0.0, 0.5f)
        mix(b, pad(3.0, A3, attack = 0.25, release = 2.0), 0.0, 0.4f)
        mix(b, pad(2.8, D4, attack = 0.3, release = 1.8), 0.05, 0.3f)
        mix(b, riser(1.6, D7, D5, fall = true), 0.6, 0.1f)
        if (ascension) {
            // Ascension: a second, fuller wave an octave higher -- light rising, not a darker copy.
            val t2 = 0.9
            mix(b, AlienSynth.powerBoom(1.0, 26.0, 2.2, drive = 4.2), t2, 0.9f)
            val high = doubleArrayOf(D5, A5, D6, A6, D7)
            for ((i, f) in high.withIndex()) mix(b, bell(2.6, f, decay = 1.0 + i * 0.12), t2 + i * 0.05, 0.5f - i * 0.05f)
            mix(b, riser(2.0, A3, D7), t2 - 0.6, 0.3f)
            mix(b, pad(3.4, A3 / 2, attack = 0.6, release = 2.4), t2 - 0.3, 0.45f)
            mix(b, pad(3.2, E5, attack = 0.8, release = 2.2), t2, 0.22f)
            mix(b, sparkle(2.4, 45, seed = 89, fLo = 2600.0, fHi = 6500.0), t2, 0.45f)
        }
        return AlienSynth.reverb(b, if (ascension) 0.7f else 0.62f, if (ascension) 3.0 else 2.6, 0.9f)
    }

    fun transform(): ShortArray = toPcm(transformRaw(false), 0.9f)

    /** Ascension Mode's transformation. */
    fun ascension(): ShortArray = toPcm(transformRaw(true), 0.92f)

    private fun revertRaw(ascension: Boolean): FloatArray {
        val rev = reversed(transformRaw(false))
        val len = n(2.0)
        val tail = rev.copyOfRange(max(0, rev.size - len), rev.size)
        val out = FloatArray(len + n(1.3))
        mix(out, tail, 0.0, 0.8f)
        mix(out, riser(1.6, A6, A3, fall = true), 0.0, 0.22f)
        mix(out, AlienSynth.whir(1.4, 1600.0, 60.0, motorHz = 14.0, q = 5.0, seed = 95, curve = 1.5, noiseGain = 0.7), 0.1, 0.25f)
        if (ascension) mix(out, sparkle(1.6, 24, seed = 96, fLo = 1800.0, fHi = 4800.0), 0.0, 0.35f)
        val end = len / SR.toDouble()
        mix(out, AlienSynth.clank(0.35, 120.0, drive = 2.6, seed = 97, decayMul = 0.8), end - 0.02, 0.7f)
        mix(out, AlienSynth.powerBoom(0.7, 32.0, 4.5, drive = 3.6), end - 0.03, 0.9f)
        mix(out, bell(1.2, D4, decay = 2.4), end - 0.02, 0.45f)
        return AlienSynth.reverb(out, 0.48f, 1.5, 0.86f)
    }

    fun revert(): ShortArray = toPcm(revertRaw(false), 0.88f)
    fun revertAscended(): ShortArray = toPcm(revertRaw(true), 0.88f)

    private fun warningRaw(): FloatArray {
        val b = FloatArray(n(1.2))
        for (i in 0 until 3) {
            val t = 0.3 * i
            val g = 0.45f + 0.1f * i
            mix(b, bell(0.32, A5, decay = 10.0), t, g)
            mix(b, bell(0.32, 932.33, decay = 10.0), t, g) // a semitone apart: they beat, urgently
            mix(b, AlienSynth.edge(0.22, 466.16, shape = 0.4, decay = 11.0), t, 0.18f)
        }
        return AlienSynth.reverb(b, 0.3f, 0.6, 0.7f)
    }

    /** Warning alert (low battery, failed action needing attention). */
    fun warning(): ShortArray = toPcm(warningRaw(), 0.8f)

    /** Transformation time ran out: the warning, then the reversion. */
    fun timeout(): ShortArray {
        val w = warningRaw()
        val r = revertRaw(false)
        val out = FloatArray(max(w.size, n(0.9) + r.size))
        mix(out, w, 0.0, 0.9f)
        mix(out, r, 0.9, 1.0f)
        return toPcm(out, 0.88f)
    }

    /** Recharge complete: a soft chord settling into place. */
    fun recharged(): ShortArray {
        val b = FloatArray(n(1.4))
        mix(b, pad(1.2, A3, attack = 0.3, release = 0.8), 0.0, 0.4f)
        mix(b, bell(1.2, D5, decay = 3.0), 0.05, 0.5f)
        mix(b, bell(1.2, A5, decay = 3.5), 0.15, 0.35f)
        mix(b, AlienSynth.clank(0.2, 900.0, drive = 1.4, seed = 62, decayMul = 2.0), 0.05, 0.15f)
        return toPcm(AlienSynth.reverb(b, 0.45f, 1.0, 0.82f), 0.75f)
    }

    /** Re-scanning the roster: a quick ascending run of five bells. */
    fun recalibrate(): ShortArray {
        val b = FloatArray(n(0.9))
        val notes = doubleArrayOf(D5, E5, 739.99, A5, 987.77)
        for ((i, f) in notes.withIndex()) mix(b, bell(0.3, f * 2, decay = 12.0, bright = 0.6), i * 0.06, 0.45f)
        mix(b, sparkle(0.5, 8, seed = 14), 0.25, 0.22f)
        return toPcm(AlienSynth.reverb(b, 0.3f, 0.5, 0.65f), 0.72f)
    }

    /** A blocked action: a low, falling bell pair with a soft buzz. */
    fun error(): ShortArray {
        val b = FloatArray(n(0.5))
        mix(b, bell(0.3, 311.13, decay = 8.0), 0.0, 0.55f)
        mix(b, bell(0.35, D4, decay = 7.0), 0.12, 0.55f)
        mix(b, AlienSynth.edge(0.2, 155.56, shape = 0.8, decay = 9.0), 0.0, 0.18f)
        return toPcm(AlienSynth.reverb(b, 0.2f, 0.35, 0.55f), 0.7f)
    }

    /**
     * Ambient energy hum, loopable without a click: every component completes a whole number of
     * cycles in [LOOP_SEC] (73.5, 110, 146.5, 220 Hz x 6 s are all integers, as are the 1/6 Hz and
     * 1/3 Hz breathing and the 0.5 Hz shimmer vibrato), and the reverb tail is wrapped by rendering
     * two loops and keeping the second.
     */
    fun hum(): ShortArray {
        val len = n(LOOP_SEC)
        val two = FloatArray(len * 2)
        val tones = doubleArrayOf(73.5, 110.0, 146.5, 220.0)
        val gains = doubleArrayOf(0.55, 0.45, 0.3, 0.16)
        for (i in two.indices) {
            val t = i / SR.toDouble()
            val breathe = 0.6 + 0.4 * (0.5 + 0.5 * sin(TWO_PI * t / LOOP_SEC))
            val breathe2 = 0.75 + 0.25 * (0.5 + 0.5 * sin(TWO_PI * 2 * t / LOOP_SEC + 1.3))
            var s = 0.0
            for (k in tones.indices) s += gains[k] * sin(TWO_PI * tones[k] * t + k * 0.9)
            s *= breathe * breathe2
            s += 0.035 * sin(TWO_PI * 587.0 * t + 2.5 * sin(TWO_PI * 0.5 * t)) * breathe2
            two[i] = s.toFloat()
        }
        val wet = AlienSynth.reverb(two, 0.4f, 0.0, 0.8f)
        val loop = FloatArray(len) { wet[len + it] }
        var m = 0f
        for (v in loop) m = max(m, abs(v))
        val g = if (m > 1e-6f) 1f / m else 1f
        val norm = tanh(1.1f)
        return ShortArray(len) { i -> ((tanh(loop[i] * g * 1.1f) / norm * 0.5f) * Short.MAX_VALUE).toInt().coerceIn(-32767, 32767).toShort() }
    }

    const val LOOP_SEC = 6.0
    const val TICK_VARIANTS = 7
}
