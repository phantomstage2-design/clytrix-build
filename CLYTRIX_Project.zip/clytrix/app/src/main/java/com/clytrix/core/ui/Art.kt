package com.clytrix.core.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import com.clytrix.core.Alien
import com.clytrix.core.CrashGuard
import com.clytrix.core.CustomAliens
import com.clytrix.core.ImageSource
import com.clytrix.core.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Lazily decodes and caches alien bitmaps -- bundled device art from resources, alien art from
 * either a bundled resource or a photo the user picked, copied into private storage by
 * [CustomAliens].
 *
 * Self-healing: a photo that fails to decode (corrupted file, ran out of storage mid-copy) never
 * crashes the draw -- a blank placeholder is cached in its place and the alien's id is recorded in
 * [consumeBroken], deliberately as a plain (non-Compose) collection. [alien] can be called from
 * anywhere a bitmap is needed, including a composable's body or a Canvas draw block, where writing
 * Compose state directly is unsafe; [rememberArt]'s drain loop is what turns a broken id into an
 * actual (safe, coroutine-side) state change.
 */
class Art(private val context: Context, private val customAliens: CustomAliens) {
    private val aliens = HashMap<String, ImageBitmap>()
    private val brokenIds = mutableSetOf<String>()

    private fun load(id: Int): ImageBitmap =
        BitmapFactory.decodeResource(context.resources, id).asImageBitmap()

    @Synchronized
    fun alien(alien: Alien): ImageBitmap = aliens.getOrPut(alien.id) {
        CrashGuard.mark("alien:" + alien.id)
        val decoded = try {
            when (val src = alien.source) {
                is ImageSource.Bundled -> load(src.resId)
                is ImageSource.Custom ->
                    BitmapFactory.decodeFile(customAliens.file(src).absolutePath)?.asImageBitmap()
            }
        } catch (e: Throwable) {
            null
        }
        if (decoded == null) {
            brokenIds.add(alien.id)
            blankPlaceholder()
        } else {
            decoded
        }
    }

    private fun blankPlaceholder(): ImageBitmap =
        Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888).asImageBitmap()

    @Synchronized
    fun forget(alien: Alien) { aliens.remove(alien.id) }

    suspend fun preload(list: List<Alien>) = withContext(Dispatchers.Default) {
        for (a in list) alien(a)
    }

    @Synchronized
    fun consumeBroken(): List<String> {
        if (brokenIds.isEmpty()) return emptyList()
        val out = brokenIds.toList()
        brokenIds.clear()
        return out
    }
}

/** Remembers an [Art] cache for the current alien playlist. */
@Composable
fun rememberArt(customAliens: CustomAliens, aliens: List<Alien>, onBroken: (Alien) -> Unit = {}): Art {
    val context = LocalContext.current
    val art = remember { Art(context.applicationContext, customAliens) }
    LaunchedEffect(aliens.size) { art.preload(aliens) }

    val currentAliens by rememberUpdatedState(aliens)
    val currentOnBroken by rememberUpdatedState(onBroken)
    LaunchedEffect(art) {
        while (true) {
            val ids = art.consumeBroken()
            if (ids.isNotEmpty()) {
                val byId = currentAliens.associateBy { it.id }
                for (id in ids) byId[id]?.let(currentOnBroken)
            }
            delay(300)
        }
    }
    return art
}
