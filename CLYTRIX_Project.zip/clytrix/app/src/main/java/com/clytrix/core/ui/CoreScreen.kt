package com.clytrix.core.ui

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.rotary.onRotaryScrollEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Text
import com.clytrix.core.CoreController
import com.clytrix.core.PerfMonitor
import com.clytrix.core.Phase
import com.clytrix.core.Profile
import com.clytrix.core.TiltSensor
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs
import kotlin.math.sin

private enum class Gesture { Tap, LongPress, Drag, Cancel }

/**
 * The main screen: one full-screen surface that draws whichever phase the [CoreController] is in
 * and forwards bezel, touch, swipe and tilt input to it.
 *
 * Controls
 *  - rotate bezel (or swipe up/down): choose a form
 *  - tap: open / transform (Tap activation) / revert
 *  - long-press while selecting: transform (Long-press activation) or recalibrate (Tap activation)
 *  - long-press elsewhere: revert / open Settings while locked / wake from disguise
 *  - Back key: open the dial / close it / revert
 *  - swipe left: Settings
 *
 * Animation runs on one throttled frame clock ([rememberFrameClock]) whose cap comes from the
 * active power profile, so Balanced and Ultra genuinely draw fewer frames instead of drawing the
 * same frames with less in them. Every drawn frame is timed into [PerfMonitor].
 */
@Composable
fun CoreScreen(controller: CoreController, art: Art, perf: PerfMonitor, onOpenSettings: () -> Unit) {
    val settings = controller.settings
    val basePal = paletteFor(settings.skin)
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    BackHandler(
        enabled = controller.phase == Phase.Locked || controller.phase == Phase.Selecting || controller.phase == Phase.Active,
    ) { controller.onBackKey() }

    // Timed phases.
    LaunchedEffect(controller.phase) {
        when (controller.phase) {
            Phase.Opening -> controller.runOpening()
            Phase.Flashing -> controller.runFlash()
            Phase.Active -> controller.runActive()
            Phase.Recharging -> controller.runRecharge()
            else -> Unit
        }
    }

    var flashVisible by remember { mutableStateOf(false) }
    LaunchedEffect(controller.flashCount) {
        if (controller.flashCount > 0) { flashVisible = true; delay(1000); flashVisible = false }
    }

    var overdriveCelebration by remember { mutableStateOf(false) }
    LaunchedEffect(settings.progress.overdriveUnlocked) {
        if (settings.progress.overdriveUnlocked && settings.progress.totalTransforms == com.clytrix.core.Progress.UNLOCK_AT) {
            overdriveCelebration = true; delay(2200); overdriveCelebration = false
        }
    }

    var holdHint by remember { mutableStateOf(false) }
    LaunchedEffect(controller.holdHintCount) {
        if (controller.holdHintCount > 0) { holdHint = true; delay(1300); holdHint = false }
    }

    // Profile-change banner ("ULTRA BATTERY SAVER ENGAGED"), then cleared.
    val notice = settings.profileNotice
    LaunchedEffect(notice) { if (notice != null) { delay(2600); settings.profileNotice = null } }

    // ---- tilt sensor: only while parallax is allowed by both the user and the profile -----------
    var tiltX by remember { mutableFloatStateOf(0f) }
    var tiltY by remember { mutableFloatStateOf(0f) }
    val context = LocalContext.current
    val fastTilt = settings.activeProfile == Profile.Performance
    DisposableEffect(settings.effectiveParallaxOn, fastTilt) {
        if (!settings.effectiveParallaxOn) { tiltX = 0f; tiltY = 0f; return@DisposableEffect onDispose {} }
        val sensor = TiltSensor(context, fast = fastTilt) { x, y -> tiltX = x; tiltY = y }
        sensor.start()
        onDispose { sensor.stop() }
    }

    val particles = remember { ParticleField() }
    LaunchedEffect(settings.effectiveParticlesOn) { if (!settings.effectiveParticlesOn) particles.clear() }

    val cap = when (controller.phase) {
        Phase.Flashing -> 0
        Phase.Locked, Phase.Disguised, Phase.Recharging -> settings.activeProfile.lockedFpsCap
        else -> settings.activeProfile.idleFpsCap
    }
    val time = rememberFrameClock(cap, if (settings.effectiveParticlesOn) particles else null)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onRotaryScrollEvent { event ->
                controller.onRotary(event.verticalScrollPixels, event.uptimeMillis)
                true
            }
            .focusRequester(focus)
            .focusable()
            .pointerInput(Unit) {
                // One handler for tap, long-press and drag (Apexium's design): a slightly rolling
                // fingertip may wander up to 24dp during the hold and it still counts as a long-press.
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val slop = 24.dp.toPx()
                    val holdMs = settings.longPressMs
                    val stepPx = settings.dragStepPx
                    controller.noteInput(down.uptimeMillis)

                    val decided: Gesture? = withTimeoutOrNull(holdMs) {
                        var result: Gesture? = null
                        while (result == null) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id }
                            result = when {
                                change == null -> Gesture.Cancel
                                change.changedToUpIgnoreConsumed() -> Gesture.Tap
                                (change.position - down.position).getDistance() > slop -> Gesture.Drag
                                else -> null
                            }
                        }
                        result
                    }

                    when (decided ?: Gesture.LongPress) {
                        Gesture.Tap -> if (controller.onTap()) onOpenSettings()

                        Gesture.LongPress -> {
                            if (controller.onLongPress()) onOpenSettings()
                            while (true) {
                                val event = awaitPointerEvent()
                                if (event.changes.none { it.pressed }) break
                            }
                        }

                        Gesture.Drag -> {
                            var lastY = down.position.y
                            var totalX = 0f
                            var totalY = 0f
                            var stepAcc = 0f
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                if (!change.pressed) break
                                change.consume()
                                totalX = change.position.x - down.position.x
                                totalY = change.position.y - down.position.y
                                stepAcc += change.position.y - lastY
                                lastY = change.position.y
                                while (abs(stepAcc) > stepPx) {
                                    controller.step(if (stepAcc < 0f) 1 else -1)
                                    stepAcc += if (stepAcc < 0f) stepPx else -stepPx
                                }
                            }
                            val canOpenSettings = controller.phase == Phase.Locked ||
                                controller.phase == Phase.Disguised || controller.phase == Phase.Selecting
                            if (canOpenSettings && totalX < -110f && abs(totalX) > 2f * abs(totalY)) onOpenSettings()
                        }

                        Gesture.Cancel -> Unit
                    }
                }
            },
    ) {
        when (controller.phase) {
            Phase.Disguised -> DisguiseFace()
            Phase.Active -> ActiveView(controller, basePal, art, particles, time, perf, cap, tiltX, tiltY)
            else -> DeviceView(controller, basePal, art, particles, time, perf, cap, tiltX, tiltY)
        }
        if (flashVisible) {
            val ascended = controller.activeAscended
            FlashOverlay(if (ascended) ascensionPalette(basePal) else basePal, ascended)
        }
        val banner = when {
            overdriveCelebration -> "OVERDRIVE UNLOCKED" to overdriveGlow
            holdHint -> "HOLD TO TRANSFORM" to basePal.accent
            notice != null -> notice to basePal.gold
            else -> null
        }
        if (banner != null) {
            Text(
                text = banner.first,
                color = banner.second,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.4.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 44.dp, start = 30.dp, end = 30.dp)
                    .background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
    }
}

/**
 * A single animation clock for the whole dial. With [fpsCap] > 0 it sleeps between frames, so the
 * device genuinely renders (and wakes the CPU) fewer times per second; 0 = display rate. It also
 * advances [particles] each tick, replacing a second per-frame loop.
 */
@Composable
private fun rememberFrameClock(fpsCap: Int, particles: ParticleField?): State<Float> {
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(fpsCap, particles) {
        var last = 0L
        while (true) {
            if (fpsCap in 1..59) delay((1000L / fpsCap - 6L).coerceAtLeast(1L))
            val nanos = withFrameNanos { it }
            val dt = if (last == 0L) 0f else ((nanos - last) / 1_000_000_000f).coerceAtMost(0.1f)
            last = nanos
            particles?.update(dt)
            time.floatValue += dt
        }
    }
    return time
}

@Composable
private fun DeviceView(
    controller: CoreController, basePal: Palette, art: Art, particles: ParticleField, time: State<Float>,
    perf: PerfMonitor, cap: Int, tiltX: Float, tiltY: Float,
) {
    val settings = controller.settings
    val recharging = controller.phase == Phase.Recharging
    val alien = controller.currentAlien
    val ascended = !recharging && settings.isAscended(alien)
    val pal = when {
        recharging -> rechargePalette(basePal)
        ascended -> ascensionPalette(basePal)
        else -> basePal
    }
    val overdriveRunning = !recharging && settings.overdriveOn && settings.progress.overdriveUnlocked

    val wantOpen = controller.phase == Phase.Opening || controller.phase == Phase.Selecting || controller.phase == Phase.Flashing
    val open = animateFloatAsState(
        targetValue = if (wantOpen) 1f else 0f,
        animationSpec = tween(if (controller.phase == Phase.Opening) 700 else 420, easing = FastOutSlowInEasing),
        label = "open",
    )
    val ringAngle = animateFloatAsState(
        targetValue = controller.spinSteps * 30f,
        animationSpec = tween(180, easing = FastOutSlowInEasing),
        label = "ring",
    )
    val swap = remember { Animatable(1f) }
    LaunchedEffect(controller.index) {
        swap.snapTo(0f)
        swap.animateTo(1f, tween(200, easing = FastOutSlowInEasing))
    }
    val recalGlow = remember { Animatable(0f) }
    LaunchedEffect(controller.recalibrateCount) {
        if (controller.recalibrateCount > 0) {
            recalGlow.snapTo(1f)
            recalGlow.animateTo(0f, tween(700, easing = FastOutSlowInEasing))
        }
    }
    val pulseSpeed = if (recharging) 5f else 1.8f

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val h = maxHeight
        // Plain (non-state) holder: only mutated inside the draw block below.
        val lastSpawnFlash = remember { intArrayOf(0) }
        Canvas(Modifier.fillMaxSize()) {
            val start = System.nanoTime()
            val c = center
            val t = time.value
            if (controller.flashCount != lastSpawnFlash[0]) {
                lastSpawnFlash[0] = controller.flashCount
                if (settings.effectiveParticlesOn) {
                    val strength = if (controller.activeAscended) 1.6f else 1f
                    particles.spawnBurst(c.x, c.y, size.minDimension / 2f, strength, settings.particleDensity)
                    particles.spawnShards(c.x, c.y, size.minDimension / 2f, strength, settings.particleDensity)
                }
            }
            if (settings.effectiveParticlesOn && controller.phase == Phase.Selecting &&
                (t * 3f).toInt() % 5 == 0 && Math.random() < settings.particleDensity
            ) {
                particles.spawnAmbientMote(c.x, c.y, size.minDimension / 2f)
            }
            drawCelestialDevice(
                pal = pal, open = open.value, time = t, ringAngle = ringAngle.value,
                pulse = 0.5f + 0.5f * sin(t * pulseSpeed),
                form = if (recharging || alien == null) null else art.alien(alien),
                swap = swap.value, direction = controller.direction,
                tiltX = tiltX, tiltY = tiltY,
                particles = particles.particles,
                ascended = ascended,
                overdriveActive = overdriveRunning,
                recalibrateGlow = recalGlow.value,
                intensity = settings.glowIntensity,
            )
            perf.onFrame(start, SystemClock.uptimeMillis(), System.nanoTime() - start, cap)
        }
        if (settings.showNames && controller.phase == Phase.Selecting && alien != null) {
            val tag = buildString {
                alien.classification?.let { append(it.glyph).append(' ') }
                append(alien.name.uppercase())
                if (alien.favorite) append("  ★")
                if (ascended) append("  ✦")
            }
            Text(
                text = tag,
                color = if (ascended) pal.gold else pal.accent,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = h * 0.06f, start = 40.dp, end = 40.dp),
            )
        }
        if (alien == null && !recharging) {
            Text(
                text = "TAP TO ADD A FORM",
                color = pal.gold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = h * 0.06f),
            )
        }
        if (recharging) {
            Text(
                text = "RECHARGING",
                color = pal.glow,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = h * 0.06f),
            )
        }
    }
}

@Composable
private fun ActiveView(
    controller: CoreController, basePal: Palette, art: Art, particles: ParticleField, time: State<Float>,
    perf: PerfMonitor, cap: Int, tiltX: Float, tiltY: Float,
) {
    val settings = controller.settings
    val alien = controller.activeAlien ?: return
    val image = art.alien(alien)
    val ascended = controller.activeAscended
    val pal = if (ascended) ascensionPalette(basePal) else basePal
    val overdriveRunning = settings.overdriveOn && settings.progress.overdriveUnlocked
    val timed = !overdriveRunning && settings.durationSec > 0

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val h = maxHeight
        Canvas(Modifier.fillMaxSize()) {
            val start = System.nanoTime()
            val t = time.value
            val breathe = 0.5f + 0.5f * sin(t * 3.9f)
            drawActiveState(
                pal = pal, img = image, time = t, breathe = breathe,
                remaining = controller.remaining, timed = timed, overdrive = overdriveRunning,
                ascended = ascended, tiltX = tiltX, tiltY = tiltY,
                particles = particles.particles, intensity = settings.glowIntensity,
            )
            perf.onFrame(start, SystemClock.uptimeMillis(), System.nanoTime() - start, cap)
        }
        if (settings.showNames) {
            Text(
                text = alien.name.uppercase() + if (ascended) "  ✦" else "",
                color = if (ascended) pal.gold else pal.glow,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp,
                maxLines = 1,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = h * 0.09f),
            )
            val status = when {
                ascended -> "ASCENDED"
                overdriveRunning -> "OVERDRIVE"
                else -> null
            }
            if (status != null) {
                Text(
                    text = status,
                    color = if (ascended) Color.White else overdriveGlow,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = h * 0.045f),
                )
            }
        }
    }
}

@Composable
private fun FlashOverlay(pal: Palette, ascended: Boolean) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { progress.animateTo(1f, tween(if (ascended) 1000 else 920, easing = LinearEasing)) }
    Canvas(Modifier.fillMaxSize()) { drawFlash(pal, progress.value, ascended) }
}
