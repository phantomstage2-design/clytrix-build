package com.clytrix.core.ui

import android.content.Context
import android.os.BatteryManager
import android.text.format.DateFormat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Text
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.TextStyle
import java.util.Locale

private val DIGIT = Color(0xFFF6EEE6)
private val DIM = Color(0xFFAE9A8C)
private val ACCENT = Color(0xFFFFA23C)

/**
 * Plain digital watch face shown in Disguise mode: big HH:MM, seconds, date and battery.
 * Long-press wakes the device; swipe left (or tap three times quickly) opens Settings, where
 * Disguise mode can be switched off again.
 */
@Composable
fun DisguiseFace() {
    val context = LocalContext.current
    val is24 = remember { DateFormat.is24HourFormat(context) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var battery by remember { mutableIntStateOf(readBattery(context)) }
    LaunchedEffect(Unit) {
        var n = 0
        while (true) {
            now = LocalDateTime.now()
            if (n++ % 30 == 0) battery = readBattery(context)
            delay(1000L - (System.currentTimeMillis() % 1000L) + 5L)
        }
    }

    val hour = if (is24) now.hour else (now.hour % 12).let { if (it == 0) 12 else it }
    val hm = "%02d:%02d".format(hour, now.minute).let { if (!is24 && it.startsWith("0")) it.substring(1) else it }
    val sec = "%02d".format(now.second)
    val ampm = if (is24) "" else if (now.hour < 12) "AM" else "PM"
    val day = now.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).uppercase()
    val month = now.month.getDisplayName(TextStyle.SHORT, Locale.getDefault()).uppercase()
    val date = "$day ${now.dayOfMonth} $month"

    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            drawCircle(Color.Black, radius = r, center = c)
            val stroke = r * 0.03f
            val inset = r * 0.045f
            val tl = Offset(c.x - r + inset + stroke / 2f, c.y - r + inset + stroke / 2f)
            val sz = Size(2f * (r - inset - stroke / 2f), 2f * (r - inset - stroke / 2f))
            drawArc(Color(0xFF241713), 0f, 360f, false, tl, sz, style = Stroke(stroke))
            val low = battery in 0..15
            if (battery >= 0) {
                drawArc(
                    if (low) Color(0xFFFF5A4D) else Color(0xFF4FD37A),
                    startAngle = -90f, sweepAngle = 360f * battery / 100f, useCenter = false,
                    topLeft = tl, size = sz, style = Stroke(stroke, cap = StrokeCap.Round),
                )
            }
            val secAngle = Math.toRadians(now.second * 6.0 - 90.0)
            val rr = r - inset - stroke * 2.2f
            drawCircle(
                ACCENT, radius = r * 0.018f,
                center = Offset(c.x + rr * Math.cos(secAngle).toFloat(), c.y + rr * Math.sin(secAngle).toFloat()),
            )
        }
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(date, color = DIM, fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp)
            Text(
                hm, color = DIGIT, fontSize = 54.sp, fontWeight = FontWeight.Light,
                fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 2.dp, bottom = 2.dp),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(sec, color = ACCENT, fontSize = 20.sp, fontFamily = FontFamily.Monospace)
                if (ampm.isNotEmpty()) {
                    Text(" $ampm", color = DIM, fontSize = 12.sp, modifier = Modifier.width(30.dp))
                }
            }
            if (battery >= 0) Text("$battery%", color = DIM, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

private fun readBattery(context: Context): Int = runCatching {
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
}.getOrDefault(-1)
