package com.clytrix.core

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject

/**
 * Lifetime usage counters (from Apexium): total transformations, Ascended transformations, and the
 * earned Overdrive unlock (an optional no-timer mode). Once [totalTransforms] crosses [UNLOCK_AT],
 * [overdriveUnlocked] flips permanently.
 */
class Progress(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("clytrix_progress", Context.MODE_PRIVATE)

    var totalTransforms by mutableIntStateOf(sp.getInt("totalTransforms", 0)); private set
    var apexTransforms by mutableIntStateOf(sp.getInt("apexTransforms", 0)); private set
    var overdriveUnlocked by mutableStateOf(sp.getBoolean("overdriveUnlocked", false)); private set

    fun recordTransform(ascended: Boolean) {
        totalTransforms += 1
        if (ascended) apexTransforms += 1
        val edit = sp.edit().putInt("totalTransforms", totalTransforms).putInt("apexTransforms", apexTransforms)
        if (!overdriveUnlocked && totalTransforms >= UNLOCK_AT) {
            overdriveUnlocked = true
            edit.putBoolean("overdriveUnlocked", true)
        }
        edit.apply()
    }

    /** 0..1 progress toward the Overdrive unlock, for a progress readout in Settings. */
    fun overdriveProgress(): Float =
        if (overdriveUnlocked) 1f else (totalTransforms.toFloat() / UNLOCK_AT).coerceIn(0f, 1f)

    fun export(): JSONObject = JSONObject()
        .put("totalTransforms", totalTransforms)
        .put("apexTransforms", apexTransforms)
        .put("overdriveUnlocked", overdriveUnlocked)

    /** Restores counters from a backup, never lowering what this watch already has. */
    fun import(o: JSONObject): Boolean {
        val total = o.optInt("totalTransforms", -1)
        val apex = o.optInt("apexTransforms", -1)
        if (total < 0 || apex < 0 || apex > total || total > 10_000_000) return false
        totalTransforms = maxOf(totalTransforms, total)
        apexTransforms = maxOf(apexTransforms, apex)
        if (o.optBoolean("overdriveUnlocked", false) || totalTransforms >= UNLOCK_AT) overdriveUnlocked = true
        sp.edit()
            .putInt("totalTransforms", totalTransforms)
            .putInt("apexTransforms", apexTransforms)
            .putBoolean("overdriveUnlocked", overdriveUnlocked)
            .apply()
        return true
    }

    companion object {
        const val UNLOCK_AT = 25
    }
}
