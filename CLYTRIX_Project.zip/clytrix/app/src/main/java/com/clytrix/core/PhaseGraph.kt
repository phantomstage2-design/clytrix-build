package com.clytrix.core

/** What the device is doing right now. */
enum class Phase {
    /** Looks like an ordinary watch face until you long-press (only when Disguise mode is on). */
    Disguised,

    /** Segments closed, the emblem glowing softly. */
    Locked,

    /** The eight mechanical segments are opening. */
    Opening,

    /** Open; rotate the bezel to choose a form, tap (or long-press) to transform. */
    Selecting,

    /** Transformation flash. */
    Flashing,

    /** Transformed. Lasts until you revert -- or, only if you chose a time limit, until it runs out. */
    Active,

    /** Cool-down after a time limit ran out; input is ignored. */
    Recharging,
}

/**
 * The transformation state machine's legal moves, written down once:
 *
 *   Disguised -> Opening | Locked          Locked -> Opening | Disguised
 *   Opening   -> Selecting                 Selecting -> Flashing | Locked | Disguised
 *   Flashing  -> Active                    Active -> Locked | Disguised | Recharging
 *   Recharging -> Locked | Disguised
 *
 * [CoreController] routes every phase change through [isAllowed]; anything else is recorded (never
 * silently) and shown by the Diagnostics Center's state-machine check. Plain Kotlin: PhaseGraphTest.
 */
object PhaseGraph {
    private val edges: Map<Phase, Set<Phase>> = mapOf(
        Phase.Disguised to setOf(Phase.Opening, Phase.Locked),
        Phase.Locked to setOf(Phase.Opening, Phase.Disguised),
        Phase.Opening to setOf(Phase.Selecting),
        Phase.Selecting to setOf(Phase.Flashing, Phase.Locked, Phase.Disguised),
        Phase.Flashing to setOf(Phase.Active),
        Phase.Active to setOf(Phase.Locked, Phase.Disguised, Phase.Recharging),
        Phase.Recharging to setOf(Phase.Locked, Phase.Disguised),
    )

    fun isAllowed(from: Phase, to: Phase): Boolean = from == to || to in (edges[from] ?: emptySet())

    fun successors(from: Phase): Set<Phase> = edges[from] ?: emptySet()

    /** Every phase can reach a resting phase (Locked or Disguised) -- no dead ends. */
    fun everyPhaseCanRest(): Boolean = Phase.values().all { start ->
        val seen = HashSet<Phase>()
        val stack = ArrayDeque(listOf(start))
        while (stack.isNotEmpty()) {
            val p = stack.removeLast()
            if (!seen.add(p)) continue
            stack.addAll(successors(p))
        }
        Phase.Locked in seen || Phase.Disguised in seen
    }
}
