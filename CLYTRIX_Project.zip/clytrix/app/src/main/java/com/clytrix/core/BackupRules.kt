package com.clytrix.core

/**
 * Validation rules for anything that arrives from outside the app (a backup zip, a manifest entry),
 * kept free of Android dependencies so they run as plain JVM unit tests (see BackupRulesTest).
 *
 * The important one is [isSafeFileName]: Apexium's import wrote `File(poolDir, name)` using a file
 * name taken straight from the zip's manifest, so a crafted backup containing "../../shared_prefs/x"
 * could have written outside the photo folder. CLYTRIX only ever accepts plain, flat file names.
 */
object BackupRules {
    /** Largest single entry read from a backup zip (a down-scaled form photo is ~50-200 KB). */
    const val MAX_ENTRY_BYTES = 8L * 1024 * 1024

    /** Largest total uncompressed size read from one backup (guards against zip bombs). */
    const val MAX_TOTAL_BYTES = 96L * 1024 * 1024

    /** Most entries read from one backup. */
    const val MAX_ENTRIES = 600

    /** Most forms accepted from one backup. */
    const val MAX_FORMS = 250

    const val MAX_NAME_CHARS = 40

    private val SAFE_FILE = Regex("^[A-Za-z0-9_][A-Za-z0-9_.-]{0,63}$")
    private val SAFE_ID = Regex("^[A-Za-z0-9_-]{1,64}$")

    /** A flat file name: no separators, no "..", no leading dot, letters/digits/_ . - only. */
    fun isSafeFileName(name: String): Boolean =
        SAFE_FILE.matches(name) && !name.contains("..")

    fun isSafeId(id: String): Boolean = SAFE_ID.matches(id)

    /** Top-level entry names a CLYTRIX (format 2) or Apexium (format 1) backup may contain. */
    fun isKnownEntry(name: String): Boolean = when {
        name in TOP_LEVEL -> true
        name.startsWith("photos/") -> isSafeFileName(name.removePrefix("photos/"))
        else -> false
    }

    /** Display names: trimmed, control characters removed, length-capped. Empty -> null. */
    fun cleanName(raw: String?): String? {
        if (raw == null) return null
        val cleaned = raw.filter { !it.isISOControl() }.trim().take(MAX_NAME_CHARS)
        return cleaned.ifEmpty { null }
    }

    private val TOP_LEVEL = setOf("manifest.json", "settings.json", "usage.json", "progress.json", "backup_info.json")
}
