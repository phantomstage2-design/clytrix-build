package com.clytrix.core

/**
 * The decision rules of the CLYTRIX Evolution Core, kept free of Android so every rule is covered
 * by plain JVM unit tests (EvolutionPolicyTest). [EvolutionCore] feeds it real measurements and
 * carries out what it decides.
 *
 * This is deliberately a small, auditable learner, not a neural network: per power profile it
 * keeps exponential moving averages of *measured* jank, frame time and battery drain, scores each
 * profile with a fixed formula, and only switches when the gain is clear (hysteresis + a minimum
 * dwell time). Before a profile has its own measurements it uses conservative priors, which the
 * measurements then replace.
 */
object EvolutionPolicy {

    /** Device conditions sampled by [AdaptiveCore] (battery broadcast, PowerManager, ActivityManager). */
    data class Signals(
        val batteryPct: Int,
        val charging: Boolean,
        val systemSaver: Boolean,
        /** PowerManager thermal status: 0 none .. 3 severe .. 6 shutdown. -1 = unknown. */
        val thermal: Int,
        val lowMemory: Boolean,
    )

    /** What's been learned about one profile on this watch. */
    data class ProfileStats(
        val windows: Int = 0,
        val jankEma: Float = 0f,
        val frameMsEma: Float = 0f,
        val drainSamples: Int = 0,
        val drainPerHourEma: Float = 0f,
    )

    data class Decision(val profile: Profile, val reason: String, val changed: Boolean)

    const val MIN_DWELL_MS = 120_000L
    const val SWITCH_MARGIN = 0.05f
    const val PARTICLE_MIN = 0.4f
    const val PARTICLE_MAX = 1.0f
    const val PARTICLE_STEP = 0.15f
    const val JANK_HIGH = 0.12f
    const val JANK_LOW = 0.03f

    private const val ALPHA = 0.25f
    private val QUALITY = floatArrayOf(1.0f, 0.82f, 0.5f)
    /** Battery %/hour priors used until real drain has been measured for a profile. */
    private val DRAIN_PRIOR = floatArrayOf(14f, 10f, 7f)

    /**
     * The most capable rank conditions allow right now: 0 = anything, 1 = Balanced or lighter,
     * 2 = Ultra only. Charging relaxes the battery rules; heat and memory pressure still apply.
     */
    fun conditionRank(s: Signals): Int = when {
        s.systemSaver || s.thermal >= 3 || (!s.charging && s.batteryPct in 1..15) -> 2
        s.thermal == 2 || s.lowMemory || (!s.charging && s.batteryPct in 16..30) -> 1
        else -> 0
    }

    private fun conditionWhy(s: Signals): String = when {
        s.systemSaver -> "the watch's own power saver is on"
        s.thermal >= 3 -> "the watch is running hot"
        !s.charging && s.batteryPct in 1..15 -> "battery is at ${s.batteryPct}%"
        s.thermal == 2 -> "the watch is warm"
        s.lowMemory -> "the system reports low memory"
        !s.charging && s.batteryPct in 16..30 -> "battery is at ${s.batteryPct}%"
        else -> ""
    }

    fun score(p: Profile, st: ProfileStats?, s: Signals): Float {
        val measured = st != null && st.windows > 0
        val jank = if (measured) st!!.jankEma else 0.02f
        val drain = if (st != null && st.drainSamples >= 2) st.drainPerHourEma else DRAIN_PRIOR[p.rank]
        val batteryWeight = if (s.charging) 0f else 0.15f + 0.85f * ((100 - s.batteryPct.coerceIn(0, 100)) / 100f)
        return QUALITY[p.rank] - 2.5f * jank - batteryWeight * (drain / 20f)
    }

    /**
     * Picks the profile for Adaptive mode.
     * @param ceiling most capable rank the user allows (0..2); @param floor least capable (ceiling..2).
     */
    fun choose(
        current: Profile,
        stats: Map<Profile, ProfileStats>,
        s: Signals,
        ceiling: Int,
        floor: Int,
        sinceLastSwitchMs: Long,
    ): Decision {
        val ceil = ceiling.coerceIn(0, 2)
        val flo = floor.coerceIn(ceil, 2)
        val needed = conditionRank(s)
        val lowest = maxOf(ceil, minOf(needed, flo))
        val candidates = Profile.values().filter { it.rank in lowest..flo }
        val limitedByUser = needed > flo

        val currentAllowed = current in candidates
        val best = candidates.maxByOrNull { score(it, stats[it], s) } ?: Profile.byRank(lowest)

        if (!currentAllowed) {
            val why = conditionWhy(s).ifEmpty { "your Adaptive limits" }
            val target = if (current.rank < lowest) Profile.byRank(lowest) else best
            val note = if (limitedByUser) " (held at your limit)" else ""
            return Decision(target, "Switched to ${target.label}: $why$note", target != current)
        }
        if (best == current) {
            val why = conditionWhy(s)
            val r = if (why.isNotEmpty() && current.rank > 0) "${current.label}: $why" else "${current.label}: best measured balance"
            return Decision(current, r, false)
        }
        val gain = score(best, stats[best], s) - score(current, stats[current], s)
        if (gain < SWITCH_MARGIN || sinceLastSwitchMs < MIN_DWELL_MS) {
            return Decision(current, "${current.label}: holding (gain too small or switched recently)", false)
        }
        val direction = if (best.rank > current.rank) "to save battery" else "for smoother effects"
        return Decision(best, "Switched to ${best.label} $direction (measured score +${"%.2f".format(gain)})", true)
    }

    /** Folds one measurement window into a profile's stats. */
    fun withWindow(st: ProfileStats, w: PerfMonitor.Window): ProfileStats {
        if (st.windows == 0) return st.copy(windows = 1, jankEma = w.jankFraction, frameMsEma = w.avgFrameMs)
        return st.copy(
            windows = (st.windows + 1).coerceAtMost(100_000),
            jankEma = st.jankEma + (w.jankFraction - st.jankEma) * ALPHA,
            frameMsEma = st.frameMsEma + (w.avgFrameMs - st.frameMsEma) * ALPHA,
        )
    }

    /** Folds one measured battery-drain sample (%/hour, while CLYTRIX was on screen). */
    fun withDrain(st: ProfileStats, pctPerHour: Float): ProfileStats {
        if (pctPerHour.isNaN() || pctPerHour < 0f || pctPerHour > 200f) return st
        if (st.drainSamples == 0) return st.copy(drainSamples = 1, drainPerHourEma = pctPerHour)
        return st.copy(
            drainSamples = (st.drainSamples + 1).coerceAtMost(100_000),
            drainPerHourEma = st.drainPerHourEma + (pctPerHour - st.drainPerHourEma) * ALPHA,
        )
    }

    /**
     * Particle-density trim: down a step after a janky window, up a step (as a *trial*) after
     * [goodStreak] smooth windows in a row. Null = leave it alone.
     */
    fun nextParticleScale(current: Float, jank: Float, goodStreak: Int): Float? = when {
        jank > JANK_HIGH && current > PARTICLE_MIN + 0.001f -> (current - PARTICLE_STEP).coerceAtLeast(PARTICLE_MIN)
        jank < JANK_LOW && goodStreak >= 3 && current < PARTICLE_MAX - 0.001f -> (current + PARTICLE_STEP).coerceAtMost(PARTICLE_MAX)
        else -> null
    }

    /** After a trial increase: true = keep it, false = roll it back. */
    fun keepTrial(baselineJank: Float, trialJank: Float): Boolean =
        trialJank <= maxOf(JANK_HIGH, baselineJank + 0.06f)

    // ---- recommendations (never applied without the user's approval) ------------------------------

    data class RecInputs(
        val crtOn: Boolean,
        val particlesOn: Boolean,
        val stayAwake: Boolean,
        val ambientHumOn: Boolean,
        val powerMode: PowerMode,
        val batteryPct: Int,
        val charging: Boolean,
        val jankEma: Float?,
        val drainPerHour: Float?,
        val soundFailures: Int,
        val recentCrashes: Int,
    )

    data class Recommendation(val id: String, val title: String, val detail: String)

    fun recommendations(i: RecInputs): List<Recommendation> = buildList {
        val jank = i.jankEma ?: 0f
        if (i.recentCrashes >= 2) add(Recommendation("run_diagnostic", "Run a full diagnostic",
            "CLYTRIX recovered from ${i.recentCrashes} crashes in the last day."))
        if (i.soundFailures >= 2) add(Recommendation("test_audio", "Test the audio output",
            "Sound failed to start ${i.soundFailures} times this session."))
        if (i.crtOn && jank > JANK_HIGH) add(Recommendation("crt_off", "Turn off the scanline filter",
            "Frames are dropping (${pct(jank)} janky); the filter redraws the whole screen."))
        if (i.particlesOn && jank > 0.2f) add(Recommendation("particles_off", "Turn off particles",
            "Frames are still dropping (${pct(jank)}) after lowering particle density."))
        if (!i.charging && i.stayAwake && (i.drainPerHour ?: 0f) > 18f) add(Recommendation("stay_awake_off",
            "Let the screen sleep", "Measured drain is ${"%.0f".format(i.drainPerHour)}%/h with Keep screen on."))
        if (!i.charging && i.powerMode == PowerMode.Performance && i.batteryPct in 1..25) add(Recommendation(
            "mode_adaptive", "Switch to Adaptive AI mode", "Battery is at ${i.batteryPct}% in Performance mode."))
        if (!i.charging && i.ambientHumOn && i.batteryPct in 1..20 && i.powerMode != PowerMode.UltraSaver) add(
            Recommendation("hum_off", "Turn off the ambient hum", "It's the only continuous sound; battery is at ${i.batteryPct}%."))
    }

    private fun pct(f: Float) = "${(f * 100).toInt()}%"
}
