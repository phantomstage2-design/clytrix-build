package com.clytrix.core.ui

import android.app.RemoteInput
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.Text
import androidx.wear.input.RemoteInputIntentHelper
import com.clytrix.core.Alien
import com.clytrix.core.Classification
import com.clytrix.core.Diagnostics
import com.clytrix.core.EvolutionCore
import com.clytrix.core.EvolutionPolicy
import com.clytrix.core.MiraLink
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val NAME_INPUT_KEY = "clytrix_form_name"

/** Launches Wear's voice/keyboard text picker and hands the typed text to [onText]. */
@Composable
private fun rememberTextInput(onText: (String) -> Unit): (String) -> Unit {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val bundle = result.data?.let { RemoteInput.getResultsFromIntent(it) } ?: return@rememberLauncherForActivityResult
        onText(bundle.getCharSequence(NAME_INPUT_KEY)?.toString().orEmpty())
    }
    return { label ->
        val intent = RemoteInputIntentHelper.createActionRemoteInputIntent()
        RemoteInputIntentHelper.putRemoteInputsExtra(intent, listOf(RemoteInput.Builder(NAME_INPUT_KEY).setLabel(label).build()))
        launcher.launch(intent)
    }
}

// ---- Transformation roster ------------------------------------------------------------------------------

@Composable
internal fun RosterPage(deps: SettingsDeps, nav: (String) -> Unit) {
    val s = deps.settings
    val scope = rememberCoroutineScope()
    var pendingUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf<String?>(null) }
    val askName = rememberTextInput { text ->
        val uri = pendingUri
        pendingUri = null
        if (uri != null) scope.launch {
            status = if (s.addAlien(uri, text) != null) "Form added" else "That image couldn't be read"
        }
    }
    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { pendingUri = uri; askName("Form name") }
    }

    Page("Transformation Roster") {
        status?.let { item { Note(it, color = Color.White) } }
        if (s.aliens.isEmpty()) item { Note("Add a photo from your gallery to create your first form. Pictures stay on this watch.") }
        for (a in s.aliens) {
            item(key = a.id) {
                val on = s.isEnabled(a)
                Chip(
                    onClick = { nav(Pages.FORM + a.id) },
                    label = { Text((if (a.favorite) "★ " else "") + a.name, maxLines = 1) },
                    secondaryLabel = {
                        Text(listOfNotNull(
                            if (a.apex) "Ascended" else null,
                            a.classification?.label,
                            "${s.usage[a.id] ?: 0} uses",
                            if (!on) "hidden" else null,
                        ).joinToString(" · "), maxLines = 1)
                    },
                    icon = { Image(bitmap = deps.art.alien(a), contentDescription = null, modifier = Modifier.size(30.dp), alpha = if (on) 1f else 0.4f) },
                    colors = if (on) ChipDefaults.primaryChipColors() else ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        item {
            ActionChip("Add form from Gallery", primary = true) {
                runCatching { photoLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                    .onFailure { status = "No photo picker available on this watch" }
            }
        }
        item { Note("Custom order is the order shown here; use Move up/down on a form. Selection order can also sort A to Z, by use, or favorites first.", color = DimText) }
    }
}

@Composable
internal fun FormPage(deps: SettingsDeps, id: String, goUp: () -> Unit) {
    val s = deps.settings
    val form: Alien? = s.aliens.find { it.id == id }
    LaunchedEffect(form == null) { if (form == null) goUp() }
    if (form == null) return
    val rename = rememberTextInput { text -> if (text.isNotBlank()) s.renameAlien(form, text) }
    var confirmRemove by remember { mutableStateOf(false) }
    LaunchedEffect(confirmRemove) { if (confirmRemove) { delay(3000); confirmRemove = false } }
    val index = s.aliens.indexOf(form)

    Page(form.name) {
        item { Image(bitmap = deps.art.alien(form), contentDescription = form.name, modifier = Modifier.size(64.dp)) }
        item { ToggleChip("In the dial", s.isEnabled(form), "hidden forms stay in the roster") { s.toggleEnabled(form) } }
        item { ToggleChip("Favorite", form.favorite) { s.setFavorite(form, it) } }
        item { ToggleChip("Ascended form", form.apex, if (s.ascensionOn) "uses Ascension Mode" else "Ascension Mode is off") { s.setApex(form, it) } }
        item {
            SettingChip("Classification", form.classification?.let { "${it.glyph} ${it.label}" } ?: "None") {
                val all: List<Classification?> = listOf<Classification?>(null) + Classification.values().toList()
                s.setClassification(form, all.after(form.classification))
            }
        }
        item { ActionChip("Rename") { rename("Rename ${form.name}") } }
        item {
            TwoChips(
                "Move up", "Move down",
                { if (index > 0) s.moveAlien(form, -1) },
                { if (index < s.aliens.size - 1) s.moveAlien(form, 1) },
                rightPrimary = false,
            )
        }
        item { Note("Position ${index + 1} of ${s.aliens.size} · used ${s.usage[form.id] ?: 0} time(s)", color = DimText) }
        item {
            ActionChip(if (confirmRemove) "Tap again to delete" else "Delete form", "Removes the photo from this watch") {
                if (!confirmRemove) confirmRemove = true
                else { deps.art.forget(form); s.removeAlien(form); goUp() }
            }
        }
    }
}

// ---- 5. Evolution Core ---------------------------------------------------------------------------------

@Composable
internal fun EvolutionPage(deps: SettingsDeps, nav: (String) -> Unit) {
    val s = deps.settings
    val a = deps.adaptive
    val evo = a.evolution
    @Suppress("UNUSED_VARIABLE") val rev = evo.revision // recompose when the core changes
    var message by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val recentCrashes = remember { com.clytrix.core.CrashGuard.record(context).recentCount() }
    val recs = evo.recommendations(EvolutionPolicy.RecInputs(
        crtOn = s.crtOn, particlesOn = s.particlesOn, stayAwake = s.stayAwake, ambientHumOn = s.ambientHumOn,
        powerMode = s.powerMode, batteryPct = a.batteryPct, charging = a.charging,
        jankEma = evo.statsFor(s.activeProfile)?.jankEma, drainPerHour = evo.statsFor(s.activeProfile)?.takeIf { it.drainSamples > 0 }?.drainPerHourEma,
        soundFailures = a.soundFailuresSession, recentCrashes = recentCrashes,
    ))

    Page("Evolution Core") {
        message?.let { item { Note(it, color = Color.White) } }
        item { ToggleChip("Evolution Core", s.adaptiveCoreOn, if (s.adaptiveCoreOn) "may adjust approved settings" else "observe only") { s.updateAdaptiveCoreOn(it); a.evaluate() } }
        item { Note("Learns from measured frame timing, input latency and battery drain on this watch. It only changes reversible settings, within a daily budget, logs everything and can roll anything back. No code is ever changed.") }
        item { Header("STATUS") }
        item { Note("${evo.adjustmentsTotal} adjustment(s) · ${evo.rollbacksTotal} rolled back · ${a.budgetRemaining()} left today", color = Color.White) }
        item { Note("Latest: ${evo.lastOptimization ?: "none yet"}") }
        item {
            val p = evo.previousWindow
            val c = evo.currentWindow
            Note(when {
                c == null -> "Measuring… keep the dial open for ~30 s."
                p == null -> "Now: ${"%.1f".format(c.fps)} fps, ${Diagnostics.pct(c.jankFraction)} janky frames"
                else -> "Before → now: ${"%.1f".format(p.fps)} → ${"%.1f".format(c.fps)} fps · janky ${Diagnostics.pct(p.jankFraction)} → ${Diagnostics.pct(c.jankFraction)}"
            })
        }
        item { Note("Particle trim ${Diagnostics.pct(s.evoParticleScale)} · profile ${s.activeProfile.label}", color = DimText) }

        item { Header("RECOMMENDATIONS") }
        if (recs.isEmpty()) item { Note("Nothing to recommend right now.") }
        for (r in recs) {
            item(key = "rec_" + r.id) { Note("${r.title}: ${r.detail}", color = Color.White) }
            item(key = "recbtn_" + r.id) {
                TwoChips("Dismiss", "Apply", { evo.dismissRecommendation(r.id) }, {
                    when (evo.applyRecommendation(r.id)) {
                        "diagnostic" -> nav(Pages.DIAGNOSTICS)
                        "audio" -> nav(Pages.SOUND)
                        else -> { message = "Applied: ${r.title}. You can roll it back below."; a.evaluate() }
                    }
                })
            }
        }

        item { Header("ROLLBACK") }
        item {
            val last = evo.lastReversible()
            ActionChip("Roll back last change", last?.let { "${it.knob}: ${it.to} → ${it.from}" } ?: "Nothing to roll back") {
                message = evo.rollbackLast() ?: "Nothing to roll back"
                a.evaluate()
            }
        }
        val history = evo.historySnapshot().take(12)
        if (history.isNotEmpty()) item { Header("HISTORY") }
        for ((i, h) in history.withIndex()) {
            item(key = "hist_$i") {
                val tag = when (h.status) {
                    EvolutionCore.Status.RolledBack -> "rolled back"
                    EvolutionCore.Status.Reverted -> "undone by you"
                    EvolutionCore.Status.Trial -> "on trial"
                    EvolutionCore.Status.Kept -> "kept"
                    EvolutionCore.Status.Applied -> if (h.auto) "auto" else "approved"
                }
                Note("${Diagnostics.fmtTime(h.at)} · ${h.knob} ${h.from} → ${h.to} ($tag)\n${h.reason}", color = SoftText)
            }
        }
        val log = a.recentLog().take(6)
        if (log.isNotEmpty()) item { Header("LOG") }
        for ((i, e) in log.withIndex()) item(key = "log_$i") { Note("${Diagnostics.fmtTime(e.at)} — ${e.message}", color = DimText) }
        item {
            ActionChip(if (confirmReset) "Tap again to reset" else "Reset learning", "Forgets measurements; history is kept") {
                if (!confirmReset) confirmReset = true else { evo.resetLearning(); confirmReset = false; message = "Learning reset"; a.evaluate() }
            }
        }
    }
}

// ---- 6. Mira AI Link --------------------------------------------------------------------------------------

@Composable
internal fun MiraPage(deps: SettingsDeps) {
    val context = LocalContext.current
    var reachable by remember { mutableStateOf<Boolean?>(null) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(MiraLink.pairingCode) {
        while (MiraLink.pairingCode != null) {
            now = System.currentTimeMillis()
            if (now > MiraLink.pairingExpiresAt) MiraLink.cancelPairing()
            delay(1000)
        }
    }
    LaunchedEffect(MiraLink.isPaired, MiraLink.enabled) {
        if (MiraLink.enabled && MiraLink.isPaired) MiraLink.checkReachable(context) { reachable = it }
    }

    Page("Mira AI Link") {
        item { Note("Optional. Lets your Mira AI app ask CLYTRIX for status and send a few commands. CLYTRIX works the same without it.") }
        item { ToggleChip("Mira AI Link", MiraLink.enabled) { MiraLink.setEnabled(context, it) } }
        if (MiraLink.enabled) {
            item { Header("CONNECTION") }
            item {
                Note(when {
                    !MiraLink.isPaired -> "Not paired"
                    reachable == true -> "Paired with ${MiraLink.pairedClient} · phone reachable"
                    reachable == false -> "Paired with ${MiraLink.pairedClient} · phone not reachable"
                    else -> "Paired with ${MiraLink.pairedClient}"
                }, color = Color.White)
            }
            item { Note("Last contact: ${if (MiraLink.lastSuccessAt > 0) Diagnostics.fmtTime(MiraLink.lastSuccessAt) else "never"} · served ${MiraLink.requestsServed}, refused ${MiraLink.requestsRefused} this session") }
            MiraLink.lastError?.let { item { Note("Last error: $it", color = DimText) } }
            val code = MiraLink.pairingCode
            if (code != null) {
                item {
                    Text(
                        text = code.chunked(3).joinToString(" "),
                        fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp,
                        textAlign = TextAlign.Center, color = paletteFor(deps.settings.skin).gold,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                item { Note("Enter this code in Mira AI on your phone. Expires in ${((MiraLink.pairingExpiresAt - now) / 1000).coerceAtLeast(0)} s.", color = Color.White) }
                item { ActionChip("Cancel pairing") { MiraLink.cancelPairing() } }
            } else {
                item { ActionChip(if (MiraLink.isPaired) "Pair again" else "Pair with Mira", "Shows a one-time code", primary = !MiraLink.isPaired) { MiraLink.startPairing() } }
            }
            if (MiraLink.isPaired) {
                item { Header("PERMISSIONS") }
                item { ToggleChip("Allow control", MiraLink.allowControl, "battery mode, open dial, select a form") { MiraLink.setPermissions(context, control = it) } }
                item { ToggleChip("Share status data", MiraLink.allowData, "battery, diagnostics, Evolution summaries") { MiraLink.setPermissions(context, data = it) } }
                item { ToggleChip("Spoken status reports", MiraLink.spokenReports, "Mira may read replies aloud") { MiraLink.setPermissions(context, spoken = it) } }
                item { Note("Mira can never trigger a transformation by itself: it can only point the dial at a form. You confirm on the watch. No photos or conversations are ever sent.", color = DimText) }
                item { ActionChip("Unpair") { MiraLink.unpair(context); reachable = null } }
            }
            item { Note("Needs the CLYTRIX Link relay on the paired phone and Mira AI support for the CLYTRIX link (see the project's MIRA_INTEGRATION guide).", color = DimText) }
        }
    }
}

// ---- 7. System Diagnostics -------------------------------------------------------------------------------

@Composable
internal fun DiagnosticsPage(deps: SettingsDeps) {
    val d = deps.diagnostics
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(d.lastResults) }
    var tick by remember { mutableIntStateOf(0) }
    var exportMsg by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { while (true) { delay(1000); tick++ } }
    val live = remember(tick) { d.live() }

    Page("System Diagnostics") {
        item {
            ActionChip(if (running) "RUNNING…" else "RUN FULL DIAGNOSTIC", primary = true) {
                if (!running) scope.launch {
                    running = true
                    results = runCatching { d.runFull() }.getOrElse { listOf(Diagnostics.Check("Diagnostic run", Diagnostics.Result.FAIL, it.javaClass.simpleName)) }
                    running = false
                }
            }
        }
        if (results.isNotEmpty()) {
            val counts = results.groupingBy { it.result }.eachCount()
            item {
                Note(Diagnostics.Result.values().filter { (counts[it] ?: 0) > 0 }.joinToString(" · ") { "${counts[it]} ${it.name.replace('_', ' ')}" }, color = Color.White)
            }
            for ((i, c) in results.withIndex()) {
                item(key = "check_$i") {
                    val color = when (c.result) {
                        Diagnostics.Result.PASS -> Color(0xFF5BE3A3)
                        Diagnostics.Result.WARNING -> Color(0xFFFFC857)
                        Diagnostics.Result.FAIL -> Color(0xFFFF6B5E)
                        Diagnostics.Result.NOT_TESTED -> Color(0xFF9AA4AB)
                    }
                    Text(
                        text = "${c.result.name.replace('_', ' ')} · ${c.name}\n${c.detail}",
                        color = color, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
        for (section in live) {
            item(key = "sec_" + section.title) { Header(section.title) }
            for (row in section.rows) {
                item(key = "row_" + section.title + row.label) {
                    Text(text = "${row.label}\n${row.value}", color = SoftText, fontSize = 11.sp, modifier = Modifier.fillMaxWidth())
                }
            }
        }
        exportMsg?.let { item { Note(it, color = Color.White) } }
        item {
            ActionChip("Export diagnostic report", "Text file, no photos or names") {
                val f = d.exportReport()
                if (f != null) shareFile(context, f, "text/plain", "Share CLYTRIX diagnostics") else exportMsg = "Couldn't write the report"
            }
        }
    }
}
