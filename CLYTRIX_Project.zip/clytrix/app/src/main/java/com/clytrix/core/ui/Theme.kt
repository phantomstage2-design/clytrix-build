package com.clytrix.core.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.wear.compose.material.Colors
import androidx.wear.compose.material.MaterialTheme

/**
 * The whole app's Material colours follow the current theme's light, so every primary chip in
 * Settings re-tints itself with the skin. Surfaces are a deep, faintly green-black; secondary text
 * is a soft gold-grey to match the device's materials.
 */
@Composable
fun ClytrixTheme(pal: Palette, content: @Composable () -> Unit) {
    val colors = Colors(
        primary = pal.glow,
        primaryVariant = lerp(pal.glow, Color.Black, 0.35f),
        secondary = pal.gold,
        secondaryVariant = pal.goldDeep,
        background = Color.Black,
        surface = Color(0xFF141A18),
        error = Color(0xFFFF5449),
        onPrimary = Color(0xFF04120C),
        onSecondary = Color(0xFF1A1405),
        onBackground = Color.White,
        onSurface = Color(0xFFEFF3F1),
        onSurfaceVariant = Color(0xFFC9C2A8),
        onError = Color.Black,
    )
    MaterialTheme(colors = colors, content = content)
}

/** Secondary text colour used across Settings and Diagnostics. */
val SoftText = Color(0xFFC9C2A8)
val DimText = Color(0xFF8C866F)
