package com.clytrix.core

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * ZIP backup and restore (Apexium's format, extended). One portable file, no server, no account.
 *
 *   backup_info.json -- {"app":"CLYTRIX","format":2,"created":<ms>}
 *   manifest.json    -- the roster: names, order, Ascended/favourite/classification flags
 *   photos/<file>    -- every photo the manifest references
 *   settings.json    -- whitelisted preferences only (see Settings.exportPrefs)
 *   usage.json       -- per-form usage counts
 *   progress.json    -- lifetime transformation counters / Overdrive unlock
 *
 * Import validates everything before writing anything (see [BackupRules]): known entry names only,
 * safe flat file names (no path traversal), per-entry and total size caps (no zip bombs), photos
 * must decode as images, preference values are type- and range-checked one by one. An Apexium
 * backup (format 1: manifest + photos only) is accepted for its forms. A corrupted or partial zip
 * imports whatever is intact and reports what was skipped; it never leaves a half-written roster.
 */
object Backup {
    data class ImportResult(
        val ok: Boolean,
        val formsAdded: Int = 0,
        val formsSkipped: Int = 0,
        val settingsApplied: Int = 0,
        val usageMerged: Int = 0,
        val progressRestored: Boolean = false,
        val message: String,
    )

    const val FORMAT = 2

    /** Writes a zip into cache/backups (exposed read-only via FileProvider) and returns it. */
    fun exportZip(context: Context, customAliens: CustomAliens, settings: Settings): File? {
        val app = context.applicationContext
        val poolDir = customAliens.poolDir()
        val dir = File(app.cacheDir, "backups").apply { mkdirs() }
        dir.listFiles()?.filter { it.name.endsWith(".zip") }?.sortedBy { it.lastModified() }?.dropLast(2)?.forEach { it.delete() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val out = File(dir, "clytrix_backup_$stamp.zip")
        return try {
            val forms = customAliens.loadAll()
            ZipOutputStream(out.outputStream()).use { zip ->
                fun put(name: String, bytes: ByteArray) { zip.putNextEntry(ZipEntry(name)); zip.write(bytes); zip.closeEntry() }
                put("backup_info.json", JSONObject().put("app", "CLYTRIX").put("format", FORMAT)
                    .put("created", System.currentTimeMillis()).put("forms", forms.size).toString().toByteArray())
                put("manifest.json", CustomAliens.toJson(forms).toString().toByteArray())
                for (a in forms) {
                    val src = a.source as? ImageSource.Custom ?: continue
                    val f = File(poolDir, src.fileName)
                    if (f.exists()) put("photos/${src.fileName}", f.readBytes())
                }
                put("settings.json", settings.exportPrefs().toString().toByteArray())
                put("usage.json", settings.exportUsage().toString().toByteArray())
                put("progress.json", settings.progress.export().toString().toByteArray())
            }
            out
        } catch (e: Exception) {
            out.delete()
            null
        }
    }

    /** A content:// Uri for an exported file, suitable for ACTION_SEND. */
    fun uriFor(context: Context, file: File): Uri =
        FileProvider.getUriForFile(context.applicationContext, "com.clytrix.core.fileprovider", file)

    private class Unpacked(
        val entries: Map<String, ByteArray>,
        val skippedEntries: Int,
        val truncated: Boolean,
    )

    /** Reads a zip with every limit enforced; unknown or unsafe entries are skipped, not trusted. */
    private fun unpack(input: InputStream): Unpacked {
        val entries = HashMap<String, ByteArray>()
        var skipped = 0
        var total = 0L
        var count = 0
        var truncated = false
        ZipInputStream(input).use { zip ->
            while (true) {
                val next: ZipEntry? = try { zip.nextEntry } catch (e: Exception) { truncated = true; null }
                val entry = next ?: break
                count++
                if (count > BackupRules.MAX_ENTRIES) { truncated = true; break }
                val name = entry.name
                if (entry.isDirectory) { zip.closeEntry(); continue }
                if (!BackupRules.isKnownEntry(name)) { skipped++; zip.closeEntry(); continue }
                val bytes = try { readCapped(zip, BackupRules.MAX_ENTRY_BYTES) } catch (e: Exception) { truncated = true; null }
                if (bytes == null) { skipped++; continue }
                total += bytes.size
                if (total > BackupRules.MAX_TOTAL_BYTES) { truncated = true; break }
                entries[name] = bytes
                try { zip.closeEntry() } catch (_: Exception) { }
            }
        }
        return Unpacked(entries, skipped, truncated)
    }

    /** Reads one entry; null if it exceeds [cap] (the rest of it is not read into memory). */
    private fun readCapped(zip: ZipInputStream, cap: Long): ByteArray? {
        val buf = java.io.ByteArrayOutputStream()
        val chunk = ByteArray(16 * 1024)
        var read = 0L
        while (true) {
            val n = zip.read(chunk)
            if (n < 0) break
            read += n
            if (read > cap) return null
            buf.write(chunk, 0, n)
        }
        return buf.toByteArray()
    }

    /** True if [bytes] decode as an image (bounds only; nothing is allocated for pixels). */
    private fun isImage(bytes: ByteArray): Boolean {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        return o.outWidth in 1..8192 && o.outHeight in 1..8192
    }

    fun importZip(context: Context, customAliens: CustomAliens, settings: Settings, uri: Uri): ImportResult {
        val unpacked = try {
            context.applicationContext.contentResolver.openInputStream(uri)?.use { unpack(it) }
                ?: return ImportResult(false, message = "Couldn't open that file")
        } catch (e: Exception) {
            return ImportResult(false, message = "That file isn't a readable backup")
        }
        return applyUnpacked(customAliens, settings, unpacked)
    }

    private fun applyUnpacked(customAliens: CustomAliens, settings: Settings, u: Unpacked): ImportResult {
        val e = u.entries
        val info = e["backup_info.json"]?.let { runCatching { JSONObject(String(it)) }.getOrNull() }
        if (info != null && info.optString("app") != "CLYTRIX") return ImportResult(false, message = "That backup isn't from CLYTRIX")
        if (info != null && info.optInt("format", 0) > FORMAT) return ImportResult(false, message = "That backup is from a newer CLYTRIX")
        val manifest = e["manifest.json"]?.let { runCatching { JSONArray(String(it)) }.getOrNull() }
        if (manifest == null && info == null) return ImportResult(false, message = "No CLYTRIX backup found in that file")

        // ---- forms: validate each, write photos, then merge the manifest once -------------------
        var added = 0
        var skipped = 0
        if (manifest != null) {
            val existing = customAliens.loadAll().map { it.id }.toSet()
            val candidates = CustomAliens.parseManifest(manifest)
            skipped += manifest.length() - candidates.size
            val accepted = ArrayList<Alien>()
            val written = ArrayList<File>()
            for (a in candidates.take(BackupRules.MAX_FORMS)) {
                if (a.id in existing) continue
                val src = a.source as ImageSource.Custom
                val bytes = e["photos/${src.fileName}"]
                if (bytes == null || !isImage(bytes)) { skipped++; continue }
                val target = File(customAliens.poolDir(), src.fileName)
                if (target.exists()) { skipped++; continue } // never overwrite another form's photo
                try {
                    target.writeBytes(bytes); written.add(target); accepted.add(a)
                } catch (ex: Exception) {
                    target.delete(); skipped++
                }
            }
            skipped += (candidates.size - BackupRules.MAX_FORMS).coerceAtLeast(0)
            added = try { customAliens.mergeImported(accepted) } catch (ex: Exception) {
                written.forEach { it.delete() }; 0
            }
        }

        // ---- settings, usage, progress (format 2 only) ----------------------------------------------
        val settingsApplied = e["settings.json"]?.let { b -> runCatching { settings.importPrefs(JSONObject(String(b))) }.getOrDefault(0) } ?: 0
        val usageMerged = e["usage.json"]?.let { b -> runCatching { settings.importUsage(JSONObject(String(b))) }.getOrDefault(0) } ?: 0
        val progress = e["progress.json"]?.let { b -> runCatching { settings.progress.import(JSONObject(String(b))) }.getOrDefault(false) } ?: false

        val parts = buildList {
            add(if (added > 0) "Added $added form(s)" else "No new forms")
            if (settingsApplied > 0) add("restored $settingsApplied setting(s)")
            if (usageMerged > 0) add("merged usage stats")
            if (progress) add("restored progress")
            if (skipped + u.skippedEntries > 0) add("skipped ${skipped + u.skippedEntries} invalid item(s)")
            if (u.truncated) add("file was incomplete")
        }
        return ImportResult(
            ok = true, formsAdded = added, formsSkipped = skipped + u.skippedEntries,
            settingsApplied = settingsApplied, usageMerged = usageMerged, progressRestored = progress,
            message = parts.joinToString(", "),
        )
    }

    /**
     * Diagnostics self-test: exports a real backup, reads it back through the same validating
     * importer path (without applying it), and checks every form's photo survived. Deletes the file.
     */
    fun selfTest(context: Context, customAliens: CustomAliens, settings: Settings): Pair<Boolean, String> {
        val file = exportZip(context, customAliens, settings) ?: return false to "Export failed"
        return try {
            val u = file.inputStream().use { unpack(it) }
            val manifest = u.entries["manifest.json"]?.let { JSONArray(String(it)) } ?: return false to "Manifest missing from archive"
            val forms = CustomAliens.parseManifest(manifest)
            val missing = forms.count { a -> u.entries["photos/${(a.source as ImageSource.Custom).fileName}"]?.let(::isImage) != true }
            when {
                u.truncated -> false to "Archive could not be read back completely"
                u.entries["settings.json"] == null -> false to "Settings missing from archive"
                missing > 0 -> false to "$missing of ${forms.size} photo(s) missing or unreadable"
                else -> true to "Round-trip OK: ${forms.size} form(s), settings, usage and progress (${file.length() / 1024} KB)"
            }
        } catch (e: Exception) {
            false to "Read-back failed: ${e.javaClass.simpleName}"
        } finally {
            file.delete()
        }
    }
}
