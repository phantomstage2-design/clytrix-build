package com.clytrix.core

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * The user's own transformation roster: photos picked from the watch's Gallery app, each copied
 * into private storage and down-scaled, alongside a name and the per-form flags (Ascended,
 * favourite, celestial classification). The manifest's array order IS the user's custom order.
 *
 * Carried over from Apexium with three additions: favourite/classification fields, [move] for
 * manual reordering, and file-name validation on every manifest read (see [BackupRules]).
 */
class CustomAliens(context: Context) {
    private val dir = File(context.filesDir, "form_pool").apply { mkdirs() }
    private val metaFile = File(dir, "manifest.json")
    private val resolver = context.applicationContext.contentResolver

    /** Self-healing: an entry whose image file has gone missing or is empty is quietly dropped. */
    @Synchronized
    fun loadAll(): List<Alien> {
        val list = readManifest()
        val valid = list.filter { a ->
            val src = a.source as? ImageSource.Custom ?: return@filter false
            val f = File(dir, src.fileName)
            f.exists() && f.length() > 0L
        }
        if (valid.size != list.size) writeManifest(valid)
        return valid
    }

    /** Copies [uri] into private storage as a new form. Null if the image couldn't be read. */
    @Synchronized
    fun add(uri: Uri, name: String): Alien? {
        val bitmap = decodeScaled(uri) ?: return null
        val list = readManifest()
        val id = "form_" + UUID.randomUUID().toString().replace("-", "").take(12)
        val fileName = "$id.webp"
        try {
            File(dir, fileName).outputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.WEBP_LOSSY, 92, out)
            }
        } catch (e: Exception) {
            File(dir, fileName).delete()
            return null
        } finally {
            bitmap.recycle()
        }
        val displayName = BackupRules.cleanName(name) ?: "Form ${list.size + 1}"
        val alien = Alien(id, displayName, ImageSource.Custom(fileName))
        list.add(alien)
        writeManifest(list)
        return alien
    }

    @Synchronized
    fun rename(id: String, newName: String) {
        val cleaned = BackupRules.cleanName(newName) ?: return
        update(id) { it.copy(name = cleaned) }
    }

    @Synchronized
    fun setApex(id: String, apex: Boolean) = update(id) { it.copy(apex = apex) }

    @Synchronized
    fun setFavorite(id: String, favorite: Boolean) = update(id) { it.copy(favorite = favorite) }

    @Synchronized
    fun setClassification(id: String, c: Classification?) = update(id) { it.copy(classification = c) }

    /** Moves a form [delta] places within the custom order (clamped to the list's ends). */
    @Synchronized
    fun move(id: String, delta: Int) {
        val list = readManifest()
        val i = list.indexOfFirst { it.id == id }
        if (i < 0) return
        val j = (i + delta).coerceIn(0, list.size - 1)
        if (i == j) return
        val item = list.removeAt(i)
        list.add(j, item)
        writeManifest(list)
    }

    private fun update(id: String, transform: (Alien) -> Alien) {
        val list = readManifest()
        val i = list.indexOfFirst { it.id == id }
        if (i < 0) return
        list[i] = transform(list[i])
        writeManifest(list)
    }

    /** Removes a form from the roster entirely and deletes its copied image file. */
    @Synchronized
    fun remove(id: String) {
        val list = readManifest()
        val alien = list.find { it.id == id } ?: return
        (alien.source as? ImageSource.Custom)?.let { File(dir, it.fileName).delete() }
        list.remove(alien)
        writeManifest(list)
    }

    /** The private-storage file backing a [ImageSource.Custom] entry, for [ui.Art] to decode. */
    fun file(source: ImageSource.Custom): File = File(dir, source.fileName)

    /** The pool directory, used by [Backup] to bundle every photo on export. */
    fun poolDir(): File = dir

    /** Merges already-validated entries (from [Backup]) into the manifest, skipping known ids. */
    @Synchronized
    fun mergeImported(entries: List<Alien>): Int {
        val list = readManifest()
        val known = list.map { it.id }.toMutableSet()
        var added = 0
        for (e in entries) {
            if (e.id in known) continue
            list.add(e); known.add(e.id); added++
        }
        if (added > 0) writeManifest(list)
        return added
    }

    // ---- manifest I/O -----------------------------------------------------------------------

    private fun readManifest(): MutableList<Alien> {
        if (!metaFile.exists()) return mutableListOf()
        return try {
            parseManifest(JSONArray(metaFile.readText())).toMutableList()
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    private fun writeManifest(list: List<Alien>) {
        val tmp = File(dir, "manifest.json.tmp")
        tmp.writeText(toJson(list).toString())
        if (!tmp.renameTo(metaFile)) {
            // renameTo can fail if the target exists on some filesystems -- fall back to a copy.
            metaFile.writeText(tmp.readText())
            tmp.delete()
        }
    }

    // ---- image decoding -----------------------------------------------------------------------

    private fun decodeScaled(uri: Uri): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val sample = sampleSizeFor(bounds.outWidth, bounds.outHeight, 640)
        resolver.openInputStream(uri)?.use { input ->
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeStream(input, null, opts)
        }
    } catch (e: Exception) {
        null
    }

    private fun sampleSizeFor(w: Int, h: Int, target: Int): Int {
        if (w <= 0 || h <= 0) return 1
        var sample = 1
        while (w / (sample * 2) >= target && h / (sample * 2) >= target) sample *= 2
        return sample
    }

    companion object {
        /** Parses a manifest array, dropping any entry with an unsafe id or file name. */
        fun parseManifest(arr: JSONArray): List<Alien> =
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val id = o.optString("id"); val file = o.optString("file")
                if (!BackupRules.isSafeId(id) || !BackupRules.isSafeFileName(file)) return@mapNotNull null
                Alien(
                    id = id,
                    name = BackupRules.cleanName(o.optString("name", id)) ?: id,
                    source = ImageSource.Custom(file),
                    apex = o.optBoolean("apex", false),
                    favorite = o.optBoolean("fav", false),
                    classification = Classification.fromName(o.optString("cls", "")),
                )
            }

        fun toJson(list: List<Alien>): JSONArray {
            val arr = JSONArray()
            for (a in list) {
                val src = a.source as? ImageSource.Custom ?: continue
                val o = JSONObject()
                    .put("id", a.id).put("name", a.name).put("file", src.fileName)
                    .put("apex", a.apex).put("fav", a.favorite)
                a.classification?.let { o.put("cls", it.name) }
                arr.put(o)
            }
            return arr
        }
    }
}
