package com.clytrix.core.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.sin

/**
 * An old-tube-monitor look drawn over the entire device UI: faint horizontal scanlines, a
 * darkened vignette toward the rim, a slow overall brightness flicker (a CRT's supply ripple),
 * and a faint bright band that rolls slowly down the screen and wraps (vertical-hold drift).
 *
 * Purely decorative: drawn last so it sits on top of everything, has no background of its own,
 * and never intercepts touch -- a plain [Canvas] with no pointer input takes no part in hit
 * testing, so every tap, swipe and long-press underneath still works exactly as before.
 */
@Composable
fun CrtOverlay(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "crt")

    val flickerPhase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
        label = "crtFlicker",
    )

    val rollProgress by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart),
        label = "crtRoll",
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Bumped up across the board on request ("a bit more showing") -- finer, darker scanlines,
        // a stronger roll bar and vignette, and a wider flicker range, while staying under the
        // touch layer and never intercepting input.
        val lineSpacing = 2.6.dp.toPx()
        var y = 0f
        while (y < h) {
            drawRect(
                color = Color.Black.copy(alpha = 0.26f),
                topLeft = Offset(0f, y),
                size = Size(w, lineSpacing * 0.5f),
            )
            y += lineSpacing
        }

        val barY = rollProgress * h
        val barHalf = h * 0.07f
        val barTop = (barY - barHalf).coerceIn(0f, h)
        val barBottom = (barY + barHalf).coerceIn(0f, h)
        if (barBottom > barTop) {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.10f), Color.Transparent),
                    startY = barTop,
                    endY = barBottom,
                ),
                topLeft = Offset(0f, barTop),
                size = Size(w, barBottom - barTop),
            )
        }

        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.5f)),
                center = Offset(w / 2f, h / 2f),
                radius = (if (w > h) w else h) * 0.72f,
            )
        )

        val flickerAlpha = (0.03f + 0.03f * sin(flickerPhase * 2f * PI.toFloat())).coerceIn(0f, 0.09f)
        drawRect(Color.Black.copy(alpha = flickerAlpha))
    }
}
