package com.clytrix.core

import android.content.Context
import kotlin.math.min

/**
 * A small, deliberately slow on-device tuner. It watches how you actually use the dial -- how
 * hard the bezel needs calibrating, how early you tend to revert before a transformation times
 * out -- and uses that only to (a) quietly improve feel across sessions, and (b) offer, at most
 * once, a single dismissible settings suggestion. It never silently changes a setting you picked
 * yourself. Every signal is smoothed with a slow exponential moving average and gated behind a
 * minimum sample count, so one odd session (or one weird tap) can't swing anything.
 */
class AdaptiveTuner(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("clytrix_tuning", Context.MODE_PRIVATE)

    // ---- bezel-click calibration -----------------------------------------------------------------
    var bezelUnitEma: Float = sp.getFloat("bezelUnitEma", 0f); private set

    fun observeBezelUnit(px: Float) {
        if (px <= 0f) return
        val next = if (bezelUnitEma <= 0f) px else bezelUnitEma + (px - bezelUnitEma) * BEZEL_ALPHA
        bezelUnitEma = next
        sp.edit().putFloat("bezelUnitEma", next).apply()
    }

    // ---- early-revert tendency, for the one-shot transform-time suggestion -----------------------
    private var revertSampleCount: Int = sp.getInt("revertSamples", 0)
    private var revertFractionEma: Float = sp.getFloat("revertFractionEma", 1f)
    private var suggestionState: String = sp.getString("durationSuggestionState", "pending") ?: "pending"

    fun recordManualRevert(remainingFraction: Float, durationSec: Int) {
        if (durationSec <= 0) return
        val usedFraction = (1f - remainingFraction).coerceIn(0f, 1f)
        revertFractionEma = if (revertSampleCount == 0) usedFraction else
            revertFractionEma + (usedFraction - revertFractionEma) * REVERT_ALPHA
        revertSampleCount = min(revertSampleCount + 1, 9_999)
        sp.edit()
            .putFloat("revertFractionEma", revertFractionEma)
            .putInt("revertSamples", revertSampleCount)
            .apply()
    }

    fun durationSuggestion(currentDurationSec: Int): Int? {
        if (suggestionState != "pending") return null
        if (revertSampleCount < MIN_REVERT_SAMPLES) return null
        if (currentDurationSec <= 0) return null
        if (revertFractionEma > 0.45f) return null
        return CANDIDATE_DURATIONS.filter { it < currentDurationSec }.maxOrNull()
    }

    fun resolveDurationSuggestion(accepted: Boolean) {
        suggestionState = if (accepted) "accepted" else "dismissed"
        sp.edit().putString("durationSuggestionState", suggestionState).apply()
    }

    private companion object {
        const val BEZEL_ALPHA = 0.12f
        const val REVERT_ALPHA = 0.08f
        const val MIN_REVERT_SAMPLES = 20
        val CANDIDATE_DURATIONS = listOf(10, 30, 60)
    }
}
