package com.clytrix.core

/**
 * The four battery modes the user can pick (Settings > Battery and Performance). Switching is
 * instant: [AdaptiveCore.evaluate] runs on every change.
 */
enum class PowerMode(val label: String, val blurb: String) {
    Performance("Performance", "Full effects, full audio and haptics"),
    Balanced("Balanced", "Smooth, lighter particles and sensors"),
    UltraSaver("Ultra Battery Saver", "Minimal effects, no ambient hum, 15 fps"),
    Adaptive("Adaptive AI", "Evolution Core picks from measurements"),
}

/**
 * What the app is actually running right now. [PowerMode.Adaptive] resolves to one of these via
 * the Evolution Core; the other modes map 1:1. Every rendering/audio/sensor decision reads these
 * numbers instead of re-deriving them, so a profile is enforced in exactly one place.
 *
 * Plain JVM (no Android imports) so the policy can be unit-tested.
 *
 * @param rank 0 = most capable. Used for floor/ceiling limits on Adaptive mode.
 * @param particleDensity multiplier on particle spawn counts; 0 = particles suspended.
 * @param idleFpsCap frame-rate cap for ambient animation (0 = display rate). Transformation
 *   flashes always run at full rate so the "essential" sequence never looks broken.
 * @param lockedFpsCap cap while the device is closed/locked and nothing is happening.
 * @param humAllowed ambient hum permitted (it's the only non-essential continuous audio).
 * @param decorAllowed tilt parallax and the scanline filter permitted.
 * @param hapticScale multiplier on vibration amplitude.
 * @param fastSensors true = gesture sensor at GAME rate; false = slower UI rate.
 */
enum class Profile(
    val label: String,
    val rank: Int,
    val particleDensity: Float,
    val idleFpsCap: Int,
    val lockedFpsCap: Int,
    val humAllowed: Boolean,
    val decorAllowed: Boolean,
    val hapticScale: Float,
    val fastSensors: Boolean,
) {
    Performance("Performance", 0, 1.0f, 0, 30, humAllowed = true, decorAllowed = true, hapticScale = 1.0f, fastSensors = true),
    Balanced("Balanced", 1, 0.55f, 30, 12, humAllowed = true, decorAllowed = true, hapticScale = 1.0f, fastSensors = true),
    Ultra("Ultra Battery Saver", 2, 0.0f, 15, 4, humAllowed = false, decorAllowed = false, hapticScale = 0.6f, fastSensors = false);

    companion object {
        fun byRank(rank: Int): Profile = values().first { it.rank == rank.coerceIn(0, 2) }
    }
}

/** How each non-Adaptive mode maps to a fixed profile. */
fun PowerMode.fixedProfile(): Profile? = when (this) {
    PowerMode.Performance -> Profile.Performance
    PowerMode.Balanced -> Profile.Balanced
    PowerMode.UltraSaver -> Profile.Ultra
    PowerMode.Adaptive -> null
}
