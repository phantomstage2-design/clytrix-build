package com.clytrix.core

/**
 * Which motion sensors CLYTRIX is listening to right now, and at what rate -- recorded by
 * [TiltSensor] and [SlapDetector] when they register/unregister, read by the Diagnostics Center.
 * Sensors are only ever registered while the app is visible and the matching feature is on.
 */
object SensorActivity {
    private val active = LinkedHashMap<String, String>()

    @Synchronized fun on(name: String, rate: String) { active[name] = rate }
    @Synchronized fun off(name: String) { active.remove(name) }
    @Synchronized fun snapshot(): Map<String, String> = LinkedHashMap(active)
}
