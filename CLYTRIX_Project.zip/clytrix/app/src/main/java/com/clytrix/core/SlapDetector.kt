package com.clytrix.core

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Optional motion activation (from Apexium): detects a sharp "slap" on the watch (a sudden acceleration spike) and calls [onSlap].
 * Register only while the activity is in the foreground.
 */
class SlapDetector(
    context: Context,
    private val threshold: () -> Float,
    private val onSlap: () -> Unit,
) : SensorEventListener {

    private val sensorManager = context.getSystemService(SensorManager::class.java)
    private val linear: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
    private val raw: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var usingRaw = false
    private var lastSlapAt = 0L

    val isAvailable: Boolean get() = linear != null || raw != null

    /** @param fast GAME rate (needed to catch a sharp spike reliably); false = UI rate, which
     *  lighter power profiles use -- a slap still registers, it just needs to be a little firmer. */
    fun start(fast: Boolean = true) {
        val sensor = linear ?: raw ?: return
        usingRaw = sensor === raw
        val delay = if (fast) SensorManager.SENSOR_DELAY_GAME else SensorManager.SENSOR_DELAY_UI
        if (sensorManager?.registerListener(this, sensor, delay) == true) {
            SensorActivity.on("Motion activation", if (fast) "game rate" else "UI rate")
        }
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
        SensorActivity.off("Motion activation")
    }

    override fun onSensorChanged(event: SensorEvent) {
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]
        var magnitude = sqrt(x * x + y * y + z * z)
        if (usingRaw) magnitude = abs(magnitude - SensorManager.GRAVITY_EARTH)
        if (magnitude < threshold()) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastSlapAt < DEBOUNCE_MS) return
        lastSlapAt = now
        onSlap()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private companion object {
        const val DEBOUNCE_MS = 1200L
    }
}
