package com.clytrix.core

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.max
import kotlin.math.min

/**
 * Reports how the watch is tilted, smoothed and clamped to a small range, so the device face can
 * parallax its layers subtly as your wrist moves -- purely decorative, never required to use the
 * app (a watch lying flat still shows everything at rest, [x]=[y]=0). Uses the gravity sensor
 * (falls back to the accelerometer where gravity isn't available) rather than the full rotation
 * vector, since all that's wanted here is "which way is down", not a true 3D orientation.
 */
class TiltSensor(
    context: Context,
    /** UI-rate sampling in the Performance profile; the slower NORMAL rate otherwise. */
    private val fast: Boolean = true,
    private val onTilt: (x: Float, y: Float) -> Unit,
) : SensorEventListener {
    private val sensorManager = context.getSystemService(SensorManager::class.java)
    private val sensor: Sensor? =
        sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private var smoothX = 0f
    private var smoothY = 0f

    val isAvailable: Boolean get() = sensor != null

    fun start() {
        val s = sensor ?: return
        val delay = if (fast) SensorManager.SENSOR_DELAY_UI else SensorManager.SENSOR_DELAY_NORMAL
        if (sensorManager?.registerListener(this, s, delay) == true) {
            SensorActivity.on("Wrist tilt", if (fast) "UI rate" else "normal rate")
        }
    }

    fun stop() {
        sensorManager?.unregisterListener(this)
        SensorActivity.off("Wrist tilt")
    }

    override fun onSensorChanged(event: SensorEvent) {
        val gx = (event.values[0] / EARTH_G).coerceIn(-1f, 1f)
        val gy = (event.values[1] / EARTH_G).coerceIn(-1f, 1f)
        smoothX += (gx - smoothX) * SMOOTHING
        smoothY += (gy - smoothY) * SMOOTHING
        val clampedX = max(-1f, min(1f, smoothX))
        val clampedY = max(-1f, min(1f, smoothY))
        onTilt(clampedX, clampedY)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    private companion object {
        const val EARTH_G = 9.80665f
        const val SMOOTHING = 0.10f
    }
}
