package com.clytrix.core.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.rotary.onRotaryScrollEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.ScalingLazyListScope
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.Chip
import androidx.wear.compose.material.ChipDefaults
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.SwipeToDismissBox
import androidx.wear.compose.material.Text
import com.clytrix.core.Activation
import com.clytrix.core.AdaptiveCore
import com.clytrix.core.Backup
import com.clytrix.core.CoreController
import com.clytrix.core.Diagnostics
import com.clytrix.core.PowerMode
import com.clytrix.core.Profile
import com.clytrix.core.Progress
import com.clytrix.core.Settings
import com.clytrix.core.Skin
import com.clytrix.core.SortMode
import com.clytrix.core.SoundEngine
import com.clytrix.core.VoiceSet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Everything the Settings pages need, bundled so page functions stay readable. */
class SettingsDeps(
    val settings: Settings,
    val sound: SoundEngine,
    val adaptive: AdaptiveCore,
    val diagnostics: Diagnostics,
    val controller: CoreController,
    val art: Art,
    val onSlapConfigChanged: () -> Unit,
)

/** The nine sections, plus two sub-pages (the roster and one form's details). */
internal object Pages {
    const val MENU = "menu"
    const val TRANSFORM = "transform"
    const val ROSTER = "roster"
    const val FORM = "form:"
    const val VISUAL = "visual"
    const val SOUND = "sound"
    const val BATTERY = "battery"
    const val EVOLUTION = "evolution"
    const val MIRA = "mira"
    const val DIAGNOSTICS = "diagnostics"
    const val BACKUP = "backup"
    const val ABOUT = "about"

    fun parent(page: String): String? = when {
        page == MENU -> null
        page == ROSTER -> TRANSFORM
        page.startsWith(FORM) -> ROSTER
        else -> MENU
    }
}

/**
 * Settings: a top menu of nine sections, each its own scrolling page. The bezel scrolls every page;
 * swipe right or press Back goes up one level (to the menu, then out to the dial).
 */
@Composable
fun SettingsScreen(deps: SettingsDeps, onBack: () -> Unit) {
    var page by rememberSaveable { mutableStateOf(Pages.MENU) }
    val goUp: () -> Unit = { Pages.parent(page)?.let { page = it } ?: onBack() }
    BackHandler { goUp() }
    // Keyed on the page so every page gets a fresh swipe state (a finished swipe never sticks).
    key(page) {
        SwipeToDismissBox(onDismissed = goUp) { isBackground ->
            if (isBackground) {
                Box(Modifier.fillMaxSize().background(Color.Black))
            } else {
                val nav: (String) -> Unit = { page = it }
                when {
                    page == Pages.MENU -> MenuPage(deps, nav, onBack)
                    page == Pages.TRANSFORM -> TransformationPage(deps, nav)
                    page == Pages.ROSTER -> RosterPage(deps, nav)
                    page.startsWith(Pages.FORM) -> FormPage(deps, page.removePrefix(Pages.FORM), goUp)
                    page == Pages.VISUAL -> VisualPage(deps)
                    page == Pages.SOUND -> SoundPage(deps)
                    page == Pages.BATTERY -> BatteryPage(deps)
                    page == Pages.EVOLUTION -> EvolutionPage(deps, nav)
                    page == Pages.MIRA -> MiraPage(deps)
                    page == Pages.DIAGNOSTICS -> DiagnosticsPage(deps)
                    page == Pages.BACKUP -> BackupPage(deps)
                    page == Pages.ABOUT -> AboutPage(deps)
                    else -> MenuPage(deps, nav, onBack)
                }
            }
        }
    }
}

// ---- shared page scaffolding and widgets -------------------------------------------------------------

/** A bezel-scrollable round-screen list with a title. */
@Composable
internal fun Page(title: String, content: ScalingLazyListScope.() -> Unit) {
    val listState = rememberScalingLazyListState()
    val focus = remember { FocusRequester() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    ScalingLazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onRotaryScrollEvent { event ->
                scope.launch { listState.scrollBy(event.verticalScrollPixels) }
                true
            }
            .focusRequester(focus)
            .focusable(),
        contentPadding = PaddingValues(top = 30.dp, bottom = 40.dp, start = 10.dp, end = 10.dp),
    ) {
        item { Title(title) }
        content()
    }
}

@Composable
internal fun Title(text: String) {
    Text(
        text = text.uppercase(),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.6.sp,
        textAlign = TextAlign.Center,
        color = MaterialTheme.colors.secondary,
        modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
    )
}

@Composable
internal fun Header(text: String) {
    Text(
        text = text,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.6.sp,
        color = MaterialTheme.colors.primary,
        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp),
    )
}

@Composable
internal fun Note(text: String, color: Color = SoftText) {
    Text(text = text, color = color, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp))
}

@Composable
internal fun NavChip(label: String, sub: String? = null, onClick: () -> Unit) {
    val secondary: (@Composable RowScope.() -> Unit)? = if (sub == null) null else {
        { Text(sub, maxLines = 2) }
    }
    Chip(
        onClick = onClick,
        label = { Text(label, maxLines = 2) },
        secondaryLabel = secondary,
        colors = ChipDefaults.secondaryChipColors(),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
internal fun SettingChip(label: String, value: String, swatch: Palette? = null, onClick: () -> Unit) {
    val iconSlot: (@Composable BoxScope.() -> Unit)? = if (swatch == null) null else {
        {
            Box(Modifier.size(26.dp).background(Brush.radialGradient(listOf(swatch.coreA, swatch.glow, swatch.coreB)), CircleShape))
        }
    }
    Chip(
        onClick = onClick,
        label = { Text(label) },
        secondaryLabel = { Text(value, maxLines = 3) },
        icon = iconSlot,
        colors = ChipDefaults.secondaryChipColors(),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
internal fun ToggleChip(label: String, checked: Boolean, sub: String? = null, onChange: (Boolean) -> Unit) {
    Chip(
        onClick = { onChange(!checked) },
        label = { Text(label) },
        secondaryLabel = { Text((if (checked) "On" else "Off") + (sub?.let { " · $it" } ?: ""), maxLines = 2) },
        colors = if (checked) ChipDefaults.primaryChipColors() else ChipDefaults.secondaryChipColors(),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
internal fun ActionChip(label: String, sub: String? = null, primary: Boolean = false, onClick: () -> Unit) {
    val secondary: (@Composable RowScope.() -> Unit)? = if (sub == null) null else {
        { Text(sub, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), maxLines = 2) }
    }
    Chip(
        onClick = onClick,
        label = { Text(label, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) },
        secondaryLabel = secondary,
        colors = if (primary) ChipDefaults.primaryChipColors() else ChipDefaults.secondaryChipColors(),
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
internal fun TwoChips(left: String, right: String, onLeft: () -> Unit, onRight: () -> Unit, rightPrimary: Boolean = true) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Chip(onClick = onLeft, label = { Text(left, fontSize = 12.sp) }, colors = ChipDefaults.secondaryChipColors(), modifier = Modifier.weight(1f))
        Spacer(Modifier.width(6.dp))
        Chip(onClick = onRight, label = { Text(right, fontSize = 12.sp) },
            colors = if (rightPrimary) ChipDefaults.primaryChipColors() else ChipDefaults.secondaryChipColors(), modifier = Modifier.weight(1f))
    }
}

@Composable
internal fun ProgressBar(fraction: Float, color: Color) {
    Box(Modifier.fillMaxWidth().height(6.dp).background(Color(0xFF26302C), RoundedCornerShape(3.dp))) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(6.dp).background(color, RoundedCornerShape(3.dp)))
    }
}

internal fun <T> List<T>.after(current: T): T = this[(indexOf(current) + 1).mod(size)]

internal fun shareFile(context: android.content.Context, file: File, mime: String, title: String) {
    val uri = Backup.uriFor(context, file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    runCatching { context.startActivity(Intent.createChooser(intent, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

// ---- the menu ----------------------------------------------------------------------------------------

@Composable
private fun MenuPage(deps: SettingsDeps, nav: (String) -> Unit, onBack: () -> Unit) {
    val s = deps.settings
    Page("CLYTRIX") {
        s.recoveryNotice?.let { notice ->
            item {
                Chip(
                    onClick = { s.dismissRecoveryNotice() },
                    label = { Text(notice, fontSize = 11.sp, maxLines = 4) },
                    secondaryLabel = { Text("Tap to dismiss") },
                    colors = ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        item { NavChip("Transformation", "${s.aliens.size} form(s) · ${s.activation.label} to activate") { nav(Pages.TRANSFORM) } }
        item { NavChip("Visual Customization", s.skin.label) { nav(Pages.VISUAL) } }
        item { NavChip("Sound and Haptics", if (s.soundOn) "${s.voiceSet.label} · ${s.effectsVolume}%" else "Sound off") { nav(Pages.SOUND) } }
        item { NavChip("Battery and Performance", "${s.powerMode.label} → ${s.activeProfile.label}") { nav(Pages.BATTERY) } }
        item { NavChip("CLYTRIX Evolution Core", if (s.adaptiveCoreOn) "Active · ${deps.adaptive.evolution.adjustmentsTotal} adjustments" else "Off") { nav(Pages.EVOLUTION) } }
        item { NavChip("Mira AI Link", when {
            !com.clytrix.core.MiraLink.enabled -> "Off (optional)"
            com.clytrix.core.MiraLink.isPaired -> "Paired"
            else -> "On · not paired"
        }) { nav(Pages.MIRA) } }
        item { NavChip("System Diagnostics", "Health, tests and reports") { nav(Pages.DIAGNOSTICS) } }
        item { NavChip("Backup and Restore") { nav(Pages.BACKUP) } }
        item { NavChip("About CLYTRIX") { nav(Pages.ABOUT) } }
        item { ActionChip("Done", primary = true, onClick = onBack) }
    }
}

// ---- 1. Transformation --------------------------------------------------------------------------------

@Composable
private fun TransformationPage(deps: SettingsDeps, nav: (String) -> Unit) {
    val s = deps.settings
    Page("Transformation") {
        item { NavChip("Transformation roster", "${s.aliens.size} form(s) · add, rename, order, favorites") { nav(Pages.ROSTER) } }
        item {
            SettingChip("Activation gesture", if (s.activation == Activation.Tap) "Tap to transform · long-press shuffles" else "Long-press to transform · taps are ignored") {
                s.updateActivation(if (s.activation == Activation.Tap) Activation.LongPress else Activation.Tap)
            }
        }
        item {
            SettingChip("Gesture sensitivity", listOf("Low · deliberate input", "Normal", "High · light touch")[s.gestureSensitivity]) {
                s.updateGestureSensitivity((s.gestureSensitivity + 1) % 3)
            }
        }
        item {
            SettingChip("Bezel steps per form", if (s.bezelClicks == 1) "1 click" else "${s.bezelClicks} clicks") {
                s.updateBezelClicks(if (s.bezelClicks >= 4) 1 else s.bezelClicks + 1)
            }
        }
        item { SettingChip("Selection order", s.sort.label) { s.updateSort(SortMode.values().toList().after(s.sort)) } }
        item { Header("ASCENSION MODE") }
        item { ToggleChip("Ascension Mode", s.ascensionOn, "for forms marked Ascended") { s.updateAscensionOn(it) } }
        item { Note("Mark a form as Ascended in the roster. With Ascension Mode on, it transforms with stronger light, extra geometry, its own sound and haptics.") }
        item { Header("TIME LIMIT") }
        item {
            SettingChip("Transformation time", if (s.durationSec == 0) "No limit (stay until you revert)" else "${s.durationSec} s, then recharge") {
                s.updateDurationSec(Settings.DURATIONS.after(s.durationSec))
            }
        }
        s.durationSuggestion()?.let { suggested ->
            item { Note("You usually revert well before time's up. Try ${suggested}s?") }
            item { TwoChips("Not now", "Use ${suggested}s", { s.dismissDurationSuggestion() }, { s.acceptDurationSuggestion(suggested) }) }
        }
        item {
            val p = s.progress
            Note(if (p.overdriveUnlocked) "Overdrive unlocked: removes a chosen time limit." else "Transform ${p.totalTransforms}/${Progress.UNLOCK_AT} times to unlock Overdrive.")
        }
        if (!s.progress.overdriveUnlocked) item { ProgressBar(s.progress.overdriveProgress(), overdriveGlow) }
        item {
            val unlocked = s.progress.overdriveUnlocked
            ToggleChip("Overdrive", s.overdriveOn && unlocked, if (!unlocked) "locked" else null) { if (unlocked) s.updateOverdriveOn(it) }
        }
        item { Header("MOTION") }
        item { ToggleChip("Wrist-tilt parallax", s.parallaxOn, "visual only") { s.updateParallaxOn(it) } }
        item {
            ToggleChip("Motion activation", s.slapOn, "sharp wrist flick transforms/reverts") {
                s.updateSlapOn(it); deps.onSlapConfigChanged()
            }
        }
        if (s.slapOn) item {
            SettingChip("Motion force needed", listOf("Light", "Normal", "Hard")[s.slapForce]) { s.updateSlapForce((s.slapForce + 1) % 3) }
        }
        item { Header("OTHER") }
        item { ToggleChip("Disguise mode", s.disguiseOn, "looks like a plain watch face") { s.updateDisguiseOn(it) } }
        item { ToggleChip("Smart tuning", s.smartTuningOn, "learns your bezel feel") { s.updateSmartTuningOn(it) } }
    }
}

// ---- 2. Visual ------------------------------------------------------------------------------------------

@Composable
private fun VisualPage(deps: SettingsDeps) {
    val s = deps.settings
    Page("Visual Customization") {
        item { SettingChip("Color theme", s.skin.label, swatch = paletteFor(s.skin)) { s.updateSkin(Skin.values().toList().after(s.skin)) } }
        item { SettingChip("Animation intensity", listOf("Subtle", "Standard", "Radiant")[s.animationIntensity]) { s.updateAnimationIntensity((s.animationIntensity + 1) % 3) } }
        item { ToggleChip("Particles", s.particlesOn, if (s.particlesOn && !s.effectiveParticlesOn) "paused by ${s.activeProfile.label}" else null) { s.updateParticlesOn(it) } }
        item { ToggleChip("Scanline filter", s.crtOn, if (s.crtOn && !s.effectiveCrtOn) "paused by ${s.activeProfile.label}" else "retro screen effect") { s.updateCrtOn(it) } }
        item { ToggleChip("Show form names", s.showNames) { s.updateShowNames(it) } }
        item { ToggleChip("Keep screen on", s.stayAwake, "while CLYTRIX is open") { s.updateStayAwake(it) } }
    }
}

// ---- 3. Sound and haptics -----------------------------------------------------------------------------

@Composable
private fun SoundPage(deps: SettingsDeps) {
    val s = deps.settings
    val sound = deps.sound
    Page("Sound and Haptics") {
        item { ToggleChip("Sound", s.soundOn) { s.updateSoundOn(it); sound.onHumSettingChanged() } }
        item {
            SettingChip("Sound set", if (sound.synthesizing) "${s.voiceSet.label} · building…" else s.voiceSet.label) {
                s.updateVoiceSet(VoiceSet.values().toList().after(s.voiceSet)); sound.reloadVoices()
            }
        }
        item {
            SettingChip("Effects volume", "${s.effectsVolume}%") {
                s.updateEffectsVolume(listOf(25, 50, 80, 100, 0).after(s.effectsVolume).let { if (it == 0 && s.effectsVolume == 0) 25 else it })
                sound.refreshHum()
            }
        }
        item { ToggleChip("Ambient energy hum", s.ambientHumOn, if (s.ambientHumOn && !s.effectiveHumOn) "paused by ${s.activeProfile.label}" else null) { s.updateAmbientHumOn(it); sound.onHumSettingChanged() } }
        item { ToggleChip("Respect silent mode", s.respectSilent, "quiet in Vibrate/Mute") { s.updateRespectSilent(it); sound.refreshHum() } }
        item {
            var label by remember { mutableStateOf(sound.volumeLabel()) }
            SettingChip("Test sound", label) { sound.testAndFixVolume(); label = sound.volumeLabel() }
        }
        item { Header("HAPTICS") }
        item { ToggleChip("Haptics", s.hapticsOn) { s.updateHapticsOn(it) } }
        item { SettingChip("Haptic intensity", listOf("Light", "Medium", "Strong")[s.hapticIntensity]) { s.updateHapticIntensity((s.hapticIntensity + 1) % 3) } }
    }
}

// ---- 4. Battery and performance ------------------------------------------------------------------------

@Composable
private fun BatteryPage(deps: SettingsDeps) {
    val s = deps.settings
    val a = deps.adaptive
    Page("Battery and Performance") {
        item {
            Note(buildString {
                append("Now: ${s.activeProfile.label}")
                if (a.batteryPct >= 0) append(" · battery ${a.batteryPct}%" + if (a.charging) " (charging)" else "")
            }, color = Color.White)
        }
        item { Note(s.profileReason) }
        for (mode in PowerMode.values()) {
            item(key = "mode_${mode.name}") {
                Chip(
                    onClick = { s.updatePowerMode(mode); a.evaluate() },
                    label = { Text(mode.label) },
                    secondaryLabel = { Text(mode.blurb, maxLines = 2) },
                    colors = if (s.powerMode == mode) ChipDefaults.primaryChipColors() else ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
        if (s.powerMode == PowerMode.Adaptive) {
            item { Header("ADAPTIVE LIMITS") }
            item {
                SettingChip("Most capable allowed", Profile.byRank(s.adaptiveCeiling).label) {
                    s.updateAdaptiveLimits((s.adaptiveCeiling + 1) % 3, s.adaptiveFloor); a.evaluate()
                }
            }
            item {
                SettingChip("Lightest allowed", Profile.byRank(s.adaptiveFloor).label) {
                    val next = if (s.adaptiveFloor >= 2) s.adaptiveCeiling else s.adaptiveFloor + 1
                    s.updateAdaptiveLimits(s.adaptiveCeiling, next); a.evaluate()
                }
            }
            item { Note("Adaptive AI never goes outside these limits, even when the battery is low. It learns from measured smoothness and drain (see Evolution Core).") }
        }
        item { Header("WHAT EACH PROFILE DOES") }
        item { Note("Performance: full effects, display frame rate, all sensors at full rate.") }
        item { Note("Balanced: 30 fps cap, ~half the particles, slower tilt sampling.") }
        item { Note("Ultra Battery Saver: 15 fps, no particles, no ambient hum, no tilt or scanlines, softer haptics. Transformations, sound effects, bezel and gestures always keep working.") }
    }
}

// ---- 8. Backup and restore ----------------------------------------------------------------------------

@Composable
private fun BackupPage(deps: SettingsDeps) {
    val s = deps.settings
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val importLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null && !busy) scope.launch {
            busy = true
            status = "Importing…"
            val voiceBefore = s.voiceSet
            // Reading and validating a zip is I/O-heavy: never on the main thread.
            val r = withContext(Dispatchers.IO) { s.importBackup(context, uri) }
            status = r.message
            if (s.voiceSet != voiceBefore) deps.sound.reloadVoices()
            deps.sound.refreshHum()
            deps.adaptive.evaluate()
            deps.onSlapConfigChanged()
            busy = false
        }
    }
    Page("Backup and Restore") {
        status?.let { item { Note(it, color = Color.White) } }
        item {
            ActionChip(if (busy) "Working…" else "Export backup", "Forms, photos, settings, favorites, usage") {
                if (!busy) scope.launch {
                    busy = true
                    val file = withContext(Dispatchers.IO) { s.exportBackup(context) }
                    busy = false
                    if (file != null) shareFile(context, file, "application/zip", "Share CLYTRIX backup") else status = "Export failed"
                }
            }
        }
        item {
            ActionChip("Import backup", "From a .zip on this watch") {
                runCatching { importLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
                    .onFailure { status = "No file picker available on this watch" }
            }
        }
        item { Note("Imports are checked before anything is written: unknown files, unsafe names, oversized entries and unreadable photos are skipped. CLYTRIX backups are kept separate from Apexium; an Apexium backup can be imported for its forms only.") }
    }
}

// ---- 9. About -------------------------------------------------------------------------------------------

@Composable
private fun AboutPage(deps: SettingsDeps) {
    val context = LocalContext.current
    val version = remember { runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "1.0" }
    Page("About CLYTRIX") {
        item { Note("CLYTRIX $version · Celestial Light and Transformation Matrix", color = Color.White) }
        item { Note("An original, fictional celestial transformation-device simulator for Wear OS. All graphics and sounds are generated by the app itself.") }
        item { Note("Works fully offline. No account, no cloud, no API keys. The Evolution Core learns on this watch only; the Mira AI link is optional.") }
        item { Note("Built on the Apexium engine (state machine, sound scheduler, crash recovery) as a separate app: com.clytrix.core.") }
        item { Note("Uptime ${Diagnostics.fmtDuration(deps.diagnostics.uptimeMs())}", color = DimText) }
    }
}
