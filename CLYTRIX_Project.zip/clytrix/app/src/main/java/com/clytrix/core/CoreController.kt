package com.clytrix.core

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlin.math.abs

/**
 * All behaviour of the device lives here so the UI stays a pure function of state. Everything is
 * called on the main thread (touch, rotary, sensor and Mira callbacks all arrive there).
 *
 * Apexium's deterministic state machine, kept: Disguised -> Locked -> Opening -> Selecting ->
 * Flashing -> Active -> (Recharging), with every timed phase driven by a LaunchedEffect keyed on
 * the phase so it's cancelled cleanly by lifecycle changes. CLYTRIX adds:
 *  - every phase change validated against [PhaseGraph] (violations are recorded for Diagnostics);
 *  - Ascension Mode ([Settings.isAscended]) for flagged forms;
 *  - a choice of activation gesture (tap or long press) to prevent accidental transformations;
 *  - transformation confirmation cue (sound) synchronized with the flash;
 *  - no mandatory timer: Active lasts until you revert unless you picked a time limit;
 *  - request handlers for the optional Mira AI link ([selectFavorite], [selectForm], [openDial]);
 *  - input counters for Diagnostics and latency stamps for [PerfMonitor].
 */
class CoreController(
    val settings: Settings,
    private val sound: SoundEngine,
    private val haptics: Haptics,
    private val perf: PerfMonitor,
) {
    var phase by mutableStateOf(if (settings.disguiseOn) Phase.Disguised else Phase.Locked)
        private set

    /** Index into [roster]. */
    var index by mutableIntStateOf(0)
        private set

    /** Cumulative dial steps (never wraps), used to spin the selection ring smoothly. */
    var spinSteps by mutableIntStateOf(0)
        private set

    /** +1 when the last step went forward, -1 backward; drives the slide direction. */
    var direction by mutableIntStateOf(1)
        private set

    var activeAlien by mutableStateOf<Alien?>(null)
        private set

    /** Whether the active (or flashing) transformation is an Ascension. */
    var activeAscended by mutableStateOf(false)
        private set

    /** Incremented on every transformation so the UI can start its flash/particle animation. */
    var flashCount by mutableIntStateOf(0)
        private set

    var recalibrateCount by mutableIntStateOf(0)
        private set

    /** Incremented when a tap is ignored because Long-press activation is on, to show a hint. */
    var holdHintCount by mutableIntStateOf(0)
        private set

    /** 1.0 = full time left, 0.0 = expired. Always 1.0 with no time limit or with Overdrive. */
    var remaining by mutableFloatStateOf(1f)
        private set

    // ---- diagnostics counters (plain fields: read on demand, never drive recomposition) --------
    @Volatile var rotaryEvents = 0; private set
    @Volatile var touchGestures = 0; private set
    @Volatile var transformCount = 0; private set
    @Volatile var illegalTransitions = 0; private set
    @Volatile var lastIllegalTransition: String? = null; private set

    private var shuffledOrder: List<Alien>? = null

    val roster: List<Alien> get() = shuffledOrder?.let { shuffled ->
        // Keep only ids still in the live roster; a stale shuffle never shows a removed form.
        val live = settings.roster()
        val liveIds = live.map { it.id }.toSet()
        val kept = shuffled.filter { it.id in liveIds }
        if (kept.size != live.size) live else kept
    } ?: settings.roster()

    /** Null only when the user hasn't added any forms yet. */
    val currentAlien: Alien?
        get() {
            val list = roster
            if (list.isEmpty()) return null
            return list[Math.floorMod(index, list.size)]
        }

    /** True while the dial is live (selecting or transformed) -- when the ambient hum belongs. */
    fun isDialActive(): Boolean = phase == Phase.Selecting || phase == Phase.Flashing || phase == Phase.Active

    private fun moveTo(to: Phase) {
        val from = phase
        if (!PhaseGraph.isAllowed(from, to)) {
            illegalTransitions += 1
            lastIllegalTransition = "$from -> $to"
        }
        phase = to
    }

    // ---- rotary bezel -----------------------------------------------------------------------------

    private var rotaryUnit = 0f
    private var rotaryAcc = 0f
    private var rotaryLastAt = 0L

    /** @param eventUptimeMs the rotary event's own timestamp, for input-latency measurement. */
    fun onRotary(pixels: Float, eventUptimeMs: Long = SystemClock.uptimeMillis()) {
        rotaryEvents += 1
        if (phase != Phase.Selecting || pixels == 0f) return
        perf.onInput(eventUptimeMs)
        val now = SystemClock.elapsedRealtime()
        if (now - rotaryLastAt > 450) rotaryAcc = 0f
        rotaryLastAt = now
        if (rotaryUnit == 0f) {
            val tuner = settings.adaptiveTuner
            rotaryUnit = if (settings.smartTuningOn && tuner.bezelUnitEma > 0f) tuner.bezelUnitEma else abs(pixels)
            if (settings.smartTuningOn) tuner.observeBezelUnit(abs(pixels))
        }
        val clicks = pixels / rotaryUnit
        if (rotaryAcc != 0f && (rotaryAcc > 0f) != (clicks > 0f)) rotaryAcc = 0f
        rotaryAcc += clicks
        val needed = settings.bezelClicks.toFloat()
        while (abs(rotaryAcc) >= needed - 0.001f) {
            val dir = if (rotaryAcc > 0f) 1 else -1
            step(dir)
            rotaryAcc -= dir * needed
        }
    }

    /** Move to the next / previous form. */
    fun step(delta: Int) {
        if (phase != Phase.Selecting) return
        val size = roster.size
        if (size <= 1) {
            sound.play(SoundEngine.Fx.Error)
            haptics.tick()
            return
        }
        index = Math.floorMod(index + delta, size)
        spinSteps += delta
        direction = if (delta > 0) 1 else -1
        sound.tick(spinSteps)
        haptics.tick()
    }

    /** Session-only shuffle of the dial order (Apexium's Recalibrate). 3+ forms only. */
    fun recalibrate() {
        if (phase != Phase.Selecting) return
        val current = roster
        if (current.size < 3) { sound.play(SoundEngine.Fx.Error); haptics.tick(); return }
        val currentId = currentAlien?.id
        var next = current.shuffled()
        if (next == current) next = next.shuffled()
        shuffledOrder = next
        index = currentId?.let { id -> next.indexOfFirst { it.id == id }.takeIf { it >= 0 } } ?: 0
        recalibrateCount += 1
        sound.play(SoundEngine.Fx.Recalibrate)
        haptics.recalibrate()
    }

    // ---- touch / sensor -----------------------------------------------------------------------------

    private var lastTaps = LongArray(3)

    fun noteInput(eventUptimeMs: Long) { touchGestures += 1; perf.onInput(eventUptimeMs) }

    /**
     * Tap. Returns true when the caller should open Settings (an empty roster, or three quick taps
     * on the disguise face).
     */
    fun onTap(): Boolean {
        when (phase) {
            Phase.Locked -> if (roster.isEmpty()) return true else open()
            Phase.Selecting -> if (settings.activation == Activation.Tap) transform() else {
                holdHintCount += 1
                haptics.tick()
            }
            Phase.Active -> revert()
            Phase.Disguised -> {
                val now = SystemClock.uptimeMillis()
                lastTaps[0] = lastTaps[1]; lastTaps[1] = lastTaps[2]; lastTaps[2] = now
                if (lastTaps[0] != 0L && now - lastTaps[0] <= 1200L) {
                    lastTaps = LongArray(3)
                    return true
                }
            }
            else -> Unit
        }
        return false
    }

    /**
     * Long press. While selecting: transforms when Long-press activation is on, otherwise
     * recalibrates (Apexium behaviour). Returns true when the caller should open Settings.
     */
    fun onLongPress(): Boolean {
        return when (phase) {
            Phase.Locked -> true
            Phase.Disguised -> { open(); false }
            Phase.Selecting -> {
                if (settings.activation == Activation.LongPress) transform() else recalibrate()
                false
            }
            Phase.Active -> { revert(); false }
            else -> false
        }
    }

    /** Optional motion activation: only when switched on, only in the phases where it's safe. */
    fun onSlap() {
        if (!settings.slapOn) return
        when (phase) {
            Phase.Selecting -> transform()
            Phase.Active -> revert()
            else -> Unit
        }
    }

    /**
     * The watch's physical Back key: open the dial while locked, close it while selecting, revert
     * while transformed. Returns false where the system default (leave the app) should happen.
     */
    fun onBackKey(): Boolean {
        return when (phase) {
            Phase.Locked -> if (roster.isNotEmpty()) { open(); true } else false
            Phase.Selecting -> { close(); true }
            Phase.Active -> { revert(); true }
            else -> false
        }
    }

    // ---- Mira AI link requests (main thread) -----------------------------------------------------------

    /** Opens the dial if it's closed. Returns false if there's nothing to show. */
    fun openDial(): Boolean {
        if (roster.isEmpty()) return false
        if (phase == Phase.Locked || phase == Phase.Disguised) open()
        return phase == Phase.Opening || phase == Phase.Selecting
    }

    /** Points the dial at the first favourite (opening it if needed). Never transforms by itself. */
    fun selectFavorite(): Alien? {
        val list = roster
        val i = list.indexOfFirst { it.favorite }
        if (i < 0) return null
        return selectIndex(i)
    }

    /** Points the dial at the form named [name] (case-insensitive). Never transforms by itself. */
    fun selectForm(name: String): Alien? {
        val list = roster
        val i = list.indexOfFirst { it.name.equals(name.trim(), ignoreCase = true) }
        if (i < 0) return null
        return selectIndex(i)
    }

    private fun selectIndex(i: Int): Alien? {
        if (phase == Phase.Flashing || phase == Phase.Active || phase == Phase.Recharging) return null
        if (!openDial()) return null
        if (i != index) {
            direction = if (i > index) 1 else -1
            spinSteps += i - index
            index = i
        }
        sound.tick(spinSteps)
        haptics.tick()
        return currentAlien
    }

    // ---- transitions ---------------------------------------------------------------------------------

    private fun open() {
        shuffledOrder = null
        if (index >= roster.size) index = 0
        moveTo(Phase.Opening)
        sound.play(SoundEngine.Fx.Open)
        haptics.open()
    }

    private fun close() {
        shuffledOrder = null
        moveTo(restingPhase())
        sound.play(SoundEngine.Fx.Close)
        sound.stopHum()
        haptics.close()
    }

    private fun transform() {
        val alien = currentAlien ?: return
        val ascended = settings.isAscended(alien)
        activeAlien = alien
        activeAscended = ascended
        settings.recordUse(alien)
        remaining = 1f
        flashCount += 1
        transformCount += 1
        moveTo(Phase.Flashing)
        val hadOverdrive = settings.progress.overdriveUnlocked
        settings.progress.recordTransform(ascended)
        // Confirmation cue lands with the flash; the full transformation follows it in the queue.
        sound.play(SoundEngine.Fx.Confirm)
        sound.playTransform(ascended)
        if (ascended) haptics.ascension() else haptics.transform()
        if (!hadOverdrive && settings.progress.overdriveUnlocked) haptics.overdriveUnlocked()
    }

    private fun revert() {
        if (phase == Phase.Active && settings.smartTuningOn) {
            settings.adaptiveTuner.recordManualRevert(remaining, settings.durationSec)
        }
        val ascended = activeAscended
        activeAlien = null
        activeAscended = false
        moveTo(restingPhase())
        sound.playRevert(ascended)
        sound.stopHum()
        haptics.revert()
    }

    private fun restingPhase() = if (settings.disguiseOn) Phase.Disguised else Phase.Locked

    /** Called when the app returns to the foreground so a stale state never lingers. */
    fun onResumed() {
        if (phase == Phase.Disguised && !settings.disguiseOn) moveTo(Phase.Locked)
        if (phase == Phase.Locked && settings.disguiseOn) moveTo(Phase.Disguised)
        if (index >= roster.size) index = 0
    }

    // ---- timed phases (driven by LaunchedEffect in the UI) --------------------------------------------

    suspend fun runOpening() {
        delay(OPEN_MS)
        if (phase == Phase.Opening) {
            moveTo(Phase.Selecting)
            sound.play(SoundEngine.Fx.Activate)
            sound.startHum()
            haptics.activate()
        }
    }

    suspend fun runFlash() {
        delay(FLASH_MS)
        if (phase == Phase.Flashing) moveTo(Phase.Active)
    }

    /** Counts down only when the user chose a time limit; never while Overdrive is on. */
    suspend fun runActive() {
        if (settings.overdriveOn && settings.progress.overdriveUnlocked) { remaining = 1f; return }
        val total = settings.durationSec * 1000L
        if (total <= 0L) { remaining = 1f; return }
        val start = SystemClock.elapsedRealtime()
        var warned = false
        while (phase == Phase.Active) {
            val elapsed = SystemClock.elapsedRealtime() - start
            remaining = (1f - elapsed.toFloat() / total).coerceIn(0f, 1f)
            if (!warned && remaining < 0.2f && total >= 10_000L) {
                warned = true
                haptics.warning()
            }
            if (elapsed >= total) {
                activeAlien = null
                activeAscended = false
                moveTo(Phase.Recharging)
                sound.play(SoundEngine.Fx.Timeout)
                sound.stopHum()
                haptics.timeout()
                return
            }
            // 10 Hz is plenty for a countdown ring and keeps the loop cheap.
            delay(100)
        }
    }

    suspend fun runRecharge() {
        delay(RECHARGE_MS)
        if (phase == Phase.Recharging) {
            moveTo(restingPhase())
            sound.play(SoundEngine.Fx.Recharged)
            haptics.recharged()
        }
    }

    companion object {
        const val OPEN_MS = 760L
        const val FLASH_MS = 520L
        const val RECHARGE_MS = 3200L
    }
}
