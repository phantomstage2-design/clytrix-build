package com.clytrix.core

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/**
 * CLYTRIX EVOLUTION CORE -- the local, offline optimizer. It measures how CLYTRIX actually runs on
 * this watch and improves its *configuration* within safe limits. It never rewrites code, never
 * downloads anything, and needs no API keys; everything it learns stays in app-private storage.
 *
 * Built on Apexium's Adaptive Core (budgeted, logged adjustments -- see [AdaptiveCore]) and Adaptive
 * Tuner, plus CrashGuard's crash history. The decision rules live in [EvolutionPolicy].
 *
 * What it does, all from recorded measurements ([PerfMonitor], battery broadcasts):
 *  1. Learns per-profile jank, frame time and real battery drain while CLYTRIX is on screen.
 *  2. In Adaptive AI mode, those numbers choose the power profile (see [AdaptiveCore.evaluate]).
 *  3. Trims particle density down after janky windows, and tries it back up after smooth ones --
 *     each increase is a *trial* that is automatically rolled back if jank gets worse.
 *  4. Produces recommendations for user-owned settings (scanline filter, keep-screen-on, ...).
 *     Those are never applied without the user tapping Apply, and each one can be undone.
 *
 * Every change is an [Adjustment] in a persisted history with its before/after numbers, so the
 * Diagnostics Center can show it and the user can roll any of it back.
 */
class EvolutionCore(
    context: Context,
    private val settings: Settings,
    /** AdaptiveCore's budgeted logger: false = today's adjustment budget is used up. */
    private val spend: (message: String, essential: Boolean) -> Boolean,
) {
    enum class Status { Applied, Trial, Kept, RolledBack, Reverted }

    data class Adjustment(
        val id: Long,
        val at: Long,
        val knob: String,
        val from: String,
        val to: String,
        val reason: String,
        val auto: Boolean,
        val status: Status,
        val beforeJank: Float?,
        val afterJank: Float?,
    )

    private val sp = context.applicationContext.getSharedPreferences("clytrix_evolution", Context.MODE_PRIVATE)

    private val stats = HashMap<Profile, EvolutionPolicy.ProfileStats>()
    private val history = ArrayList<Adjustment>()
    private val dismissedUntil = HashMap<String, Long>()

    /** Bumped on every change so Compose screens reading [historySnapshot] etc. refresh. */
    var revision by mutableIntStateOf(0); private set
    var adjustmentsTotal by mutableIntStateOf(sp.getInt("adjustmentsTotal", 0)); private set
    var rollbacksTotal by mutableIntStateOf(sp.getInt("rollbacksTotal", 0)); private set
    var lastOptimization by mutableStateOf(sp.getString("lastOptimization", null)); private set

    /** The two most recent measurement windows, for "previous vs current" in Diagnostics. */
    var previousWindow by mutableStateOf<PerfMonitor.Window?>(null); private set
    var currentWindow by mutableStateOf<PerfMonitor.Window?>(null); private set

    private var goodStreak = 0
    private var trialAdjustmentId: Long? = null
    private var trialBaselineJank = 0f
    private var trialPrevScale = 1f

    /** A profile the user pinned by rolling back an automatic switch, and until when. */
    var profileHold: Profile? = null; private set
    private var profileHoldUntil = 0L

    // battery-drain anchor: only measured while visible, on one profile, not charging
    private var drainAnchorPct = -1
    private var drainAnchorAt = 0L
    private var drainAnchorProfile: Profile? = null

    init {
        load()
        settings.evoParticleScale = sp.getFloat("particleScale", 1f)
            .coerceIn(EvolutionPolicy.PARTICLE_MIN, EvolutionPolicy.PARTICLE_MAX)
    }

    fun statsFor(p: Profile): EvolutionPolicy.ProfileStats? = stats[p]
    fun statsSnapshot(): Map<Profile, EvolutionPolicy.ProfileStats> = HashMap(stats)
    fun historySnapshot(): List<Adjustment> = history.toList().asReversed()

    fun activeHold(now: Long = System.currentTimeMillis()): Profile? =
        if (profileHold != null && now < profileHoldUntil) profileHold else null

    // ---- measurements ----------------------------------------------------------------------------

    /** Called every evaluation tick with the window [PerfMonitor] just closed (null = too few frames). */
    fun onWindow(w: PerfMonitor.Window?, profile: Profile) {
        if (w == null) return
        previousWindow = currentWindow
        currentWindow = w
        stats[profile] = EvolutionPolicy.withWindow(stats[profile] ?: EvolutionPolicy.ProfileStats(), w)
        saveStats()

        trialAdjustmentId?.let { id ->
            trialAdjustmentId = null
            if (EvolutionPolicy.keepTrial(trialBaselineJank, w.jankFraction)) {
                setStatus(id, Status.Kept, w.jankFraction)
                note("Kept particle density ${pct(settings.evoParticleScale)}: jank ${pct(w.jankFraction)} stayed within limits")
            } else {
                setParticleScale(trialPrevScale)
                setStatus(id, Status.RolledBack, w.jankFraction)
                rollbacksTotal += 1
                sp.edit().putInt("rollbacksTotal", rollbacksTotal).apply()
                note("Rolled back particle density to ${pct(trialPrevScale)}: jank rose to ${pct(w.jankFraction)}")
            }
            bump()
            return
        }

        goodStreak = if (w.jankFraction < EvolutionPolicy.JANK_LOW) goodStreak + 1 else 0
        if (!settings.adaptiveCoreOn || !settings.particlesOn || profile.particleDensity <= 0f) return
        val cur = settings.evoParticleScale
        val next = EvolutionPolicy.nextParticleScale(cur, w.jankFraction, goodStreak) ?: return
        val increase = next > cur
        val reason = if (increase) "${goodStreak} smooth windows in a row" else "jank ${pct(w.jankFraction)} on ${profile.label}"
        if (!spend("Particle density ${pct(cur)} → ${pct(next)} ($reason)", false)) return
        setParticleScale(next)
        val adj = record("particles", pct(cur), pct(next), reason, auto = true,
            status = if (increase) Status.Trial else Status.Applied, beforeJank = w.jankFraction)
        if (increase) {
            trialAdjustmentId = adj.id; trialBaselineJank = w.jankFraction; trialPrevScale = cur
        }
        goodStreak = 0
    }

    /** Battery level updates while CLYTRIX is visible; turns 1% drops into %/hour samples. */
    fun onBattery(pct: Int, charging: Boolean, profile: Profile, now: Long = System.currentTimeMillis()) {
        if (charging || pct <= 0) { resetDrainAnchor(); return }
        if (drainAnchorPct < 0 || drainAnchorProfile != profile || pct > drainAnchorPct) {
            drainAnchorPct = pct; drainAnchorAt = now; drainAnchorProfile = profile; return
        }
        if (pct < drainAnchorPct) {
            val hours = (now - drainAnchorAt) / 3_600_000f
            if (hours >= 0.05f) {
                val rate = (drainAnchorPct - pct) / hours
                stats[profile] = EvolutionPolicy.withDrain(stats[profile] ?: EvolutionPolicy.ProfileStats(), rate)
                saveStats(); bump()
            }
            drainAnchorPct = pct; drainAnchorAt = now
        }
    }

    fun resetDrainAnchor() { drainAnchorPct = -1; drainAnchorProfile = null }

    /** Records an automatic profile switch made by [AdaptiveCore] in Adaptive mode. */
    fun recordProfileSwitch(from: Profile, to: Profile, reason: String) {
        record("profile", from.name, to.name, reason, auto = true, status = Status.Applied,
            beforeJank = currentWindow?.jankFraction)
    }

    // ---- recommendations ---------------------------------------------------------------------------

    fun recommendations(inputs: EvolutionPolicy.RecInputs, now: Long = System.currentTimeMillis()): List<EvolutionPolicy.Recommendation> =
        EvolutionPolicy.recommendations(inputs).filter { (dismissedUntil[it.id] ?: 0L) < now }

    /**
     * Applies an approved recommendation. Returns a UI action for the ones that are really
     * "go and do this" ("diagnostic", "audio"), or null when a setting was changed.
     */
    fun applyRecommendation(id: String): String? {
        when (id) {
            "run_diagnostic" -> return "diagnostic"
            "test_audio" -> return "audio"
            "crt_off" -> { approved("crtOn", settings.crtOn.toString(), "false", "Scanline filter off"); settings.updateCrtOn(false) }
            "particles_off" -> { approved("particlesOn", settings.particlesOn.toString(), "false", "Particles off"); settings.updateParticlesOn(false) }
            "stay_awake_off" -> { approved("stayAwake", settings.stayAwake.toString(), "false", "Screen allowed to sleep"); settings.updateStayAwake(false) }
            "hum_off" -> { approved("ambientHumOn", settings.ambientHumOn.toString(), "false", "Ambient hum off"); settings.updateAmbientHumOn(false) }
            "mode_adaptive" -> { approved("powerMode", settings.powerMode.name, PowerMode.Adaptive.name, "Adaptive AI mode"); settings.updatePowerMode(PowerMode.Adaptive) }
        }
        dismissedUntil[id] = System.currentTimeMillis() + 7 * DAY
        saveDismissed()
        return null
    }

    fun dismissRecommendation(id: String) {
        dismissedUntil[id] = System.currentTimeMillis() + 7 * DAY
        saveDismissed(); bump()
    }

    private fun approved(knob: String, from: String, to: String, what: String) {
        record(knob, from, to, "$what (approved by you)", auto = false, status = Status.Applied,
            beforeJank = currentWindow?.jankFraction)
        note("$what (approved by you)")
    }

    // ---- rollback ----------------------------------------------------------------------------------

    /** The newest adjustment that can still be undone, or null. */
    fun lastReversible(): Adjustment? =
        history.lastOrNull { it.status == Status.Applied || it.status == Status.Kept || it.status == Status.Trial }

    /** Undoes [lastReversible]. Returns a plain-language description, or null if nothing to undo. */
    fun rollbackLast(): String? {
        val a = lastReversible() ?: return null
        when (a.knob) {
            "particles" -> {
                val v = a.from.removeSuffix("%").toFloatOrNull()?.div(100f) ?: return null
                setParticleScale(v)
                if (trialAdjustmentId == a.id) trialAdjustmentId = null
            }
            "profile" -> {
                val p = runCatching { Profile.valueOf(a.from) }.getOrNull() ?: return null
                profileHold = p
                profileHoldUntil = System.currentTimeMillis() + 30 * 60_000L
            }
            "crtOn" -> settings.updateCrtOn(a.from.toBoolean())
            "particlesOn" -> settings.updateParticlesOn(a.from.toBoolean())
            "stayAwake" -> settings.updateStayAwake(a.from.toBoolean())
            "ambientHumOn" -> settings.updateAmbientHumOn(a.from.toBoolean())
            "powerMode" -> runCatching { PowerMode.valueOf(a.from) }.getOrNull()?.let { settings.updatePowerMode(it) }
            else -> return null
        }
        setStatus(a.id, Status.Reverted, null)
        rollbacksTotal += 1
        sp.edit().putInt("rollbacksTotal", rollbacksTotal).apply()
        val msg = when (a.knob) {
            "profile" -> "Rolled back to ${Profile.valueOf(a.from).label}; Adaptive mode holds it for 30 minutes"
            else -> "Rolled back: ${a.knob} ${a.to} → ${a.from}"
        }
        note(msg)
        spend(msg, true)
        bump()
        return msg
    }

    /** Forgets everything learned (stats, particle trim, trial, holds). History is kept. */
    fun resetLearning() {
        stats.clear(); saveStats()
        setParticleScale(1f)
        trialAdjustmentId = null; goodStreak = 0
        profileHold = null; profileHoldUntil = 0L
        resetDrainAnchor()
        note("Learning reset by you")
        bump()
    }

    // ---- self-check for diagnostics ------------------------------------------------------------------

    /** Returns a list of problems with the stored configuration (empty = consistent). */
    fun configProblems(): List<String> = buildList {
        val s = settings.evoParticleScale
        if (s < EvolutionPolicy.PARTICLE_MIN - 1e-3f || s > EvolutionPolicy.PARTICLE_MAX + 1e-3f) add("particle trim out of range ($s)")
        if (settings.adaptiveFloor < settings.adaptiveCeiling) add("adaptive floor above ceiling")
        for ((p, st) in stats) {
            if (st.jankEma.isNaN() || st.jankEma !in 0f..1f) add("${p.label} jank average invalid")
            if (st.drainPerHourEma.isNaN() || st.drainPerHourEma < 0f) add("${p.label} drain average invalid")
        }
        if (history.size > MAX_HISTORY) add("history over limit")
    }

    // ---- internals ----------------------------------------------------------------------------------

    private fun setParticleScale(v: Float) {
        val c = v.coerceIn(EvolutionPolicy.PARTICLE_MIN, EvolutionPolicy.PARTICLE_MAX)
        settings.evoParticleScale = c
        sp.edit().putFloat("particleScale", c).apply()
    }

    private fun record(knob: String, from: String, to: String, reason: String, auto: Boolean, status: Status, beforeJank: Float?): Adjustment {
        val a = Adjustment(System.currentTimeMillis() * 10 + (history.size % 10), System.currentTimeMillis(),
            knob, from, to, reason, auto, status, beforeJank, null)
        history.add(a)
        while (history.size > MAX_HISTORY) history.removeAt(0)
        adjustmentsTotal += 1
        lastOptimization = reason
        sp.edit().putInt("adjustmentsTotal", adjustmentsTotal).putString("lastOptimization", reason).apply()
        saveHistory(); bump()
        return a
    }

    private fun setStatus(id: Long, status: Status, afterJank: Float?) {
        val i = history.indexOfFirst { it.id == id }
        if (i < 0) return
        history[i] = history[i].copy(status = status, afterJank = afterJank ?: history[i].afterJank)
        saveHistory()
    }

    private fun note(text: String) {
        lastOptimization = text
        sp.edit().putString("lastOptimization", text).apply()
    }

    private fun bump() { revision += 1 }

    private fun load() {
        runCatching {
            val o = JSONObject(sp.getString("stats", "{}") ?: "{}")
            for (p in Profile.values()) {
                val s = o.optJSONObject(p.name) ?: continue
                stats[p] = EvolutionPolicy.ProfileStats(
                    windows = s.optInt("w"), jankEma = s.optDouble("j", 0.0).toFloat(),
                    frameMsEma = s.optDouble("f", 0.0).toFloat(), drainSamples = s.optInt("ds"),
                    drainPerHourEma = s.optDouble("d", 0.0).toFloat(),
                )
            }
        }
        runCatching {
            val arr = JSONArray(sp.getString("history", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                history.add(Adjustment(
                    id = o.optLong("id"), at = o.optLong("at"), knob = o.optString("k"),
                    from = o.optString("from"), to = o.optString("to"), reason = o.optString("r"),
                    auto = o.optBoolean("auto"),
                    status = runCatching { Status.valueOf(o.optString("s")) }.getOrDefault(Status.Applied),
                    beforeJank = if (o.has("bj")) o.optDouble("bj").toFloat() else null,
                    afterJank = if (o.has("aj")) o.optDouble("aj").toFloat() else null,
                ))
            }
            // A trial interrupted by the app closing is resolved conservatively: roll it back.
            for (i in history.indices) if (history[i].status == Status.Trial) {
                history[i] = history[i].copy(status = Status.RolledBack)
                history[i].from.removeSuffix("%").toFloatOrNull()?.let { sp.edit().putFloat("particleScale", it / 100f).apply() }
            }
        }
        runCatching {
            val o = JSONObject(sp.getString("dismissed", "{}") ?: "{}")
            for (k in o.keys()) dismissedUntil[k] = o.optLong(k)
        }
    }

    private fun saveStats() {
        val o = JSONObject()
        for ((p, s) in stats) o.put(p.name, JSONObject()
            .put("w", s.windows).put("j", s.jankEma.toDouble()).put("f", s.frameMsEma.toDouble())
            .put("ds", s.drainSamples).put("d", s.drainPerHourEma.toDouble()))
        sp.edit().putString("stats", o.toString()).apply()
    }

    private fun saveHistory() {
        val arr = JSONArray()
        for (a in history) {
            val o = JSONObject().put("id", a.id).put("at", a.at).put("k", a.knob).put("from", a.from)
                .put("to", a.to).put("r", a.reason).put("auto", a.auto).put("s", a.status.name)
            a.beforeJank?.let { o.put("bj", it.toDouble()) }
            a.afterJank?.let { o.put("aj", it.toDouble()) }
            arr.put(o)
        }
        sp.edit().putString("history", arr.toString()).apply()
    }

    private fun saveDismissed() {
        val o = JSONObject(); dismissedUntil.forEach { (k, v) -> o.put(k, v) }
        sp.edit().putString("dismissed", o.toString()).apply()
    }

    private fun pct(f: Float) = "${(f * 100).toInt()}%"

    private companion object {
        const val MAX_HISTORY = 40
        const val DAY = 86_400_000L
    }
}
