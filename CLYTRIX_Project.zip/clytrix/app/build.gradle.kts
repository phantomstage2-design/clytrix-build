plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.clytrix.core"
    // 36 = Wear OS 6 / Android 16, the Galaxy Watch 8 Classic's platform. Carried over unchanged
    // from Apexium (which documented it against Google's Wear OS 6 guide); requires AGP 8.10.0+.
    compileSdk = 36

    defaultConfig {
        // Independent identity: CLYTRIX installs side by side with Apexium (com.apexium.core) and
        // never shares its SharedPreferences, files or backups.
        applicationId = "com.clytrix.core"
        // Kept at 30 (Wear OS 3+), as in Apexium -- nothing in CLYTRIX needs a higher floor.
        minSdk = 30
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
}

// Gradle writes app/build/outputs/apk/debug/app-debug.apk; the `clytrixApk` task below copies it
// to the project root as CLYTRIX.apk (no internal AGP APIs needed for the rename).
tasks.register<Copy>("clytrixApk") {
    dependsOn("assembleDebug")
    from(layout.buildDirectory.file("outputs/apk/debug/app-debug.apk"))
    into(rootProject.layout.projectDirectory)
    rename { "CLYTRIX.apk" }
}

dependencies {
    // Versions carried over unchanged from the Apexium project, which recorded checking each
    // against Google's release pages. Not re-verified in the CLYTRIX build session (Google's Maven
    // repository was not reachable there) -- see docs/VERIFICATION.md.
    val composeBom = platform("androidx.compose:compose-bom:2026.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.runtime:runtime")
    implementation("androidx.compose.animation:animation-core")

    implementation("androidx.wear.compose:compose-material:1.7.1")
    implementation("androidx.wear.compose:compose-foundation:1.7.1")

    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // RemoteInputIntentHelper -- the standard Wear OS voice/keyboard text-entry picker, used to
    // name a form after picking its photo. Its methods take the PLATFORM android.app.RemoteInput,
    // not androidx.core.app.RemoteInput.
    implementation("androidx.wear:wear-input:1.1.0")

    // NEW in CLYTRIX: Wear OS Data Layer (MessageClient/NodeClient) for the optional Mira AI
    // Companion Link. 19.0.0 is a published release of this artifact; it is only used when the
    // user turns the link on, and CLYTRIX works fully offline without it ever connecting.
    implementation("com.google.android.gms:play-services-wearable:19.0.0")

    // Local-JVM unit tests (app/src/test): SoundScheduler, CelestialSynth, EvolutionPolicy,
    // PerfMonitor, MiraAuth, PhaseGraph and BackupRules have no Android dependency.
    testImplementation("junit:junit:4.13.2")
}
