plugins {
    // Carried over from Apexium: AGP 8.10.0 is the first release supporting compileSdk/targetSdk 36
    // (Wear OS 6). Kotlin 2.0.21 with its matching Compose compiler plugin.
    id("com.android.application") version "8.10.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
}
