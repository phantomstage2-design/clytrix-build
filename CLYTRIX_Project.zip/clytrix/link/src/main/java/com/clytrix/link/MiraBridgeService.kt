package com.clytrix.link

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.RemoteException
import android.util.Log
import com.google.android.gms.wearable.CapabilityClient
import com.google.android.gms.wearable.MessageClient
import com.google.android.gms.wearable.MessageEvent
import com.google.android.gms.wearable.Node
import com.google.android.gms.wearable.Wearable
import org.json.JSONObject

/**
 * Phone-side relay between Mira AI and CLYTRIX on the watch.
 *
 * Mira AI binds this service (it must hold com.clytrix.permission.MIRA_LINK, which the user grants
 * in a runtime prompt) and talks to it with [Messenger]:
 *
 *   Mira -> bridge  what = [MSG_REQUEST], data = Bundle { "json": "<request JSON>" }, replyTo = Mira's Messenger
 *   bridge -> Mira  what = [MSG_REPLY],   data = Bundle { "json": "<reply JSON>" }
 *
 * The request JSON is exactly the watch protocol (see docs/MIRA_INTEGRATION.md); it must carry a
 * unique "id". The bridge does not interpret commands or hold tokens -- all authentication happens
 * on the watch. It only finds the watch (capability "clytrix_watch"), forwards the request over the
 * Data Layer, and routes the watch's reply back to whoever asked, or answers "watch_unreachable" /
 * "watch_timeout" itself.
 */
class MiraBridgeService : Service(), MessageClient.OnMessageReceivedListener {

    private val main = Handler(Looper.getMainLooper())
    private val pending = HashMap<String, Messenger>()

    private val incoming = Messenger(Handler(Looper.getMainLooper()) { msg -> handleFromMira(msg); true })

    override fun onBind(intent: Intent?): IBinder = incoming.binder

    override fun onCreate() {
        super.onCreate()
        Wearable.getMessageClient(this).addListener(this)
    }

    override fun onDestroy() {
        Wearable.getMessageClient(this).removeListener(this)
        for ((id, to) in pending) replyError(to, id, "bridge_closed", "The CLYTRIX Link relay stopped")
        pending.clear()
        super.onDestroy()
    }

    private fun handleFromMira(msg: Message) {
        if (msg.what != MSG_REQUEST) return
        val replyTo = msg.replyTo ?: return
        val json = msg.data?.getString("json")
        val req = try {
            if (json == null || json.length > MAX_JSON) throw IllegalArgumentException()
            JSONObject(json)
        } catch (e: Exception) {
            replyError(replyTo, "", "bad_request", "Request must be a JSON object under $MAX_JSON characters")
            return
        }
        val id = req.optString("id")
        if (id.isEmpty() || id.length > 64) { replyError(replyTo, id, "bad_request", "Request needs an id of 1-64 characters"); return }
        if (pending.size >= MAX_PENDING) { replyError(replyTo, id, "busy", "Too many requests in flight"); return }
        pending[id] = replyTo
        main.postDelayed({ pending.remove(id)?.let { replyError(it, id, "watch_timeout", "CLYTRIX on the watch didn't answer in time") } }, TIMEOUT_MS)

        Wearable.getCapabilityClient(this)
            .getCapability(WATCH_CAPABILITY, CapabilityClient.FILTER_REACHABLE)
            .addOnSuccessListener { info ->
                val node: Node? = info.nodes.firstOrNull { it.isNearby } ?: info.nodes.firstOrNull()
                if (node == null) {
                    pending.remove(id)?.let { replyError(it, id, "watch_unreachable", "No watch with CLYTRIX is connected") }
                    return@addOnSuccessListener
                }
                Wearable.getMessageClient(this).sendMessage(node.id, REQUEST_PATH, json!!.toByteArray(Charsets.UTF_8))
                    .addOnFailureListener { e ->
                        pending.remove(id)?.let { replyError(it, id, "send_failed", "Couldn't reach the watch: ${e.javaClass.simpleName}") }
                    }
            }
            .addOnFailureListener {
                pending.remove(id)?.let { to -> replyError(to, id, "watch_unreachable", "Wear OS connection unavailable") }
            }
    }

    /** Replies from the watch arrive here (Data Layer listener, main thread). */
    override fun onMessageReceived(event: MessageEvent) {
        if (event.path != REPLY_PATH) return
        val text = String(event.data ?: return, Charsets.UTF_8)
        val id = runCatching { JSONObject(text).optString("id") }.getOrNull() ?: return
        val to = pending.remove(id) ?: return
        send(to, text)
    }

    private fun replyError(to: Messenger, id: String, code: String, message: String) {
        send(to, JSONObject().put("v", 1).put("id", id).put("ok", false).put("error", code).put("message", message).toString())
    }

    private fun send(to: Messenger, json: String) {
        try {
            to.send(Message.obtain(null, MSG_REPLY).apply { data = Bundle().apply { putString("json", json) } })
        } catch (e: RemoteException) {
            Log.w(TAG, "Mira AI went away before the reply arrived")
        }
    }

    companion object {
        const val MSG_REQUEST = 1
        const val MSG_REPLY = 2
        const val REQUEST_PATH = "/clytrix/v1/request"
        const val REPLY_PATH = "/clytrix/v1/reply"
        const val WATCH_CAPABILITY = "clytrix_watch"
        private const val TAG = "ClytrixLink"
        private const val MAX_JSON = 4096
        private const val MAX_PENDING = 16
        private const val TIMEOUT_MS = 10_000L
    }
}
