plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// OPTIONAL phone-side relay for the Mira AI Companion Link. Install on the phone paired with the
// watch only if you use Mira AI. It has no UI of its own: Mira AI binds to MiraBridgeService.
android {
    namespace = "com.clytrix.link"
    compileSdk = 36

    defaultConfig {
        // MUST equal the watch app's applicationId, and both must be signed with the same key:
        // the Wear OS Data Layer only delivers messages between matching apps.
        applicationId = "com.clytrix.core"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.android.gms:play-services-wearable:19.0.0")
}
